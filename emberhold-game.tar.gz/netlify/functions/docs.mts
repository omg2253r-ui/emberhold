// Shared guild documents. Logic lives in ../lib/docs.mjs (shared with the local test server).
import { getStore } from '@netlify/blobs';
import { handleDocs, blobsDocs } from '../lib/docs.mjs';

export default async (req: Request) => handleDocs(req, blobsDocs(getStore({ name: 'emberhold-docs', consistency: 'strong' })));

export const config = { path: '/api/docs' };
