// All sound is synthesized with the Web Audio API (no audio files needed).
// Audio starts only after the first user gesture, as browsers require.

export function createAudio() {
  let ctx = null, master = null, sfxBus = null, musicBus = null, noiseBuf = null;
  let sfxVol = 0.8, musicVol = 0.45;
  const lastPlayed = new Map();
  let music = null;

  function ensure() {
    if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return true; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return false;
    ctx = new AC();
    master = ctx.createGain(); master.gain.value = 0.9; master.connect(ctx.destination);
    const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 6; comp.connect(master);
    sfxBus = ctx.createGain(); sfxBus.gain.value = sfxVol; sfxBus.connect(comp);
    musicBus = ctx.createGain(); musicBus.gain.value = musicVol * 0.5; musicBus.connect(comp);
    noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 0.6, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    return true;
  }

  const now = () => ctx.currentTime;

  function tone({ type = 'sine', f = 440, f2 = null, t = 0, dur = 0.15, vol = 0.3, attack = 0.005, bus = sfxBus, detune = 0 }) {
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type; o.detune.value = detune;
    const st = now() + t;
    o.frequency.setValueAtTime(f, st);
    if (f2) o.frequency.exponentialRampToValueAtTime(Math.max(20, f2), st + dur);
    g.gain.setValueAtTime(0.0001, st);
    g.gain.exponentialRampToValueAtTime(vol, st + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, st + dur);
    o.connect(g); g.connect(bus);
    o.start(st); o.stop(st + dur + 0.05);
  }

  function noise({ t = 0, dur = 0.15, vol = 0.3, type = 'bandpass', f = 1200, f2 = null, q = 1.2 }) {
    const s = ctx.createBufferSource(), flt = ctx.createBiquadFilter(), g = ctx.createGain();
    s.buffer = noiseBuf; flt.type = type; flt.Q.value = q;
    const st = now() + t;
    flt.frequency.setValueAtTime(f, st);
    if (f2) flt.frequency.exponentialRampToValueAtTime(f2, st + dur);
    g.gain.setValueAtTime(0.0001, st);
    g.gain.exponentialRampToValueAtTime(vol, st + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, st + dur);
    s.connect(flt); flt.connect(g); g.connect(sfxBus);
    s.start(st, Math.random() * 0.3); s.stop(st + dur + 0.05);
  }

  // Pentatonic notes used by chimes and the ambient music.
  const scale = [0, 2, 4, 7, 9];
  const note = (n, base = 293.66) => base * Math.pow(2, (Math.floor(n / 5) * 12 + scale[((n % 5) + 5) % 5]) / 12);

  const SOUNDS = {
    click: () => tone({ type: 'triangle', f: 880, f2: 660, dur: 0.06, vol: 0.12 }),
    tab: () => { tone({ type: 'triangle', f: 520, dur: 0.07, vol: 0.12 }); tone({ type: 'triangle', f: 780, t: 0.04, dur: 0.08, vol: 0.1 }); },
    error: () => { tone({ type: 'square', f: 220, dur: 0.1, vol: 0.08 }); tone({ type: 'square', f: 165, t: 0.1, dur: 0.14, vol: 0.08 }); },
    swing: (o) => noise({ dur: 0.13, vol: 0.22 * (o?.power || 1), f: 2600, f2: 700, q: 0.9 }),
    hit: () => { tone({ type: 'sine', f: 170, f2: 60, dur: 0.14, vol: 0.45 }); noise({ dur: 0.05, vol: 0.25, type: 'highpass', f: 2000 }); },
    crit: () => { tone({ type: 'sine', f: 190, f2: 55, dur: 0.18, vol: 0.5 }); tone({ type: 'triangle', f: 1480, f2: 1200, t: 0.01, dur: 0.22, vol: 0.18 }); noise({ dur: 0.08, vol: 0.3, type: 'highpass', f: 3000 }); },
    enemyDie: () => { tone({ type: 'triangle', f: 420, f2: 90, dur: 0.28, vol: 0.25 }); noise({ dur: 0.2, vol: 0.18, f: 600, f2: 200 }); },
    hurt: () => { tone({ type: 'square', f: 140, f2: 80, dur: 0.18, vol: 0.16 }); noise({ dur: 0.12, vol: 0.2, f: 900 }); },
    dash: () => noise({ dur: 0.2, vol: 0.2, f: 900, f2: 3000, q: 0.7 }),
    gold: () => { tone({ type: 'triangle', f: 1568, dur: 0.08, vol: 0.12 }); tone({ type: 'triangle', f: 2093, t: 0.06, dur: 0.12, vol: 0.1 }); },
    pickup: (o) => {
      const r = o?.rarity ?? 0;
      const notes = r >= 2 ? [5, 7, 9, 10] : r === 1 ? [5, 7, 9] : [7, 9];
      notes.forEach((n, i) => tone({ type: 'triangle', f: note(n), t: i * 0.06, dur: 0.18 + r * 0.05, vol: 0.14 }));
      if (r >= 2) tone({ type: 'sine', f: note(12), t: notes.length * 0.06, dur: 0.6, vol: 0.12 });
    },
    potion: () => { for (let i = 0; i < 4; i++) tone({ type: 'sine', f: 400 + i * 120, f2: 700 + i * 140, t: i * 0.05, dur: 0.12, vol: 0.12 }); },
    levelup: () => [0, 2, 4, 5, 7].forEach((n, i) => tone({ type: 'triangle', f: note(n + 5), t: i * 0.08, dur: 0.3, vol: 0.16 })),
    telegraph: () => tone({ type: 'sawtooth', f: 110, f2: 160, dur: 0.35, vol: 0.07 }),
    roar: () => { noise({ dur: 0.7, vol: 0.35, type: 'lowpass', f: 500, f2: 150, q: 2 }); tone({ type: 'sawtooth', f: 90, f2: 55, dur: 0.7, vol: 0.12 }); },
    slam: () => { tone({ type: 'sine', f: 90, f2: 30, dur: 0.45, vol: 0.6 }); noise({ dur: 0.35, vol: 0.35, type: 'lowpass', f: 400, f2: 80 }); },
    forge: () => { [1, 2.76, 5.4].forEach((m, i) => tone({ type: 'sine', f: 520 * m, dur: 0.5 - i * 0.12, vol: 0.12 / (i + 1) })); noise({ dur: 0.05, vol: 0.25, type: 'highpass', f: 3000 }); },
    success: () => { [0, 4, 7, 12].forEach((s, i) => tone({ type: 'triangle', f: 392 * Math.pow(2, s / 12), t: i * 0.09, dur: 0.4, vol: 0.16 })); tone({ type: 'sine', f: 1568, t: 0.36, dur: 0.8, vol: 0.08 }); },
    fail: () => { tone({ type: 'sawtooth', f: 220, f2: 110, dur: 0.4, vol: 0.1 }); noise({ dur: 0.3, vol: 0.18, type: 'lowpass', f: 600, f2: 120 }); },
    buy: () => { SOUNDS.gold(); tone({ type: 'triangle', f: 660, t: 0.12, dur: 0.1, vol: 0.1 }); },
    wave: () => [0, 3, 5].forEach((n, i) => tone({ type: 'triangle', f: note(n), t: i * 0.1, dur: 0.25, vol: 0.13 })),
    victory: () => [0, 2, 4, 7, 9, 12].forEach((n, i) => tone({ type: 'triangle', f: note(n + 3), t: i * 0.11, dur: 0.45, vol: 0.15 })),
    defeat: () => [7, 4, 2, 0].forEach((n, i) => tone({ type: 'sine', f: note(n), t: i * 0.18, dur: 0.5, vol: 0.14 })),
    spawn: () => noise({ dur: 0.25, vol: 0.1, f: 300, f2: 900, q: 3 }),
    bow: (o) => { tone({ type: 'triangle', f: 320 * (o?.power || 1), f2: 140, dur: 0.12, vol: 0.18 }); noise({ dur: 0.08, vol: 0.16, type: 'highpass', f: 2600 }); },
    cast: (o) => { tone({ type: 'sine', f: 520, f2: 980 * Math.min(1.6, o?.power || 1), dur: 0.16, vol: 0.14 }); noise({ dur: 0.14, vol: 0.12, f: 1800, f2: 4200, q: 2 }); },
    blink: () => { tone({ type: 'sine', f: 1200, f2: 300, dur: 0.14, vol: 0.12 }); noise({ dur: 0.12, vol: 0.12, type: 'highpass', f: 3000 }); },
    charge: () => { tone({ type: 'triangle', f: 660, dur: 0.08, vol: 0.12 }); tone({ type: 'triangle', f: 990, t: 0.06, dur: 0.14, vol: 0.12 }); },
    perfect: () => { tone({ type: 'sine', f: 1760, f2: 880, dur: 0.5, vol: 0.14 }); tone({ type: 'triangle', f: 440, t: 0.02, dur: 0.4, vol: 0.12 }); noise({ dur: 0.3, vol: 0.12, f: 3000, f2: 600, q: 0.8 }); },
    guard: () => { tone({ type: 'triangle', f: 520, f2: 760, dur: 0.07, vol: 0.07 }); noise({ dur: 0.06, vol: 0.05, type: 'highpass', f: 2400 }); },
    block: () => { tone({ type: 'square', f: 260, f2: 180, dur: 0.08, vol: 0.09 }); noise({ dur: 0.1, vol: 0.16, f: 1800, f2: 900, q: 2 }); },
    guardBreak: () => { tone({ type: 'sawtooth', f: 200, f2: 70, dur: 0.35, vol: 0.13 }); noise({ dur: 0.35, vol: 0.2, type: 'lowpass', f: 1200, f2: 200 }); },
    parry: () => { tone({ type: 'triangle', f: 1320, f2: 1980, dur: 0.12, vol: 0.16 }); tone({ type: 'sine', f: 2640, t: 0.03, dur: 0.45, vol: 0.09 }); noise({ dur: 0.16, vol: 0.2, type: 'highpass', f: 3200 }); },
    counter: () => { tone({ type: 'sawtooth', f: 330, f2: 990, dur: 0.14, vol: 0.12 }); noise({ dur: 0.2, vol: 0.18, f: 900, f2: 3000, q: 1.5 }); },
    clash: () => { tone({ type: 'square', f: 880, f2: 660, dur: 0.1, vol: 0.11 }); noise({ dur: 0.12, vol: 0.22, type: 'highpass', f: 2800 }); },
    summon: () => [0, 4, 7, 11, 14].forEach((n, i) => tone({ type: 'triangle', f: note(n + 7), t: i * 0.07, dur: 0.35, vol: 0.13 })),
    legendary: () => { [0, 4, 7, 12, 16, 19].forEach((n, i) => tone({ type: 'triangle', f: note(n + 5), t: i * 0.09, dur: 0.6, vol: 0.15 })); tone({ type: 'sine', f: 2093, t: 0.5, dur: 1, vol: 0.08 }); },
  };

  function startMusic(mood = 'camp') {
    if (!ensure()) return;
    stopMusic();
    const state = { stop: false, step: 0, timer: 0 };
    const tempo = mood === 'battle' ? 0.24 : 0.36;
    const droneBase = mood === 'battle' ? 73.42 : 98;
    const drone = ctx.createOscillator(), dg = ctx.createGain(), lp = ctx.createBiquadFilter();
    drone.type = 'sawtooth'; drone.frequency.value = droneBase; lp.type = 'lowpass'; lp.frequency.value = 280;
    dg.gain.value = 0.05; drone.connect(lp); lp.connect(dg); dg.connect(musicBus); drone.start();
    state.drone = drone;
    let nextT = ctx.currentTime + 0.1;
    const pattern = mood === 'battle' ? [0, 2, 3, 2, 4, 3, 2, 0] : [0, 3, 2, 4, 3, 1, 2, 0];
    function schedule() {
      if (state.stop) return;
      while (nextT < ctx.currentTime + 0.4) {
        const i = state.step++;
        const n = pattern[i % pattern.length] + (Math.random() < 0.18 ? 5 : 0);
        if (Math.random() > 0.15) {
          const o = ctx.createOscillator(), g = ctx.createGain();
          o.type = 'triangle'; o.frequency.value = note(n, mood === 'battle' ? 220 : 293.66);
          g.gain.setValueAtTime(0.0001, nextT); g.gain.exponentialRampToValueAtTime(0.09, nextT + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, nextT + tempo * 1.8);
          o.connect(g); g.connect(musicBus); o.start(nextT); o.stop(nextT + tempo * 2);
        }
        if (mood === 'battle' && i % 2 === 0) {
          const o = ctx.createOscillator(), g = ctx.createGain();
          o.type = 'sine'; o.frequency.setValueAtTime(120, nextT); o.frequency.exponentialRampToValueAtTime(45, nextT + 0.15);
          g.gain.setValueAtTime(0.18, nextT); g.gain.exponentialRampToValueAtTime(0.0001, nextT + 0.18);
          o.connect(g); g.connect(musicBus); o.start(nextT); o.stop(nextT + 0.2);
        }
        nextT += tempo;
      }
      state.timer = setTimeout(schedule, 120);
    }
    schedule();
    music = state;
  }

  function stopMusic() {
    if (!music) return;
    music.stop = true; clearTimeout(music.timer);
    try { music.drone.stop(); } catch { /* already stopped */ }
    music = null;
  }

  return {
    unlock: ensure,
    play(name, opts) {
      if (!ctx || sfxVol <= 0 || !SOUNDS[name]) return;
      // throttle identical sounds so 10 simultaneous hits don't clip
      const t = performance.now();
      if (t - (lastPlayed.get(name) || 0) < 35) return;
      lastPlayed.set(name, t);
      SOUNDS[name](opts);
    },
    setVolumes(sfx, mus) {
      sfxVol = sfx; musicVol = mus;
      if (sfxBus) sfxBus.gain.value = sfx;
      if (musicBus) musicBus.gain.value = mus * 0.5;
    },
    startMusic, stopMusic,
    suspend() { if (ctx && ctx.state === 'running') ctx.suspend(); },
    resume() { if (ctx && ctx.state === 'suspended') ctx.resume(); },
    get ready() { return !!ctx; },
  };
}
