// The companion in the dungeon: follows the hero with a soft spring, and uses its ability on a timer.
// Numbers come from data/pets.js (scaled by stars in systems/pets.js → activePet).
import { nearestEnemy } from './moves.js';

export function createPetEntity(active, x, y) {
  if (!active) return null;
  return {
    id: active.id, pet: active.pet, v: active.v, stars: active.stars,
    x: x - 50, y: y + 10, r: 14, vx: 0, vy: 0, z: active.pet.flying ? 34 : 0, t: 0, cd: Math.min(2, active.v.every || 0),
    flip: false, state: 'follow', dash: null, hop: 0, target: null, glow: 0,
  };
}

const anyEnemy = (world) => world.enemies.some((e) => !e.dead && e.spawning <= 0);

export function updatePet(pet, dt, world) {
  if (!pet) return;
  const p = world.player, v = pet.v;
  pet.t += dt;
  if (pet.glow > 0) pet.glow -= dt * 2;

  // --- movement: a dash toward a bite target, or follow a point behind the hero
  if (pet.dash) {
    const D = pet.dash;
    D.t += dt;
    const k = Math.min(1, D.t / D.dur);
    const e = D.target;
    const tx = e.dead ? D.x1 : e.x - Math.cos(D.a) * e.r, ty = e.dead ? D.y1 : e.y;
    pet.x = D.x0 + (tx - D.x0) * k; pet.y = D.y0 + (ty - D.y0) * k;
    if (k >= 1 && !D.hit) {
      D.hit = true;
      if (!e.dead) {
        world.petStrike(e, v.power, { kx: Math.cos(D.a) * 120, ky: Math.sin(D.a) * 120, mark: v.mark, markT: v.markT });
        world.particles.burst(e.x, e.y - e.r, 10, { color: ['#c8d2f4', '#ffffff'], speedMin: 60, speedMax: 200, life: 0.3, size: 3, drag: 4, glow: true });
      }
    }
    if (D.t > D.dur + 0.12) pet.dash = null;
  } else {
    // stay at the hero's back shoulder (flyers a little higher up in the air, walkers a step behind)
    let gx = p.x + (p.flip ? 62 : -62), gy = p.y + (pet.pet.flying ? -6 : 8);
    // the moss mouse scurries off to loot that is lying around
    if (pet.id === 'mossmouse') {
      const d = world.drops.find((x) => x.state === 'rest');
      if (d) { gx = d.x; gy = d.y + 6; }
    }
    const dx = gx - pet.x, dy = gy - pet.y, dist = Math.hypot(dx, dy);
    const want = dist > 30 ? Math.min(560, dist * 4.2) : 0;
    const tvx = dist > 1 ? (dx / dist) * want : 0, tvy = dist > 1 ? (dy / dist) * want : 0;
    const k = Math.min(1, dt * 7);
    pet.vx += (tvx - pet.vx) * k; pet.vy += (tvy - pet.vy) * k;
    pet.x += pet.vx * dt; pet.y += pet.vy * dt;
    if (dist > 600) { pet.x = p.x - 40; pet.y = p.y + 10; }   // fell far behind (room change)
    if (Math.abs(pet.vx) > 12) pet.flip = pet.vx < 0;
    else pet.flip = p.x < pet.x;
  }
  if (!pet.pet.flying && Math.hypot(pet.vx, pet.vy) > 40) pet.hop += dt * 16;
  world.clampBody?.(pet);

  // --- ability
  if (v.kind === 'passive') return;
  pet.cd -= dt;
  if (pet.cd > 0) return;
  const fighting = anyEnemy(world);
  switch (v.kind) {
    case 'heal': {
      if (p.hp >= p.maxHp || p.dead) { pet.cd = 0.5; return; }
      const heal = Math.max(1, Math.round(p.maxHp * v.healPct));
      p.hp = Math.min(p.maxHp, p.hp + heal);
      world.fx.number(p.x, p.y - 96, `+${heal}`, 'heal');
      world.particles.burst(pet.x, pet.y - pet.z, 10, { color: ['#ffd889', '#fff3c4'], speedMin: 30, speedMax: 100, life: 0.6, size: 3, drag: 2, grav: -60, glow: true });
      pet.glow = 1;
      break;
    }
    case 'shield': {
      if (!fighting) { pet.cd = 0.5; return; }
      const amt = Math.round(p.maxHp * v.shieldPct);
      if (p.shield < amt) { p.shield = amt; p.shieldMax = amt; }
      p.shieldT = Math.max(p.shieldT, v.duration);
      world.fx.ring(p.x, p.y - 30, 50, 22, '#b8a48a', 0.4, 6);
      pet.glow = 1;
      break;
    }
    case 'bless': {
      if (!fighting) { pet.cd = 0.5; return; }
      p.buffs.blessT = v.duration; p.buffs.bless = v.atkPct;
      world.fx.ring(p.x, p.y - 40, 10, 60, '#ffb35a', 0.5, 5);
      world.particles.burst(p.x, p.y - 50, 14, { color: ['#ffb35a', '#fff3c4'], speedMin: 30, speedMax: 120, life: 0.6, size: 3, drag: 2, grav: -60, glow: true });
      pet.glow = 1;
      break;
    }
    case 'bolt': {
      const e = nearestEnemy(world, pet, v.range);
      if (!e) { pet.cd = 0.3; return; }
      const a = Math.atan2(e.y - e.r - (pet.y - pet.z), e.x - pet.x);
      world.firePlayerShot({ kind: 'feather', x: pet.x, y: pet.y - pet.z, angle: a, speed: 560, r: 8, pierce: 0, homing: 4, power: v.power, src: 'pet', kb: 60 });
      pet.flip = Math.cos(a) < 0; pet.glow = 0.6;
      break;
    }
    case 'bite': {
      const e = nearestEnemy(world, pet, v.range);
      if (!e) { pet.cd = 0.3; return; }
      const a = Math.atan2(e.y - pet.y, e.x - pet.x);
      pet.dash = { t: 0, dur: 0.18, x0: pet.x, y0: pet.y, x1: e.x, y1: e.y, a, target: e, hit: false };
      pet.flip = Math.cos(a) < 0;
      break;
    }
    case 'breath': {
      const e = nearestEnemy(world, pet, v.range + 60);
      if (!e) { pet.cd = 0.3; return; }
      const arc = (v.arc * Math.PI) / 180;
      world.addCone({ from: () => (e.dead && world.enemies.indexOf(e) < 0 ? null : { x: pet.x, y: pet.y - pet.z - 10, dir: Math.atan2(e.y - e.r - (pet.y - pet.z - 10), e.x - pet.x) }),
        range: v.range, arc, ticks: v.ticks, interval: 0.2, power: v.power, src: 'pet', t: 0, n: 0 });
      pet.flip = e.x < pet.x; pet.glow = 1;
      break;
    }
    default: break;
  }
  // a hero on a long combo makes the drake breathe twice as often
  const fast = pet.id === 'drake' && world.combo?.n >= 20;
  pet.cd = v.every * (fast ? 0.5 : 1);
}

export function drawPet(renderer, pet, sprites, time) {
  if (!pet) return;
  const ctx = renderer.ctx, s = sprites[pet.pet.sprite];
  if (!s) return;
  const fly = pet.pet.flying;
  const bob = fly ? Math.sin(time * 4 + pet.id.length) * 5 : -Math.abs(Math.sin(pet.hop)) * 5;
  const z = (fly ? pet.z : 0) - bob;
  ctx.fillStyle = 'rgba(12,8,6,0.3)';
  ctx.beginPath(); ctx.ellipse(pet.x, pet.y, s.w * 0.32 * (fly ? 0.7 : 1), 5, 0, 0, Math.PI * 2); ctx.fill();
  if (pet.glow > 0 || pet.id === 'firefly' || pet.id === 'lantern') {
    const g = Math.max(pet.glow, pet.id === 'firefly' || pet.id === 'lantern' ? 0.35 + 0.15 * Math.sin(time * 5) : 0);
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    const gr = ctx.createRadialGradient(pet.x, pet.y - z - s.h * 0.4, 2, pet.x, pet.y - z - s.h * 0.4, 46);
    gr.addColorStop(0, `rgba(255,216,137,${(0.5 * g).toFixed(3)})`); gr.addColorStop(1, 'rgba(255,170,90,0)');
    ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(pet.x, pet.y - z - s.h * 0.4, 46, 0, Math.PI * 2); ctx.fill(); ctx.restore();
  }
  const flap = fly ? 1 + Math.sin(time * 22) * 0.05 : 1;
  renderer.sprite(s, pet.x, pet.y - z, { flip: pet.flip, sx: 0.9 * flap, sy: 0.9 / flap });
}
