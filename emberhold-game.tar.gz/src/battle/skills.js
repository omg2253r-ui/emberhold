// Active skills in battle. Numbers come from data/skills.js via systems/skills.js (slottedSkills).
// Damage goes through world.playerStrike (src 'skill'), so skill-power bonuses and combos apply.

export function createSkillBar(slotted) {
  return slotted.map((s) => (s ? { ...s, cd: 0 } : null));
}

export function tickSkills(bar, dt) {
  for (const s of bar) if (s && s.cd > 0) s.cd = Math.max(0, s.cd - dt);
}

function nearest(world, maxDist) {
  const p = world.player;
  let best = null, bd = maxDist;
  for (const e of world.enemies) {
    if (e.dead || e.spawning > 0) continue;
    const d = Math.hypot(e.x - p.x, e.y - p.y);
    if (d < bd) { bd = d; best = e; }
  }
  return best;
}

// Returns true when the skill fired (false on cooldown / nothing to do).
export function castSkill(bar, index, world) {
  const s = bar[index];
  const p = world.player;
  if (!s || p.dead) return false;
  if (s.cd > 0) { world.sfx('error'); return false; }
  const v = s.v;
  switch (s.id) {
    case 'ember_whirl': {
      for (const e of world.enemies) {
        if (e.dead || e.spawning > 0) continue;
        const d = Math.hypot(e.x - p.x, e.y - p.y);
        if (d > v.radius + e.r) continue;
        const a = Math.atan2(e.y - p.y, e.x - p.x);
        world.playerStrike(e, v.power, { src: 'skill', kx: Math.cos(a) * 320, ky: Math.sin(a) * 320 });
      }
      world.cutProjectiles?.(p.x, p.y - 20, 0, v.radius, Math.PI * 2);
      world.fx.ring(p.x, p.y - 20, 20, v.radius, '#ff8a3d', 0.4, 10);
      world.fx.ring(p.x, p.y - 20, 10, v.radius * 0.8, '#ffd889', 0.3, 6);
      world.particles.burst(p.x, p.y - 24, 36, { color: ['#ff8a3d', '#ffd889', '#c2412f'], speedMin: 160, speedMax: 360, life: 0.45, size: 4, drag: 4, glow: true });
      p.spinT = 0.35;
      world.sfx('crit'); world.shake(5, 0.2); world.hitStop(0.05);
      break;
    }
    case 'fang_lunge': {
      let dir = p.facing;
      const t = nearest(world, 360);
      if (t) dir = Math.atan2(t.y - p.y, t.x - p.x);
      p.lunge = { t: 0.22, dir, speed: v.distance / 0.22, power: v.power, hit: new Set() };
      p.iframes = Math.max(p.iframes, 0.3);
      p.facing = dir; p.flip = Math.cos(dir) < 0;
      world.sfx('dash'); world.sfx('swing', { power: 1.6 });
      break;
    }
    case 'thorn_snare': {
      const t = nearest(world, 420);
      const x = t ? t.x : p.x + Math.cos(p.facing) * 150, y = t ? t.y : p.y + Math.sin(p.facing) * 150;
      world.addSnare({ x, y, r: v.radius, t: 0, dur: v.duration, delay: 0.22, slow: v.slow, power: v.power, struck: false });
      world.sfx('telegraph');
      break;
    }
    case 'hearth_ward': {
      p.shield = Math.round(p.maxHp * v.shieldPct); p.shieldMax = p.shield; p.shieldT = v.duration;
      world.fx.ring(p.x, p.y - 30, 50, 20, '#ffd889', 0.5, 6);
      world.particles.burst(p.x, p.y - 30, 20, { color: ['#ffd889', '#ff8a3d'], speedMin: 30, speedMax: 120, life: 0.7, size: 3, drag: 2, grav: -80, glow: true });
      world.sfx('potion');
      break;
    }
    default: return false;
  }
  s.max = v.cooldown * (p.stats.skillCdMult || 1);
  s.cd = s.max;
  world.onSkillCast?.(s.id);
  return true;
}

// Snare zones: strike once after a short delay, then slow everything inside until they expire.
export function updateSnares(snares, dt, world) {
  for (let i = snares.length - 1; i >= 0; i--) {
    const z = snares[i];
    z.t += dt;
    if (!z.struck && z.t >= z.delay) {
      z.struck = true;
      world.shake(4, 0.15); world.sfx('hit');
      world.particles.burst(z.x, z.y, 22, { color: ['#7da853', '#c9e48e', '#3f612b'], speedMin: 60, speedMax: 220, life: 0.5, size: 4, drag: 3, shape: 1 });
      for (const e of world.enemies) {
        if (e.dead || e.spawning > 0 || Math.hypot(e.x - z.x, e.y - z.y) > z.r + e.r) continue;
        world.playerStrike(e, z.power, { src: 'skill', kx: 0, ky: 0 });
      }
    }
    if (z.struck) for (const e of world.enemies) {
      if (e.dead || Math.hypot(e.x - z.x, e.y - z.y) > z.r + e.r) continue;
      e.slowT = 0.2; e.slowMult = e.type.boss ? Math.min(1, z.slow + 0.3) : z.slow;
    }
    if (z.t >= z.delay + z.dur) snares.splice(i, 1);
  }
}

export function drawSnares(ctx, snares, time) {
  for (const z of snares) {
    const k = Math.min(1, z.t / z.delay);
    const fade = Math.min(1, (z.delay + z.dur - z.t) / 0.4);
    ctx.save();
    ctx.globalAlpha = 0.85 * fade;
    ctx.strokeStyle = z.bloom ? '#8fd06a' : '#3f612b'; ctx.fillStyle = z.bloom ? 'rgba(143,208,106,0.14)' : 'rgba(111,154,74,0.18)'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(z.x, z.y, z.r * k, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    if (z.struck && z.bloom) {
      for (let i = 0; i < 12; i++) {
        const a = (i / 12) * Math.PI * 2 + time * 0.2, rr = z.r * (0.35 + 0.55 * ((i * 37) % 10) / 10);
        const x = z.x + Math.cos(a) * rr, y = z.y + Math.sin(a) * rr * 0.6, b = 4 + 1.5 * Math.sin(time * 3 + i);
        ctx.fillStyle = i % 3 ? '#f3a6c8' : '#fff3c4';
        for (let k = 0; k < 5; k++) { const pa = (k / 5) * Math.PI * 2; ctx.beginPath(); ctx.arc(x + Math.cos(pa) * b, y + Math.sin(pa) * b * 0.7, b * 0.7, 0, Math.PI * 2); ctx.fill(); }
        ctx.fillStyle = '#e0b45a'; ctx.beginPath(); ctx.arc(x, y, b * 0.55, 0, Math.PI * 2); ctx.fill();
      }
    } else if (z.struck) {
      for (let i = 0; i < 10; i++) {
        const a = (i / 10) * Math.PI * 2 + time * 0.3, rr = z.r * (0.4 + 0.5 * ((i * 37) % 10) / 10);
        const x = z.x + Math.cos(a) * rr, y = z.y + Math.sin(a) * rr * 0.6;
        ctx.fillStyle = '#58733a'; ctx.strokeStyle = '#1a120e'; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.moveTo(x - 5, y); ctx.quadraticCurveTo(x - 2, y - 14, x + 1, y - 24); ctx.quadraticCurveTo(x + 3, y - 12, x + 5, y); ctx.closePath(); ctx.fill(); ctx.stroke();
      }
    }
    ctx.restore();
  }
}
