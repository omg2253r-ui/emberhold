// Unique weapon powers — a passive that works on every hit and a signature skill on the charged attack.
// They are deliberately strong in PvE. In PvP every number below is halved (world.pvp), so both players still
// win by reading, guarding and countering rather than by the weapon alone.
//
//   ดาบคู่ราชันมังกร (sovereign) — the secret twin blades
//     passive  "สองพี่น้องมังกร": every 5th landed hit (and every counter) releases a dragon echo: 80% of the
//              hit again on the target and everything within 130 px. Each hit adds a stack of "ลมหายใจราชัน"
//              (+3% damage, up to 10, fades 2.5 s after the last hit). A kill heals 6% max HP.
//     skill    "อัคนิ-นิมิต" (charged attack): two crossing blasts of fire and starlight, 150% each, around the target.
//   เคียวสวรรค์ (judgment) — the Heaven Scythe
//     passive  "ตราพิพากษา": each hit brands the target (max 5). The fifth brand detonates — a holy burst of 220%,
//              always critical, that splashes 110 px.
//     skill    "คำพิพากษาสวรรค์" (charged attack): every brand on every enemy nearby detonates at once (55% per brand).
export const UNIQUES = Object.freeze({
  sovereign: {
    name: 'สองพี่น้องมังกร', skill: 'อัคนิ-นิมิต', color: '#ff5a3a', color2: '#7fe8ff',
    passive: 'ทุกฮิตที่ 5 และทุกเคาน์เตอร์ ปลุกเงามังกรฟันซ้ำ 80% ใส่เป้าและรอบตัว · ทุกฮิตสะสมลมหายใจราชัน +3% ดาเมจ (สูงสุด 10 ชั้น) · ฆ่าศัตรูฟื้น 6% HP',
    skillText: 'ท่าชาร์จปล่อยระเบิดไฟและแสงดาวไขว้กัน 2 ครั้ง ครั้งละ 150%',
  },
  judgment: {
    name: 'ตราพิพากษา', skill: 'คำพิพากษาสวรรค์', color: '#fff3a0', color2: '#f5c35a',
    passive: 'ทุกฮิตประทับตราพิพากษา (สูงสุด 5) ตราที่ 5 ระเบิดแสงศักดิ์สิทธิ์ 220% คริติคอลเสมอ กระจายรอบเป้า',
    skillText: 'ท่าชาร์จจุดระเบิดตราทั้งหมดของศัตรูรอบตัวพร้อมกัน ตราละ 55%',
  },
});
export const PVP_SCALE = 0.5;
export const SOV = Object.freeze({ every: 5, echo: 0.8, echoR: 130, counterEcho: 1.5, stack: 0.03, maxStacks: 10, stackT: 2.5, heal: 0.06, blast: 1.5, blastR: 140 });
export const JUD = Object.freeze({ max: 5, burst: 2.2, burstR: 110, skillPer: 0.55, skillR: 260 });

export const uniqueOf = (p) => (p?.stats?.unique && UNIQUES[p.stats.unique] ? p.stats.unique : null);
const scale = (world) => (world.pvp ? PVP_SCALE : 1);
function state(p) { return (p.uniq ||= { hits: 0, stacks: 0, stackT: 0, skillMove: null }); }

// called every frame (stack decay)
export function tickUnique(p, dt) {
  const u = p.uniq;
  if (!u) return;
  if (u.stackT > 0) { u.stackT -= dt; if (u.stackT <= 0) u.stacks = 0; }
}

// extra damage multiplier for the next hit (sovereign stacks)
export function uniqueDamageMult(p, world) {
  if (uniqueOf(p) !== 'sovereign') return 1;
  return 1 + (p.uniq?.stacks || 0) * SOV.stack * scale(world);
}

function around(world, at, r, also = null) {
  const out = also && !also.dead ? [also] : [];
  for (const t of world.enemies || []) if (t !== also && !t.dead && !t.untargetable && Math.hypot(t.x - at.x, t.y - at.y) <= r + (t.r || 20)) out.push(t);
  return out;
}
const strikeAll = (world, list, power, o = {}) => { for (const t of list) world.playerStrike(t, power, { ...o, src: 'unique' }); };

// After a landed hit. o: the hit options; returns nothing. Never recurses (its own hits are src 'unique').
export function uniqueAfterHit(world, p, e, o = {}) {
  const id = uniqueOf(p);
  if (!id || !e || o.src === 'unique' || o.src === 'burn' || o.src === 'pet') return;
  const k = scale(world), u = state(p);
  const charged = p.move?.kind === 'charged' && u.skillMove !== p.move;
  if (charged) u.skillMove = p.move;
  if (id === 'sovereign') {
    u.stacks = Math.min(SOV.maxStacks, u.stacks + 1); u.stackT = SOV.stackT;
    u.hits += 1;
    if (u.hits % SOV.every === 0 || o.counter) {
      const list = around(world, e, SOV.echoR, e);
      strikeAll(world, list, SOV.echo * k * (o.counter ? SOV.counterEcho : 1));
      world.fx?.ring(e.x, e.y - 30, 14, SOV.echoR, '#ff5a3a', 0.4, 6);
      world.fx?.ring(e.x, e.y - 30, 8, SOV.echoR * 0.8, '#7fe8ff', 0.5, 4);
      world.particles?.burst(e.x, e.y - 30, 18, { color: ['#ff5a3a', '#ffcf5a', '#7fe8ff', '#ffffff'], speedMin: 140, speedMax: 380, life: 0.4, size: 3, drag: 4, glow: true });
      world.sfx?.('crit');
    }
    if (charged) {
      for (const [dx, col] of [[-36, '#ff5a3a'], [36, '#7fe8ff']]) {
        const at = { x: e.x + dx, y: e.y };
        strikeAll(world, around(world, at, SOV.blastR, e), SOV.blast * k, { forceCrit: false });
        world.fx?.ring(at.x, at.y - 30, 16, SOV.blastR, col, 0.5, 8);
      }
      world.fx?.callout(p.x, p.y - 140, UNIQUES.sovereign.skill, '#ffcf5a');
      world.shake?.(7, 0.25);
    }
  } else if (id === 'judgment') {
    if (charged) {
      // detonate every brand nearby
      let n = 0;
      for (const t of around(world, p, JUD.skillR, e)) {
        const b = t.brand || 0;
        if (b <= 0) continue;
        t.brand = 0; n += b;
        world.playerStrike(t, JUD.skillPer * b * k, { src: 'unique', forceCrit: true });
        world.fx?.ring(t.x, t.y - 30, 10, 90, '#fff3a0', 0.45, 6);
      }
      if (n) { world.fx?.callout(p.x, p.y - 140, UNIQUES.judgment.skill, '#fff3a0'); world.shake?.(6, 0.22); world.sfx?.('perfect'); }
      return;
    }
    e.brand = Math.min(JUD.max, (e.brand || 0) + 1); e.brandT = 6;
    if (e.brand >= JUD.max) {
      e.brand = 0;
      strikeAll(world, around(world, e, JUD.burstR, e), JUD.burst * k, { forceCrit: true });
      world.fx?.ring(e.x, e.y - 30, 12, JUD.burstR, '#fff3a0', 0.5, 8);
      world.particles?.burst(e.x, e.y - 40, 22, { color: ['#ffffff', '#fff3a0', '#f5c35a'], speedMin: 160, speedMax: 420, life: 0.45, size: 3, drag: 4, glow: true });
      world.fx?.callout(e.x, e.y - (e.r || 30) * 2 - 30, 'พิพากษา!', '#fff3a0');
      world.sfx?.('crit');
    }
  }
}

export function uniqueOnKill(p, world) {
  if (uniqueOf(p) !== 'sovereign' || p.dead) return 0;
  const heal = Math.round(p.maxHp * SOV.heal * scale(world));
  p.hp = Math.min(p.maxHp, p.hp + heal);
  return heal;
}

// brands drawn over a target (small golden pips) and the sovereign stack ring around the hero
export function drawBrands(ctx, e, time) {
  if (!(e.brand > 0)) return;
  const y = e.y - (e.r || 24) * 2 - 22;
  for (let i = 0; i < e.brand; i++) {
    const x = e.x + (i - (e.brand - 1) / 2) * 11;
    ctx.fillStyle = '#1a120a'; ctx.beginPath(); ctx.arc(x, y, 4.6, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = i === 4 ? '#ffffff' : '#fff3a0'; ctx.beginPath(); ctx.moveTo(x, y - 3.6); ctx.lineTo(x + 3.2, y); ctx.lineTo(x, y + 3.6); ctx.lineTo(x - 3.2, y); ctx.closePath(); ctx.fill();
  }
}
export function drawUniqueAura(ctx, p, time) {
  const id = uniqueOf(p);
  if (!id) return;
  const u = p.uniq;
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  if (id === 'sovereign' && u?.stacks) {
    const k = u.stacks / SOV.maxStacks;
    for (let i = 0; i < u.stacks; i++) {
      const a = time * 2.4 + (i / SOV.maxStacks) * Math.PI * 2;
      ctx.fillStyle = i % 2 ? 'rgba(127,232,255,0.8)' : 'rgba(255,90,58,0.8)';
      ctx.beginPath(); ctx.arc(p.x + Math.cos(a) * 34, p.y - 8 + Math.sin(a) * 12, 2.4 + k, 0, Math.PI * 2); ctx.fill();
    }
  } else if (id === 'judgment') {
    ctx.strokeStyle = `rgba(255,243,160,${(0.25 + 0.15 * Math.sin(time * 3)).toFixed(3)})`; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.ellipse(p.x, p.y - 96, 14, 4, 0, 0, Math.PI * 2); ctx.stroke();
  }
  ctx.restore();
}

// Artifact "debuff": a landed hit may sunder the enemy (it deals 20% less and moves slower for 3 s).
export const SUNDER = Object.freeze({ t: 3, dmg: 0.8, slow: 0.7 });
export function trySunder(p, e, rng, o = {}) {
  const ch = p.stats?.debuff || 0;
  if (!ch || !e || e.dead || o.src === 'burn' || o.src === 'pet' || o.src === 'unique' || rng.next() >= ch) return false;
  e.sunderT = SUNDER.t;
  if (!e.type?.boss) { e.slowMult = e.slowT > 0 ? Math.min(e.slowMult ?? 1, SUNDER.slow) : SUNDER.slow; e.slowT = Math.max(e.slowT || 0, SUNDER.t); }
  return true;
}
export const sunderMult = (e) => (e && e.sunderT > 0 ? SUNDER.dmg : 1);
// Artifact shield at the start of a room / wave.
export function roomShield(p) {
  const pct = p.stats?.shieldPct || 0;
  if (pct <= 0 || p.dead) return 0;
  p.shield = Math.max(p.shield || 0, Math.round(p.maxHp * pct)); p.shieldMax = Math.max(p.shieldMax || 0, p.shield); p.shieldT = 9999;
  return p.shield;
}
