// Every tunable number lives here. Systems read from this file instead of using magic numbers.

export const BALANCE = Object.freeze({
  player: {
    baseHp: 100, hpPerLevel: 12,
    baseAtk: 6, atkPerLevel: 1.5,
    baseDef: 2, defPerLevel: 0.8,
    baseSpeed: 230,            // world px / second
    baseCrit: 0.05,
    baseCritMult: 1.5,
    maxLevel: 30,
    xpCurveBase: 40, xpCurveExp: 1.4,
    radius: 20,
  },
  combat: {
    defenseK: 30,              // damage multiplier = K / (K + def)
    variance: 0.1,             // +/- 10%
    minDamage: 1,
    critChanceCap: 0.75,
    // Weapon movesets live in data/weapons.js. comboWindow = time after a move ends in which the next tap continues the chain.
    attack: { comboWindow: 0.62, branchDelay: 0.2, chargeDelay: 0.16, dashAttackWindow: 0.28 },
    // Dodge: charges refill one at a time. A hit that lands in the first `perfectWindow` seconds of a dodge = perfect dodge.
    dash: { duration: 0.18, speedMult: 3.1, cooldown: 1.1, charges: 2, perfectWindow: 0.16, blinkDuration: 0.12, blinkSpeedMult: 3.9 },
    perfect: { slowmo: 0.55, timeScale: 0.3, empowerT: 2.5, empowerPower: 0.3 },
    // Chain hits without getting hurt; the counter resets after `resetAfter` seconds without a hit.
    combo: { resetAfter: 3, tiers: [{ at: 10, bonus: 0.05 }, { at: 25, bonus: 0.1 }, { at: 50, bonus: 0.2 }] },
    // Bosses have poise: hits wear it down (perHit × move power); at zero the boss is stunned and takes extra damage.
    poise: { max: 100, perHit: 7, regenDelay: 2.5, regenRate: 14, breakStun: 2.2, breakBonus: 0.3 },
    burn: { ticks: 4, interval: 0.5, power: 0.12 },
    hurtIFrames: 0.6,
    potion: { healPct: 0.35, cooldown: 6 },
    autoAimRange: 280,
  },
  inventory: { capacity: 30, maxStack: 99 },
  pickup: { magnetRadius: 90, collectRadius: 26, flySpeed: 620 },
  upgrade: {
    maxLevel: 10,
    statGrowthPerLevel: 0.12,                     // +12% of base stats per level
    successRate: [1, 1, 1, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.35], // index = current level
    goldBase: { common: 30, uncommon: 50, rare: 80, epic: 130, legendary: 200, mythic: 320 },
    goldGrowth: 0.6,                               // cost *= 1 + L * growth
    // Materials by current level band. qty grows with level inside the band.
    materials: [
      { minLevel: 0, maxLevel: 3, items: [{ id: 'm_iron_shard', base: 2, perLevel: 1 }] },
      { minLevel: 4, maxLevel: 6, items: [{ id: 'm_iron_shard', base: 4, perLevel: 1 }, { id: 'm_beast_hide', base: 1, perLevel: 1 }] },
      { minLevel: 7, maxLevel: 9, items: [{ id: 'm_iron_shard', base: 6, perLevel: 1 }, { id: 'm_beast_hide', base: 3, perLevel: 1 }, { id: 'm_thorn_core', base: 1, perLevel: 0 }] },
    ],
  },
  economy: {
    sellEquipBase: { common: 8, uncommon: 30, rare: 75, epic: 160, legendary: 300, mythic: 900 },
    sellUpgradeBonus: 0.5,     // sell price *= 1 + lvl * bonus
  },
  firstClearBonusGold: 100,
  // Amber Sparks (pet summons). Boss kills give the `sparks` listed on the enemy.
  sparks: { chest: { small: 1, key: 2, rare: 3 }, loreFirst: 2, firstClear: 10 },
});

export function xpToNext(level) {
  const p = BALANCE.player;
  return Math.round(p.xpCurveBase * Math.pow(level, p.xpCurveExp));
}
