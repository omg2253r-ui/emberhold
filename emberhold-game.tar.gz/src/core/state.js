// The canonical game state shape. Everything shown in the UI is derived from this object.
import { BALANCE } from '../config/balance.js';
import { SKILL_SLOTS } from '../data/skills.js';

export const SAVE_VERSION = 5;
export const START_SPARKS = 10; // enough for one free pet summon
export const HERO_NAME_MAX = 16;
export const DEFAULT_HERO_NAME = 'นักล่า';

export function createNewState(now = Date.now()) {
  return {
    version: SAVE_VERSION,
    createdAt: now,
    updatedAt: now,
    nextUid: 4,
    gold: 60,
    player: { level: 1, xp: 0 },
    equipment: {
      weapon: { uid: 1, id: 'w_rust_blade', qty: 1, lvl: 0 },
      armor:  { uid: 2, id: 'a_cloth_wrap', qty: 1, lvl: 0 },
      charm:  null,
    },
    inventory: {
      capacity: BALANCE.inventory.capacity,
      slots: [{ uid: 3, id: 'p_tonic', qty: 2, lvl: 0 }],
    },
    progress: { cleared: {}, clears: {} },
    stats: { kills: 0, runs: 0, upgradesWon: 0, upgradesLost: 0 },
    settings: { sfx: 0.8, music: 0.45, shake: true },
    skills: { ranks: {}, slots: new Array(SKILL_SLOTS).fill(null) },
    story: { name: DEFAULT_HERO_NAME, flags: {}, seen: {}, lore: {} },
    race: { id: null, rolls: 0 },                       // v3: bloodline (null until the awakening)
    sparks: START_SPARKS,                                // v3: Amber Sparks, the pet-summon currency
    pets: { owned: {}, active: null, pity: 0, summons: 0 },
    social: { friends: {} },                            // v4: friends by account id → { name, at }
    pvp: { wins: 0, losses: 0 },                        // v4: duel record
    zones: { cleared: {}, best: {} },                    // v5: online zones cleared (count) and best time (s)
    guild: null,                                         // v5: { id, name, tag } of my guild (the guild itself is a shared document)
  };
}

// Hero name typed by the player: trimmed, control characters removed, length capped. Rendered with textContent only.
export function cleanHeroName(raw) {
  const s = String(raw ?? '').replace(/[\u0000-\u001f\u007f<>]/g, '').replace(/\s+/g, ' ').trim();
  return Array.from(s).slice(0, HERO_NAME_MAX).join('') || DEFAULT_HERO_NAME;
}

// Deep copy used by every transaction so a failed operation never touches the original.
export function cloneState(state) {
  return typeof structuredClone === 'function' ? structuredClone(state) : JSON.parse(JSON.stringify(state));
}

export function takeUid(state) {
  const uid = state.nextUid;
  state.nextUid += 1;
  return uid;
}
