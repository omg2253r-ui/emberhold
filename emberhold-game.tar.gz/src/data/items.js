// Item definitions. `id` is the stable key; `name` is display only.
// category: weapon | armor | charm | material | consumable
// stats keys: atk, def, hp, crit, critMult, spd (spd is a fraction, 0.05 = +5% move speed)
// art: key used by src/art/icons.js to draw the icon (and the in-game weapon sprite).
// wtype (weapons only): moveset from src/data/weapons.js — sword | katana | dagger | greatsword | staff | bow | spear

export const ITEMS = Object.freeze({
  // ---- weapons
  w_rust_blade:   { id: 'w_rust_blade', wtype: 'sword',   name: 'ดาบสนิมเก่า',       category: 'weapon', rarity: 'common',   stats: { atk: 8, crit: 0.03 },
                    art: { kind: 'blade', blade: '#a9a39a', edge: '#d7d1c4', guard: '#6d4a2c', grip: '#3b2a20' },
                    desc: 'ดาบเก่าที่ยังคมพอจะใช้ล่าได้' },
  w_hunter_saber: { id: 'w_hunter_saber', wtype: 'sword', name: 'ดาบนายพราน',        category: 'weapon', rarity: 'uncommon', stats: { atk: 13, crit: 0.05 },
                    art: { kind: 'saber', blade: '#c7ccd1', edge: '#f1f3f4', guard: '#b07a2e', grip: '#4a2f22' },
                    desc: 'ดาบโค้งเบามือ ฟันได้ไว' },
  w_thorn_edge:   { id: 'w_thorn_edge', wtype: 'sword',   name: 'ดาบคมหนาม',         category: 'weapon', rarity: 'rare',     stats: { atk: 19, crit: 0.08 },
                    art: { kind: 'thorn', blade: '#6f9a5b', edge: '#cfe3a8', guard: '#5a3a24', grip: '#2e2019' },
                    desc: 'หล่อจากหนามของหมูป่าหลังหนาม' },
  w_ember_fang:   { id: 'w_ember_fang', wtype: 'sword',   name: 'เขี้ยวอัคคี',         category: 'weapon', rarity: 'epic',     stats: { atk: 27, crit: 0.10, critMult: 0.2 },
                    art: { kind: 'fang', blade: '#c4492e', edge: '#ffc979', guard: '#2a1a14', grip: '#1c1210', glow: '#ff8a3d' },
                    desc: 'ยังอุ่นอยู่เสมอ แม้ในคืนที่หนาวที่สุด' },

  // ---- katana (ดาบซามูไร): fast 4-hit combo, charged iai dash
  w_ronin_katana:   { id: 'w_ronin_katana', wtype: 'katana', name: 'ดาบซามูไรพเนจร', category: 'weapon', rarity: 'uncommon', stats: { atk: 12, crit: 0.08 },
                      art: { kind: 'katana', blade: '#c9cfd6', edge: '#f4f6f8', guard: '#2a1a14', grip: '#6e2a22', wrap: '#e8d9b8' }, desc: 'คมบางเบา ชักออกจากฝักได้ในพริบตา' },
  w_mist_katana:    { id: 'w_mist_katana', wtype: 'katana', name: 'ดาบซามูไรสายหมอก', category: 'weapon', rarity: 'rare', stats: { atk: 17, crit: 0.12 },
                      art: { kind: 'katana', blade: '#b9d3d9', edge: '#f0fbff', guard: '#3a4a50', grip: '#24323a', wrap: '#9fc4cc' }, desc: 'ใบดาบเย็นเฉียบเหมือนหมอกยามเช้า' },
  w_moonfall_katana:{ id: 'w_moonfall_katana', wtype: 'katana', name: 'จันทร์ร่วง', category: 'weapon', rarity: 'epic', stats: { atk: 24, crit: 0.15, critMult: 0.25 },
                      art: { kind: 'katana', blade: '#dcd6ff', edge: '#ffffff', guard: '#e0b45a', grip: '#1c1430', wrap: '#7a62c8', glow: '#b9a8ff' }, desc: 'ว่ากันว่าฟันแสงจันทร์ให้ขาดได้' },
  // ---- dagger (ดาบเล็กคู่): 5-hit flurry, dodge-cancel anytime, backstab after a dodge
  w_twin_fangs:     { id: 'w_twin_fangs', wtype: 'dagger', name: 'มีดคู่เขี้ยวงู', category: 'weapon', rarity: 'uncommon', stats: { atk: 10, crit: 0.12 },
                      art: { kind: 'dagger', blade: '#b8bcc0', edge: '#eef0f2', guard: '#7a5a3c', grip: '#3b2a20' }, desc: 'สั้น เร็ว และไม่เคยปล่อยให้เหยื่อตั้งตัว' },
  w_venom_daggers:  { id: 'w_venom_daggers', wtype: 'dagger', name: 'มีดคู่หนามพิษ', category: 'weapon', rarity: 'rare', stats: { atk: 15, crit: 0.16 },
                      art: { kind: 'dagger', blade: '#7fae5c', edge: '#d6f0a8', guard: '#3a2a20', grip: '#2a1d16' }, desc: 'ปลายมีดชุบยางหนาม แผลจะชาไปครึ่งวัน' },
  w_cinder_talons:  { id: 'w_cinder_talons', wtype: 'dagger', name: 'กรงเล็บถ่าน', category: 'weapon', rarity: 'epic', stats: { atk: 21, crit: 0.2, critMult: 0.3 },
                      art: { kind: 'dagger', blade: '#d0532f', edge: '#ffd08a', guard: '#2a1a14', grip: '#1c1210', glow: '#ff8a3d' }, desc: 'ร้อนจนอากาศรอบคมบิดเบี้ยว' },
  // ---- greatsword (ดาบใหญ่): slow, huge arcs, cannot be knocked back mid-swing
  w_iron_cleaver:   { id: 'w_iron_cleaver', wtype: 'greatsword', name: 'ดาบใหญ่เหล็กทุบ', category: 'weapon', rarity: 'uncommon', stats: { atk: 16, def: 2 },
                      art: { kind: 'greatsword', blade: '#9ea4a8', edge: '#dfe3e6', guard: '#5a3a24', grip: '#3b2a20' }, desc: 'หนักจนต้องใช้สองมือ แต่ฟันทีเดียวเกลี้ยงลาน' },
  w_boar_breaker:   { id: 'w_boar_breaker', wtype: 'greatsword', name: 'ดาบใหญ่ทลายหมูป่า', category: 'weapon', rarity: 'rare', stats: { atk: 23, def: 3 },
                      art: { kind: 'greatsword', blade: '#7d8a5a', edge: '#d2e2a0', guard: '#6e4a30', grip: '#2e2019' }, desc: 'ตีจากหนามหลังของหมูป่า ยิ่งตียิ่งแข็ง' },
  w_furnace_cleaver:{ id: 'w_furnace_cleaver', wtype: 'greatsword', name: 'ดาบใหญ่เตาหลอม', category: 'weapon', rarity: 'epic', stats: { atk: 32, def: 5, hp: 20 },
                      art: { kind: 'greatsword', blade: '#4a3a34', edge: '#ff9a4a', guard: '#2a1a14', grip: '#1c1210', glow: '#ff8a3d' }, desc: 'แกนกลางยังคุไฟจากเตาหลอมลับ' },
  // ---- staff (คทาเวท): bolts, nova finisher, charged meteor, blink dodge
  w_ash_staff:      { id: 'w_ash_staff', wtype: 'staff', name: 'คทาไม้เถ้า', category: 'weapon', rarity: 'uncommon', stats: { atk: 13, hp: 10 },
                      art: { kind: 'staff', wood: '#7a5a3c', orb: '#ffb35a', trim: '#e0b45a' }, desc: 'ไม้จากต้นที่รอดจากคืนเถ้าถล่ม' },
  w_thorn_rod:      { id: 'w_thorn_rod', wtype: 'staff', name: 'คทาหนามมรกต', category: 'weapon', rarity: 'rare', stats: { atk: 19, hp: 15, crit: 0.05 },
                      art: { kind: 'staff', wood: '#4b6e33', orb: '#9fe27a', trim: '#cfe3a8' }, desc: 'เถาหนามพันรอบหินที่เรืองแสงสีเขียว' },
  w_ember_scepter:  { id: 'w_ember_scepter', wtype: 'staff', name: 'คทาอัคคีโบราณ', category: 'weapon', rarity: 'epic', stats: { atk: 27, crit: 0.08, critMult: 0.2 },
                      art: { kind: 'staff', wood: '#2a1a14', orb: '#ff6a2a', trim: '#e0b45a', glow: '#ffd08a' }, desc: 'ช่างของดาวเคยใช้มันจุดเตาหลอมทั้งเหมือง' },
  // ---- bow (ธนู): ranged, 3rd shot is a piercing volley, charged power shot
  w_hunter_bow:     { id: 'w_hunter_bow', wtype: 'bow', name: 'ธนูนายพราน', category: 'weapon', rarity: 'uncommon', stats: { atk: 12, spd: 0.03 },
                      art: { kind: 'bow', wood: '#8a5a36', string: '#efe2c4', trim: '#d9a84e' }, desc: 'คันธนูไม้ไผ่ดัดไฟ เบาและแม่นยำ' },
  w_thornstring_bow:{ id: 'w_thornstring_bow', wtype: 'bow', name: 'ธนูสายหนาม', category: 'weapon', rarity: 'rare', stats: { atk: 17, spd: 0.04, crit: 0.06 },
                      art: { kind: 'bow', wood: '#4b6e33', string: '#cfe3a8', trim: '#a3c46c' }, desc: 'สายธนูทำจากเถาหนามที่ไม่มีวันขาด' },
  w_sunfire_bow:    { id: 'w_sunfire_bow', wtype: 'bow', name: 'ธนูสุริยะถ่าน', category: 'weapon', rarity: 'epic', stats: { atk: 24, crit: 0.1, spd: 0.05 },
                      art: { kind: 'bow', wood: '#2a1a14', string: '#ffd08a', trim: '#e0b45a', glow: '#ff8a3d' }, desc: 'ลูกศรที่ยิงออกไปลุกเป็นไฟกลางอากาศ' },
  // ---- spear (หอก): long thrusts, wide sweep finisher, charged piercing rush
  w_boar_spear:     { id: 'w_boar_spear', wtype: 'spear', name: 'หอกล่าหมูป่า', category: 'weapon', rarity: 'uncommon', stats: { atk: 13, def: 1 },
                      art: { kind: 'spear', shaft: '#8a5a36', head: '#b8bcc0', edge: '#eef0f2', trim: '#b8382a' }, desc: 'ยาวพอจะแทงก่อนเขี้ยวหมูป่าจะถึงตัว' },
  w_thorn_pike:     { id: 'w_thorn_pike', wtype: 'spear', name: 'หอกยาวหนาม', category: 'weapon', rarity: 'rare', stats: { atk: 19, def: 2 },
                      art: { kind: 'spear', shaft: '#4a3a24', head: '#7fae5c', edge: '#d6f0a8', trim: '#a3c46c' }, desc: 'ปลายหอกแตกเป็นหนามสามแฉก' },
  w_ember_glaive:   { id: 'w_ember_glaive', wtype: 'spear', name: 'ง้าวอัคคี', category: 'weapon', rarity: 'epic', stats: { atk: 27, crit: 0.06 },
                      art: { kind: 'spear', shaft: '#2a1a14', head: '#d0532f', edge: '#ffd08a', trim: '#e0b45a', glow: '#ff8a3d' }, desc: 'ใบง้าวโค้งเหมือนเปลวไฟที่ถูกแช่แข็ง' },

  // ---- armor
  a_cloth_wrap:   { id: 'a_cloth_wrap',   name: 'ผ้าคลุมเดินป่า',      category: 'armor', rarity: 'common',   stats: { def: 4, hp: 20 },
                    art: { kind: 'cloak', main: '#3f6b67', trim: '#b8382a' }, desc: 'กันลม กันหนาม ได้บ้าง' },
  a_hide_vest:    { id: 'a_hide_vest',    name: 'เสื้อหนังสัตว์',      category: 'armor', rarity: 'uncommon', stats: { def: 8, hp: 35 },
                    art: { kind: 'vest', main: '#8a5a36', trim: '#d9a84e' }, desc: 'หนังหนาเย็บสองชั้น' },
  a_bark_mail:    { id: 'a_bark_mail',    name: 'เกราะเปลือกไม้หนาม',  category: 'armor', rarity: 'rare',     stats: { def: 13, hp: 55 },
                    art: { kind: 'bark', main: '#5d6b3a', trim: '#a3c46c' }, desc: 'เปลือกไม้แข็งที่ฟื้นตัวเองได้ช้าๆ' },
  a_lacquer_plate:{ id: 'a_lacquer_plate',name: 'เกราะรักดำ',          category: 'armor', rarity: 'epic',     stats: { def: 19, hp: 80, atk: 3 },
                    art: { kind: 'plate', main: '#231a17', trim: '#e0b45a' }, desc: 'ลงรักเก้าชั้น ปิดทองลายกนก' },

  // ---- charms
  c_moss_bead:    { id: 'c_moss_bead',    name: 'ลูกปัดมอส',           category: 'charm', rarity: 'uncommon', stats: { hp: 25, spd: 0.05 },
                    art: { kind: 'bead', main: '#6aa25a', trim: '#2e4a2a' }, desc: 'กลิ่นป่าหลังฝน ทำให้ก้าวเบา' },
  c_boar_tusk:    { id: 'c_boar_tusk',    name: 'เครื่องรางเขี้ยวหมูป่า', category: 'charm', rarity: 'rare',     stats: { crit: 0.08, critMult: 0.3 },
                    art: { kind: 'tusk', main: '#efe2c4', trim: '#8a3a2a' }, desc: 'เขี้ยวที่ไม่เคยหัก' },
  c_cinder_eye:   { id: 'c_cinder_eye',   name: 'ดวงตาถ่านแดง',        category: 'charm', rarity: 'epic',     stats: { atk: 6, crit: 0.1, critMult: 0.4 },
                    art: { kind: 'eye', main: '#ff7a33', trim: '#2a1a14' }, desc: 'มองเห็นจุดอ่อนในเปลวไฟ' },

  // ---- materials
  m_iron_shard:   { id: 'm_iron_shard',   name: 'เศษเหล็ก',            category: 'material', rarity: 'common',   sellPrice: 6,
                    art: { kind: 'shard', main: '#9aa3ad' }, desc: 'วัตถุดิบตีบวกขั้นพื้นฐาน' },
  m_beast_hide:   { id: 'm_beast_hide',   name: 'หนังสัตว์',           category: 'material', rarity: 'common',   sellPrice: 8,
                    art: { kind: 'hide', main: '#9b6a43' }, desc: 'ใช้ตีบวกตั้งแต่ +4 ขึ้นไป' },
  m_thorn_core:   { id: 'm_thorn_core',   name: 'แก่นหนาม',            category: 'material', rarity: 'rare',     sellPrice: 40,
                    art: { kind: 'core', main: '#7dbb5a', glow: '#d6f59a' }, desc: 'จำเป็นสำหรับตีบวกตั้งแต่ +7' },
  m_bloodstone:   { id: 'm_bloodstone',   name: 'ศิลาเปลี่ยนสายเลือด',  category: 'material', rarity: 'epic', special: 'reroll',
                    art: { kind: 'bloodstone', main: '#a8323a', glow: '#ff9a7a' }, desc: 'ได้จากบอสเท่านั้น ใช้สุ่มเผ่าใหม่ในแท็บสายเลือด (ขายไม่ได้)' },
  m_ember_core:   { id: 'm_ember_core',   name: 'แก่นถ่านอัคคี',        category: 'material', rarity: 'rare',     sellPrice: 55,
                    art: { kind: 'core', main: '#e0592f', glow: '#ffd08a' }, desc: 'ร้อนจนวางบนมือเปล่าไม่ได้' },

  // ---- legendary: one per online-zone boss (src/data/zones.js)
  w_tempest_saber:   { id: 'w_tempest_saber', wtype: 'sword', name: 'ดาบพายุราชันนก', category: 'weapon', rarity: 'legendary', stats: { atk: 36, crit: 0.12, critMult: 0.3, spd: 0.04 },
                       art: { kind: 'saber', blade: '#d9e8f6', edge: '#ffffff', guard: '#f5d48a', grip: '#34465e', glow: '#bfe3ff' }, desc: 'ขนนกพายุพันรอบด้าม ฟันแล้วลมตาม' },
  w_glacier_fang:    { id: 'w_glacier_fang', wtype: 'katana', name: 'เขี้ยวธารน้ำแข็ง', category: 'weapon', rarity: 'legendary', stats: { atk: 32, crit: 0.2, critMult: 0.35 },
                       art: { kind: 'katana', blade: '#bfe8ff', edge: '#ffffff', guard: '#2f5a80', grip: '#1a2a3a', wrap: '#e8f8ff', glow: '#bfe8ff' }, desc: 'เย็นจนอากาศรอบใบดาบกลายเป็นเกล็ด' },
  w_hydra_kiss:      { id: 'w_hydra_kiss', wtype: 'dagger', name: 'จุมพิตไฮดรา', category: 'weapon', rarity: 'legendary', stats: { atk: 28, crit: 0.25, critMult: 0.4 },
                       art: { kind: 'dagger', blade: '#b8e08a', edge: '#e8ff9a', guard: '#5a2f78', grip: '#24401e', glow: '#c27ff0' }, desc: 'สามคม สามพิษ ไม่มีใครได้แผลเดียว' },
  w_umbral_greatblade:{ id: 'w_umbral_greatblade', wtype: 'greatsword', name: 'มหาดาบจันทร์ดับ', category: 'weapon', rarity: 'legendary', stats: { atk: 42, def: 7, hp: 40 },
                       art: { kind: 'greatsword', blade: '#5a4f80', edge: '#e0b0ff', guard: '#2a2438', grip: '#0e0b16', glow: '#c27ff0' }, desc: 'ใบดาบดูดแสงรอบตัวจนมืดสนิท' },
  w_sunspire_staff:  { id: 'w_sunspire_staff', wtype: 'staff', name: 'คทายอดสุริยะ', category: 'weapon', rarity: 'legendary', stats: { atk: 36, crit: 0.1, critMult: 0.3 },
                       art: { kind: 'staff', wood: '#c8a46a', orb: '#7fe8ff', trim: '#f3dca0' }, desc: 'ดวงตาที่สามของสฟิงซ์ยังมองเห็นอยู่' },
  w_sporebloom_bow:  { id: 'w_sporebloom_bow', wtype: 'bow', name: 'ธนูบุปผาสปอร์', category: 'weapon', rarity: 'legendary', stats: { atk: 32, crit: 0.12, spd: 0.06 },
                       art: { kind: 'bow', wood: '#6a3a8a', string: '#9fffd8', trim: '#f0d0ff' }, desc: 'สายธนูเรืองแสงในความมืด' },
  w_thunder_lance:   { id: 'w_thunder_lance', wtype: 'spear', name: 'ทวนอัสนี', category: 'weapon', rarity: 'legendary', stats: { atk: 36, crit: 0.1, spd: 0.03 },
                       art: { kind: 'spear', shaft: '#4a5a70', head: '#ffe65a', edge: '#fff9c4', trim: '#7fe8ff' }, desc: 'ปลายทวนมีประกายไฟฟ้าวิ่งตลอดเวลา' },
  a_drakescale:      { id: 'a_drakescale', name: 'เกราะเกล็ดมังกรรอยแยก', category: 'armor', rarity: 'legendary', stats: { def: 26, hp: 110, atk: 5 },
                       art: { kind: 'plate', main: '#5a1a14', trim: '#ffb35a' }, desc: 'เกล็ดที่ไม่เคยไหม้แม้ในลาวา' },
  c_seraph_feather:  { id: 'c_seraph_feather', name: 'ขนนกเทวะ', category: 'charm', rarity: 'legendary', stats: { hp: 40, crit: 0.12, critMult: 0.5 },
                       art: { kind: 'bead', main: '#fff3c4', trim: '#e0b45a' }, desc: 'อุ่นเหมือนแสงแรกของวัน' },
  c_ember_crown:     { id: 'c_ember_crown', name: 'มงกุฎเถ้าถ่าน', category: 'charm', rarity: 'legendary', stats: { atk: 10, crit: 0.14, critMult: 0.6 },
                       art: { kind: 'eye', main: '#ff8a3d', trim: '#3a2a24' }, desc: 'มงกุฎของผู้ที่เผาป่าอำพัน ยังคุอยู่ข้างใน' },

  // ---- consumables
  p_tonic:        { id: 'p_tonic',        name: 'ยาฟื้นพลัง',           category: 'consumable', rarity: 'common', sellPrice: 10,
                    art: { kind: 'potion', main: '#c93a2e' }, desc: 'ฟื้นพลังชีวิต 35% ใช้ระหว่างต่อสู้ (Q)' },
});

export const EQUIP_SLOTS = Object.freeze(['weapon', 'armor', 'charm']);
export const SLOT_NAMES = Object.freeze({ weapon: 'อาวุธ', armor: 'ชุดเกราะ', charm: 'เครื่องราง' });
export const STAT_NAMES = Object.freeze({ atk: 'พลังโจมตี', def: 'ป้องกัน', hp: 'พลังชีวิต', crit: 'โอกาสคริติคอล', critMult: 'แรงคริติคอล', spd: 'ความเร็ว' });

export function getItem(id) {
  return Object.prototype.hasOwnProperty.call(ITEMS, id) ? ITEMS[id] : null;
}

export function isEquipment(def) {
  return !!def && (def.category === 'weapon' || def.category === 'armor' || def.category === 'charm');
}

export function isStackable(def) {
  return !!def && (def.category === 'material' || def.category === 'consumable');
}
