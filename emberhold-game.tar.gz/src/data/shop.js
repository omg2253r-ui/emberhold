// What the camp merchant sells. Prices are in gold. `requires` = stage id that must be cleared.
export const SHOP_STOCK = Object.freeze([
  { itemId: 'p_tonic',        price: 30 },
  { itemId: 'm_iron_shard',   price: 18 },
  { itemId: 'm_beast_hide',   price: 24 },
  { itemId: 'w_hunter_saber', price: 220 },
  { itemId: 'w_ronin_katana', price: 220 },
  { itemId: 'w_twin_fangs',   price: 220 },
  { itemId: 'w_iron_cleaver', price: 240 },
  { itemId: 'w_ash_staff',    price: 230 },
  { itemId: 'w_hunter_bow',   price: 230 },
  { itemId: 'w_boar_spear',   price: 220 },
  { itemId: 'a_hide_vest',    price: 240 },
  { itemId: 'c_moss_bead',    price: 260, requires: 's1' },
  { itemId: 'm_thorn_core',   price: 160, requires: 's2' },
]);
