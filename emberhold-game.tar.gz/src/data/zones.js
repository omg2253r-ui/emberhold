// The ten online zones (ดันเจี้ยนรวม): each has its own ground, a zone mechanic that changes how you move and dodge,
// two monsters with their own attack patterns, and a boss. Runs are 3 rooms: two fight rooms and the boss room.
// Up to 4 players go in together (or one alone); enemy HP grows with the party size.
//
// Enemy stats come from the zone level (zoneStats) times per-monster multipliers, so balance lives in one place.

export const ZONE_ROOM = Object.freeze({ w: 1240, h: 820, wall: 60 });
export const PARTY_HP_SCALE = 0.6;     // +60% enemy HP per extra player

// Base numbers for a normal monster at zone level L (a boss multiplies these).
export function zoneStats(level) {
  return { hp: 34 + level * 9, atk: 9 + level * 1.7, def: 2 + level * 0.65, xp: 6 + level * 2.2, gold: [4 + level, 8 + level * 2] };
}

// Shared drop pools by tier (0..3). Existing items only, plus each boss's own legendary.
const MAT = [
  [{ id: 'm_iron_shard', weight: 6, qty: [1, 3] }, { id: 'm_beast_hide', weight: 3, qty: [1, 2] }, { id: 'p_tonic', weight: 1, qty: [1, 1] }],
  [{ id: 'm_iron_shard', weight: 5, qty: [2, 3] }, { id: 'm_beast_hide', weight: 4, qty: [1, 2] }, { id: 'm_thorn_core', weight: 1, qty: [1, 1] }, { id: 'p_tonic', weight: 1, qty: [1, 1] }],
  [{ id: 'm_iron_shard', weight: 4, qty: [2, 4] }, { id: 'm_beast_hide', weight: 4, qty: [2, 3] }, { id: 'm_thorn_core', weight: 2, qty: [1, 1] }, { id: 'm_ember_core', weight: 1, qty: [1, 1] }],
  [{ id: 'm_iron_shard', weight: 3, qty: [3, 5] }, { id: 'm_beast_hide', weight: 3, qty: [2, 4] }, { id: 'm_thorn_core', weight: 2, qty: [1, 2] }, { id: 'm_ember_core', weight: 2, qty: [1, 1] }],
];
const GEAR = [
  [{ id: 'w_hunter_saber', weight: 1, qty: [1, 1] }, { id: 'w_ronin_katana', weight: 1, qty: [1, 1] }, { id: 'w_twin_fangs', weight: 1, qty: [1, 1] }, { id: 'a_hide_vest', weight: 1, qty: [1, 1] }, { id: 'c_moss_bead', weight: 1, qty: [1, 1] }],
  [{ id: 'w_thorn_edge', weight: 1, qty: [1, 1] }, { id: 'w_mist_katana', weight: 1, qty: [1, 1] }, { id: 'w_venom_daggers', weight: 1, qty: [1, 1] }, { id: 'w_boar_breaker', weight: 1, qty: [1, 1] }, { id: 'w_thorn_rod', weight: 1, qty: [1, 1] }, { id: 'w_thornstring_bow', weight: 1, qty: [1, 1] }, { id: 'w_thorn_pike', weight: 1, qty: [1, 1] }, { id: 'a_bark_mail', weight: 1, qty: [1, 1] }, { id: 'c_boar_tusk', weight: 1, qty: [1, 1] }],
  [{ id: 'w_ember_fang', weight: 1, qty: [1, 1] }, { id: 'w_moonfall_katana', weight: 1, qty: [1, 1] }, { id: 'w_cinder_talons', weight: 1, qty: [1, 1] }, { id: 'w_furnace_cleaver', weight: 1, qty: [1, 1] }, { id: 'w_ember_scepter', weight: 1, qty: [1, 1] }, { id: 'w_sunfire_bow', weight: 1, qty: [1, 1] }, { id: 'w_ember_glaive', weight: 1, qty: [1, 1] }, { id: 'a_lacquer_plate', weight: 1, qty: [1, 1] }, { id: 'c_cinder_eye', weight: 1, qty: [1, 1] }],
];
function monsterDrops(tier) {
  return [
    { chance: 0.55, entries: MAT[tier] },
    { chance: 0.03 + tier * 0.01, entries: GEAR[Math.min(2, tier)] },
  ];
}
function bossDrops(tier, legendary) {
  return [
    { chance: 1, entries: MAT[tier] }, { chance: 1, entries: MAT[tier] },
    { chance: 0.6, entries: GEAR[Math.min(2, tier)] },
    { chance: 0.25 + tier * 0.05, entries: GEAR[2] },
    { chance: 0.12 + tier * 0.03, entries: [{ id: legendary, weight: 1, qty: [1, 1] }] },
    { chance: 0.4, entries: [{ id: 'm_bloodstone', weight: 1, qty: [1, 1] }] },
  ];
}

// ------------------------------------------------------------------ zones
export const ZONES = Object.freeze([
  { id: 'z1', n: 1, name: 'ทุ่งหญ้าลมกรด', level: 6, tier: 0, theme: 'gale', mechanic: 'gale',
    desc: 'ทุ่งหญ้ากว้างที่ลมพัดแรงจนผลักคนล้ม สายลมกรรโชกจะเตือนทิศก่อนพัด ยืนหลบหลังหินหรือพุ่งสวนลมไว้',
    mechanicText: 'ลมกรรโชก: ลูกศรบอกทิศ 1.2 วินาที แล้วผลักทุกคนไปทางนั้น',
    monsters: ['z_gust_sprite', 'z_seed_spitter'], boss: 'z_storm_roc',
    rooms: [[['z_gust_sprite', 3], ['z_seed_spitter', 2]], [['z_seed_spitter', 2], ['z_gust_sprite', 3], ['z_gust_sprite', 2]], 'boss'] },
  { id: 'z2', n: 2, name: 'ถ้ำผลึกน้ำแข็ง', level: 8, tier: 0, theme: 'frost', mechanic: 'ice',
    desc: 'พื้นน้ำแข็งลื่นจนหยุดเดินไม่ได้ทันที หินย้อยน้ำแข็งร่วงจากเพดานเป็นระยะ',
    mechanicText: 'พื้นลื่น: เดินแล้วไถลต่อ · หินย้อยร่วงตรงจุดที่มีวงเตือน',
    monsters: ['z_frost_slime', 'z_ice_archer'], boss: 'z_glacier_wyrm',
    rooms: [[['z_frost_slime', 3], ['z_ice_archer', 1]], [['z_ice_archer', 2], ['z_frost_slime', 3], ['z_ice_archer', 1]], 'boss'] },
  { id: 'z3', n: 3, name: 'บึงพิษ', level: 10, tier: 1, theme: 'marsh', mechanic: 'toxic',
    desc: 'หนองน้ำที่เดือดปุดๆ แอ่งพิษผุดขึ้นมาเรื่อยๆ ยืนแช่นานพลังชีวิตจะค่อยๆ ลด',
    mechanicText: 'แอ่งพิษ: ผุดขึ้นทุก 5 วินาที ยืนในแอ่ง = ติดพิษ',
    monsters: ['z_bog_toad', 'z_spore_puff'], boss: 'z_hydra_mire',
    rooms: [[['z_bog_toad', 2], ['z_spore_puff', 3]], [['z_spore_puff', 3], ['z_bog_toad', 2], ['z_bog_toad', 1], ['z_spore_puff', 2]], 'boss'] },
  { id: 'z4', n: 4, name: 'ซากปราสาทเงา', level: 12, tier: 1, theme: 'shadow', mechanic: 'dark',
    desc: 'ความมืดกลืนทุกอย่างนอกรัศมีตะเกียงของคุณ มือเงาโผล่จากพื้นใต้เท้า เพื่อนร่วมทีมช่วยส่องทางได้',
    mechanicText: 'ความมืด: มองเห็นเฉพาะรอบตัวและเพื่อน · มือเงาผุดใต้เท้าทุก 4 วินาที',
    monsters: ['z_shade_stalker', 'z_bone_lancer'], boss: 'z_umbral_knight',
    rooms: [[['z_bone_lancer', 2], ['z_shade_stalker', 2]], [['z_shade_stalker', 2], ['z_bone_lancer', 2], ['z_shade_stalker', 2]], 'boss'] },
  { id: 'z5', n: 5, name: 'ทะเลทรายเงาแดด', level: 14, tier: 1, theme: 'dunes', mechanic: 'sun',
    desc: 'ทรายดูดทำให้เดินช้า และลำแสงอาทิตย์จะกวาดผ่านสนามเป็นแนวยาว',
    mechanicText: 'ทรายดูด: เดินช้าลงครึ่งหนึ่ง · ลำแสงแดดแผดเผาเป็นแนวทุก 6 วินาที',
    monsters: ['z_sand_burrower', 'z_scarab'], boss: 'z_sphinx_colossus',
    rooms: [[['z_scarab', 4], ['z_sand_burrower', 2]], [['z_sand_burrower', 2], ['z_scarab', 5], ['z_sand_burrower', 2]], 'boss'] },
  { id: 'z6', n: 6, name: 'ป่าเห็ดเรืองแสง', level: 16, tier: 2, theme: 'glow', mechanic: 'spores',
    desc: 'เห็ดยักษ์พ่นสปอร์เป็นจังหวะ ทุกดอกพ่นพร้อมกันเป็นรอบ ต้องอ่านจังหวะให้ออก',
    mechanicText: 'เห็ดยักษ์: พ่นสปอร์เป็นวงทุก 4 วินาที (เห็ดเรืองแสงก่อนพ่น)',
    monsters: ['z_cap_bouncer', 'z_mycel_weaver'], boss: 'z_mother_morel',
    rooms: [[['z_cap_bouncer', 3], ['z_mycel_weaver', 1]], [['z_mycel_weaver', 2], ['z_cap_bouncer', 3], ['z_mycel_weaver', 2]], 'boss'] },
  { id: 'z7', n: 7, name: 'โรงหลอมสายฟ้า', level: 18, tier: 2, theme: 'foundry', mechanic: 'storm',
    desc: 'ฟ้าผ่าลงในโรงหลอมไม่หยุด จุดที่จะโดนผ่าจะมีวงไฟฟ้าเตือนก่อน',
    mechanicText: 'ฟ้าผ่า: ผ่าลงใกล้ผู้เล่นทุก 2.5 วินาที',
    monsters: ['z_volt_drone', 'z_iron_brute'], boss: 'z_tesla_titan',
    rooms: [[['z_volt_drone', 3], ['z_iron_brute', 1]], [['z_iron_brute', 2], ['z_volt_drone', 3], ['z_iron_brute', 1]], 'boss'] },
  { id: 'z8', n: 8, name: 'หุบเขาลาวา', level: 20, tier: 2, theme: 'magma', mechanic: 'geysers',
    desc: 'ปล่องลาวาปะทุทีละจุดวนไปรอบสนาม ทิ้งพื้นไฟไว้ชั่วครู่',
    mechanicText: 'ปล่องลาวา: ปะทุวนเป็นลำดับ ทิ้งพื้นไฟ 3 วินาที',
    monsters: ['z_magma_hound', 'z_cinder_mortar'], boss: 'z_rift_drake',
    rooms: [[['z_magma_hound', 3], ['z_cinder_mortar', 1]], [['z_cinder_mortar', 2], ['z_magma_hound', 3], ['z_cinder_mortar', 1]], 'boss'] },
  { id: 'z9', n: 9, name: 'สวนลอยฟ้า', level: 22, tier: 3, theme: 'sky', mechanic: 'void',
    desc: 'สวนบนเกาะลอยฟ้า แผ่นพื้นบางช่องจะพังลงสู่ความว่างเปล่าชั่วคราว อย่ายืนบนแผ่นที่กะพริบ',
    mechanicText: 'พื้นพัง: แผ่นพื้นกะพริบ 1.4 วินาทีแล้วพัง ใครยืนอยู่จะร่วง',
    monsters: ['z_feather_monk', 'z_cloud_ray'], boss: 'z_seraph_warden',
    rooms: [[['z_feather_monk', 2], ['z_cloud_ray', 2]], [['z_cloud_ray', 2], ['z_feather_monk', 2], ['z_cloud_ray', 2]], 'boss'] },
  { id: 'z10', n: 10, name: 'บัลลังก์คืนเถ้า', level: 25, tier: 3, theme: 'throne', mechanic: 'ashstorm',
    desc: 'ห้องบัลลังก์ของผู้ที่ทำให้ป่าอำพันกลายเป็นเถ้า พายุเถ้าบดบังสายตาเป็นระลอก และเถ้าถ่านร่วงลงมาไม่หยุด',
    mechanicText: 'พายุเถ้า: มืดลงเป็นระลอก · ถ่านร่วงตามตัวผู้เล่น',
    monsters: ['z_ash_revenant', 'z_cinder_mage'], boss: 'z_ash_sovereign',
    rooms: [[['z_ash_revenant', 2], ['z_cinder_mage', 2]], [['z_cinder_mage', 2], ['z_ash_revenant', 3], ['z_cinder_mage', 1]], 'boss'] },
]);

export function getZone(id) { return ZONES.find((z) => z.id === id) || null; }
export const zoneOfEnemy = (id) => ZONES.find((z) => z.boss === id || z.monsters.includes(id)) || null;

// Zone clear rewards (once per run, for everyone who reaches the end).
export function clearReward(zone, first) {
  return { gold: 80 + zone.level * 12 + (first ? 150 : 0), sparks: first ? 12 : 3, xp: 40 + zone.level * 8 };
}

// ------------------------------------------------------------------ enemies
// m: multipliers on zoneStats. ai: behaviour in src/battle/zoneBehaviours.js.
function mk(id, zoneIdx, name, o) {
  const z = ZONES[zoneIdx];
  const base = zoneStats(z.level);
  const boss = !!o.boss;
  const hpM = o.hp ?? 1, atkM = o.atk ?? 1;
  return [id, Object.freeze({
    id, name, sprite: id, zone: z.id, boss, faces: o.faces ?? true, particles: o.particles,
    hp: Math.round(base.hp * hpM * (boss ? 16 : 1)), atk: Math.round(base.atk * atkM * (boss ? 1.25 : 1)), def: Math.round(base.def * (o.def ?? 1) * (boss ? 1.4 : 1)),
    speed: o.speed, radius: o.radius, mass: o.mass ?? (boss ? 8 : 1), xp: Math.round(base.xp * (boss ? 14 : o.xp ?? 1)),
    gold: boss ? [base.gold[0] * 10, base.gold[1] * 10] : base.gold, sparks: boss ? 4 + z.tier * 2 : 0,
    interruptAt: o.interruptAt, scale: o.scale, flying: !!o.flying, split: o.split || null, guardFront: o.guardFront || 0, revive: !!o.revive,
    ai: o.ai, ai_params: Object.freeze(o.p || {}),
    drops: boss ? bossDrops(z.tier, o.legendary) : monsterDrops(z.tier),
  })];
}

export const ZONE_ENEMIES = Object.freeze(Object.fromEntries([
  // 1 Gale Meadow
  mk('z_gust_sprite', 0, 'ภูตลมกรด', { ai: 'zigzag', speed: 150, radius: 18, hp: 0.8, particles: ['#cdf3e6', '#9fd6c4', '#ffffff'], flying: true, faces: false,
    p: { dashes: 3, dashSpeed: 420, dashTime: 0.22, windup: 0.5, dartSpeed: 620, dartTime: 0.35, rest: 0.7 } }),
  mk('z_seed_spitter', 0, 'บุปผาพ่นเมล็ด', { ai: 'turret_burrow', speed: 0, radius: 22, hp: 1.1, mass: 99, particles: ['#6f9a4a', '#d6ef8a', '#e8c34a'], faces: false,
    p: { windup: 0.6, shots: 3, spread: 0.35, shotSpeed: 330, volleys: 3, gap: 1.3, burrowTime: 1.0, emergeRadius: 70 } }),
  mk('z_storm_roc', 0, 'ราชันนกพายุ', { boss: true, ai: 'storm_roc', speed: 120, radius: 60, particles: ['#d9e8f6', '#8aa6c8', '#f5d48a'], flying: true, legendary: 'w_tempest_saber',
    p: { diveTelegraph: 0.8, diveSpeed: 900, dives: 3, fanCount: 9, fanSpread: 1.1, shotSpeed: 360, tornadoLife: 6, rest: 1.1 } }),
  // 2 Frost Crystal Cave
  mk('z_frost_slime', 1, 'สไลม์ผลึกน้ำแข็ง', { ai: 'hopper', speed: 70, radius: 24, hp: 1.2, particles: ['#bfe8ff', '#8fd0f0', '#ffffff'], faces: false, split: { id: 'z_frost_mote', count: 2 },
    p: { hopEvery: 1.1, hopTime: 0.4, hopSpeed: 300, contactRange: 36 } }),
  mk('z_frost_mote', 1, 'ผลึกน้ำแข็งน้อย', { ai: 'hopper', speed: 90, radius: 14, hp: 0.35, xp: 0.3, scale: 0.6, particles: ['#bfe8ff', '#ffffff'], faces: false,
    p: { hopEvery: 0.7, hopTime: 0.3, hopSpeed: 340, contactRange: 26 } }),
  mk('z_ice_archer', 1, 'พลธนูน้ำแข็ง', { ai: 'sniper', speed: 95, radius: 20, hp: 0.9, particles: ['#bfe8ff', '#5f8fb8', '#ffffff'],
    p: { keepAway: 360, aim: 0.95, shotSpeed: 720, pierce: true, pool: 'ice', cooldown: 2.2 } }),
  mk('z_glacier_wyrm', 1, 'มังกรธารน้ำแข็ง', { boss: true, ai: 'glacier_wyrm', speed: 110, radius: 62, particles: ['#e8f8ff', '#8fc4e8', '#ffffff'], faces: true, legendary: 'w_glacier_fang',
    p: { burrowTime: 1.4, emergeTelegraph: 0.95, emergeRadius: 140, breathTelegraph: 0.8, breathRange: 380, breathArc: 0.9, ringCount: 16, shotSpeed: 300, rest: 1.0 } }),
  // 3 Venom Marsh
  mk('z_bog_toad', 2, 'คางคกบึงพิษ', { ai: 'tongue', speed: 80, radius: 26, hp: 1.3, particles: ['#b8d070', '#6a8a3a', '#c27ff0'], faces: false,
    p: { range: 330, windup: 0.75, tongueWidth: 34, pull: -520, hopSpeed: 360, hopTime: 0.35, rest: 0.9 } }),
  mk('z_spore_puff', 2, 'พองสปอร์', { ai: 'bomber', speed: 70, radius: 20, hp: 0.6, particles: ['#ecd2ff', '#b07ad0', '#e8ff9a'], faces: false, flying: true,
    p: { trigger: 110, swell: 0.95, blast: 120, poolR: 90, poolT: 4 } }),
  mk('z_hydra_mire', 2, 'ไฮดราแห่งบึง', { boss: true, ai: 'hydra', speed: 0, radius: 70, mass: 99, particles: ['#b8e08a', '#5a8a4a', '#c27ff0'], faces: false, legendary: 'w_hydra_kiss',
    p: { spitEvery: 0.55, spitSpeed: 380, volley: 6, submergeTime: 1.6, waveTelegraph: 0.8, waveRadii: [130, 240, 350], waveGap: 0.55, summon: 'z_spore_puff' } }),
  // 4 Shadow Ruins
  mk('z_shade_stalker', 3, 'นักฆ่าเงา', { ai: 'blink_assassin', speed: 120, radius: 20, hp: 0.9, atk: 1.2, particles: ['#9a8ad0', '#3a3450', '#c27ff0'],
    p: { fade: 1.6, windup: 0.5, slashRange: 120, slashArc: 1.6, recover: 0.8 } }),
  mk('z_bone_lancer', 3, 'อัศวินกระดูกทวน', { ai: 'lancer', speed: 85, radius: 22, hp: 1.3, particles: ['#f3ead2', '#c8bca0', '#8e2c21'], interruptAt: 1.6,
    p: { range: 260, windup: 0.8, thrustLen: 360, thrustWidth: 44, thrustTime: 0.28, recover: 1.0 } }),
  mk('z_umbral_knight', 3, 'อัศวินจันทร์ดับ', { boss: true, ai: 'umbral_knight', speed: 140, radius: 52, particles: ['#e0b0ff', '#2a2438', '#c27ff0'], legendary: 'w_umbral_greatblade',
    p: { slashTelegraph: 0.7, slashLen: 420, slashWidth: 70, slashes: 3, pulseRadius: 260, pulseTelegraph: 1.0, summon: 'z_shade_stalker', rest: 1.0 } }),
  // 5 Sunscorch Dunes
  mk('z_sand_burrower', 4, 'ด้วงมุดทราย', { ai: 'burrower', speed: 170, radius: 24, hp: 1.2, particles: ['#f0d89a', '#c8a060', '#6a4a24'], interruptAt: 1.5,
    p: { travel: 1.6, emergeTelegraph: 0.8, emergeRadius: 85, spitCount: 5, spitSpeed: 300, exposed: 1.8 } }),
  mk('z_scarab', 4, 'แมลงปีกแข็งเทอร์ควอยซ์', { ai: 'swarm', speed: 210, radius: 14, hp: 0.45, xp: 0.5, scale: 0.75, particles: ['#7fd0c0', '#2f6a6a', '#f5d48a'], flying: true,
    p: { orbit: 140, orbitTime: 2.2, dashSpeed: 560, dashTime: 0.3, windup: 0.35 } }),
  mk('z_sphinx_colossus', 4, 'สฟิงซ์ยักษ์แห่งเนินทราย', { boss: true, ai: 'sphinx', speed: 60, radius: 70, mass: 99, particles: ['#f3dca0', '#c8a46a', '#7fe8ff'], faces: false, legendary: 'w_sunspire_staff',
    p: { beamTelegraph: 1.0, beamLen: 760, beamWidth: 46, beamSweep: 2.2, beamSteps: 11, pillarCount: 6, pillarRadius: 70, pillarTelegraph: 1.0, rest: 1.2 } }),
  // 6 Glowcap Grove
  mk('z_cap_bouncer', 5, 'เห็ดเด้ง', { ai: 'ricochet', speed: 0, radius: 24, hp: 1.1, particles: ['#ffd0e0', '#d06a8a', '#ff7aa8'], faces: false,
    p: { windup: 0.7, speed: 560, bounces: 3, travel: 2.4, dizzy: 1.3 } }),
  mk('z_mycel_weaver', 5, 'แมงมุมใยเรืองแสง', { ai: 'weaver', speed: 120, radius: 20, hp: 0.9, particles: ['#c8b8ff', '#6a5aa8', '#9fffd8'],
    p: { keepAway: 260, webEvery: 2.6, webTelegraph: 0.9, webRadius: 75, webT: 4, strandSpeed: 260 } }),
  mk('z_mother_morel', 5, 'มารดาเห็ดราชินี', { boss: true, ai: 'morel', speed: 70, radius: 64, particles: ['#f0d0ff', '#a86ad0', '#9fffd8'], faces: false, flying: true, legendary: 'w_sporebloom_bow',
    p: { spiralTime: 3.2, spiralRate: 0.09, spiralArms: 3, spiralSpeed: 230, rainCount: 9, rainRadius: 70, rainTelegraph: 1.0, summon: 'z_cap_bouncer', rest: 1.2 } }),
  // 7 Thunder Foundry
  mk('z_volt_drone', 6, 'โดรนสายฟ้า', { ai: 'orbit_zapper', speed: 160, radius: 18, hp: 0.8, particles: ['#fff07a', '#5a6a80', '#c8d8ea'], faces: false, flying: true,
    p: { orbit: 200, zapEvery: 2.1, zapTelegraph: 0.65, zapWidth: 26 } }),
  mk('z_iron_brute', 6, 'ยักษ์เหล็กถือโล่', { ai: 'shielded', speed: 70, radius: 30, hp: 1.8, atk: 1.2, mass: 4, particles: ['#b8c0cc', '#6a6f78', '#ffcf5a'], guardFront: 0.8, interruptAt: 2.2,
    p: { smashRange: 110, smashRadius: 95, windup: 0.9, recover: 1.1 } }),
  mk('z_tesla_titan', 6, 'ไททันเทสลา', { boss: true, ai: 'tesla', speed: 80, radius: 66, particles: ['#a8c0de', '#4a5a70', '#ffe65a'], faces: false, legendary: 'w_thunder_lance',
    p: { pylons: 3, chainTelegraph: 0.9, chainWidth: 30, ringTelegraph: 0.7, ringRadii: [150, 260, 370, 480], ringGap: 0.45, overloadRadius: 200, rest: 1.0 } }),
  mk('z_pylon', 6, 'เสานำไฟฟ้า', { ai: 'pylon', speed: 0, radius: 22, hp: 0.9, mass: 99, xp: 0.2, particles: ['#ffe65a', '#4a5a70'], faces: false, p: {} }),
  // 8 Magma Rift
  mk('z_magma_hound', 7, 'สุนัขลาวา', { ai: 'trailblazer', speed: 230, radius: 22, hp: 1.0, particles: ['#ff8a3d', '#6a2a1e', '#ffcf5a'],
    p: { circle: 2.0, trailEvery: 0.22, trailR: 34, trailT: 2.4, pounceTelegraph: 0.55, pounceSpeed: 700, pounceTime: 0.3 } }),
  mk('z_cinder_mortar', 7, 'ป้อมปืนครกถ่าน', { ai: 'mortar', speed: 50, radius: 26, hp: 1.3, mass: 6, particles: ['#ff7a33', '#5a4a44', '#ffcf5a'],
    p: { shells: 3, scatter: 110, telegraph: 1.15, blast: 70, cooldown: 2.6, keepAway: 320 } }),
  mk('z_rift_drake', 7, 'มังกรรอยแยก', { boss: true, ai: 'drake', speed: 130, radius: 64, particles: ['#ffb35a', '#8e2c21', '#ffe89a'], legendary: 'a_drakescale',
    p: { breathTelegraph: 0.8, breathSteps: 7, breathArc: 0.7, breathRange: 420, meteorCount: 10, meteorRadius: 75, meteorTelegraph: 1.1, chargeSpeed: 760, chargeTime: 0.7, rest: 1.0 } }),
  // 9 Sky Gardens
  mk('z_feather_monk', 8, 'นักพรตขนนก', { ai: 'counter', speed: 130, radius: 20, hp: 1.1, particles: ['#ffffff', '#e8e0c8', '#5fa8ec'],
    p: { guard: 1.6, counterRadius: 130, palmRange: 110, palmArc: 1.2, palms: 3, palmGap: 0.32, windup: 0.4 } }),
  mk('z_cloud_ray', 8, 'กระเบนเมฆ', { ai: 'glider', speed: 0, radius: 26, hp: 1.0, particles: ['#f4faff', '#a8c8e8', '#ffe65a'], flying: true,
    p: { telegraph: 0.9, glideSpeed: 560, trailDelay: 0.45, trailWidth: 40, rest: 1.4 } }),
  mk('z_seraph_warden', 8, 'ผู้พิทักษ์เทวะ', { boss: true, ai: 'seraph', speed: 110, radius: 58, particles: ['#fff3a0', '#f3e6c8', '#e0b45a'], flying: true, legendary: 'c_seraph_feather',
    p: { beamTelegraph: 0.85, beamLen: 900, beamWidth: 50, wheels: 4, wheelLife: 5, petalCount: 20, petalSpeed: 250, rest: 1.0 } }),
  // 10 Ashen Throne
  mk('z_ash_revenant', 9, 'วิญญาณเถ้า', { ai: 'revenant', speed: 110, radius: 22, hp: 1.1, atk: 1.15, particles: ['#ff8a3d', '#4a4440', '#8a827a'], revive: true,
    p: { range: 120, windup: 0.45, arc: 1.6, swings: 2, gap: 0.35, recover: 0.9, reviveTime: 3 } }),
  mk('z_cinder_mage', 9, 'จอมเวทถ่าน', { ai: 'homing_caster', speed: 100, radius: 20, hp: 0.9, particles: ['#ffcf5a', '#5a2a24', '#ffb35a'],
    p: { keepAway: 300, windup: 0.75, orbs: 3, orbSpeed: 210, homing: 1.7, cooldown: 2.6, blinkRange: 160 } }),
  mk('z_ash_sovereign', 9, 'จักรพรรดิเถ้าถ่าน', { boss: true, ai: 'sovereign', speed: 120, radius: 60, particles: ['#ff8a3d', '#3a2a24', '#e0b45a'], legendary: 'c_ember_crown',
    p: { waveTelegraph: 0.75, waveLen: 640, waveWidth: 56, waveFan: 5, waveSpread: 0.9, orbCount: 6, orbSpeed: 230, ringTelegraph: 1.2, rest: 0.9, summon: 'z_ash_revenant' } }),
]));
