// Rasterizes the vector illustrations once into offscreen canvases (plus a white silhouette for hit flashes).
export const ART_SCALE = 2; // rasterize at 2x world size so sprites stay crisp on high-DPI screens

export function rasterize(spec, scale = ART_SCALE) {
  const W = Math.ceil(spec.w * scale), H = Math.ceil(spec.h * scale);
  const scaled = spec.svg.replace(/width="[\d.]+" height="[\d.]+"/, `width="${W}" height="${H}"`);
  const img = new Image();
  img.decoding = 'async';
  img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(scaled);
  return img.decode().then(() => {
    const canvas = document.createElement('canvas');
    canvas.width = W; canvas.height = H;
    canvas.getContext('2d').drawImage(img, 0, 0, W, H);
    const white = document.createElement('canvas');
    white.width = W; white.height = H;
    const w = white.getContext('2d');
    w.drawImage(canvas, 0, 0);
    w.globalCompositeOperation = 'source-in';
    w.fillStyle = '#fff8ea';
    w.fillRect(0, 0, W, H);
    return { canvas, white, w: spec.w, h: spec.h, ax: spec.ax, ay: spec.ay, ...(spec.meta || {}) };
  });
}

export async function rasterizeAll(specs) {
  const keys = Object.keys(specs);
  const out = {};
  const results = await Promise.all(keys.map((k) => rasterize(specs[k]).catch((e) => {
    throw new Error(`ภาพ "${k}" โหลดไม่สำเร็จ: ${e.message || e}`);
  })));
  keys.forEach((k, i) => { out[k] = results[i]; });
  return out;
}
