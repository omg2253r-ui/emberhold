// Entry point: builds the app context, rasterizes art, restores the save and runs the scene loop.
import { createRenderer } from './engine/renderer.js';
import { createInput } from './engine/input.js';
import { createLoop } from './engine/loop.js';
import { createParticles } from './engine/particles.js';
import { rasterize } from './engine/assets.js';
import { createAudio } from './audio/sfx.js';
import { createRng } from './core/rng.js';
import { createStore } from './core/store.js';
import { createNewState, cloneState } from './core/state.js';
import { createSaveStore, browserStorage } from './persistence/save.js';
import { ITEMS, getItem } from './data/items.js';
import { ENEMIES } from './data/enemies.js';
import { validateDropTable } from './systems/loot.js';
import * as ART from './art/sprites.js';
import * as CREATURES from './art/creatures.js';
import * as OBJ from './art/objects.js';
import { heroParts, portraits, heroPortrait, DEFAULT_LOOK } from './art/hero.js';
import { itemIconSvg, goldIconSvg, sparkIconSvg, svgDataUri } from './art/icons.js';
import { weaponSprite } from './art/weapons.js';
import { wingSprite } from './art/wings.js';
import { PET_ART } from './art/pets.js';
import { RACES } from './data/races.js';
import { createStoryUi } from './ui/storyUi.js';
import { createAwakenUi } from './ui/raceUi.js';
import { awakenRace, rerollRace } from './systems/race.js';
import { nextCampScene } from './systems/story.js';
import { doorsOf } from './systems/dungeon.js';
import { cleanHeroName } from './core/state.js';
import { createScreens } from './ui/screens.js';
import { setTipState } from './ui/itemTip.js';
import { createHud } from './ui/hud.js';
import { createToasts } from './ui/toast.js';
import { createCampScene } from './scenes/campScene.js';
import { createDungeonScene } from './scenes/dungeonScene.js';
import { createVillageScene } from './scenes/villageScene.js';
import { createMatchScene } from './scenes/matchScene.js';
import { createCoopScene } from './scenes/coopScene.js';
import { ZONE_ART } from './art/zoneCreatures.js';
import { getZone } from './data/zones.js';
import { ALL_ENEMIES } from './data/enemies.js';
import { openZoneBoard, zoneLock } from './ui/zonesUi.js';
import { openCrafting } from './ui/craftUi.js';
import { openPatchNotes } from './ui/patchNotes.js';
import { hasUnseenNotes, markSeen } from './data/changelog.js';
import { openCosmos } from './ui/cosmosUi.js';
import { INFINITE, infiniteZone, entriesLeft, dayKey } from './data/infinite.js';
import { getArtifact } from './data/artifacts.js';
import { createGuildSession } from './online/guild.js';
import { createRooms } from './online/rooms.js';
import { createTradeLink } from './online/tradeLink.js';
import { openTradeUi } from './ui/tradeUi.js';
import { MODES, TEAM_INFO } from './online/match.js';
import { createVillageUi } from './ui/villageUi.js';
import { VILLAGE_ART } from './art/village.js';
import { createNet } from './net/net.js';
import { createOnline } from './online/online.js';
import { lookOf } from './online/protocol.js';
import { h, itemImg, glyph, artifactImg } from './ui/dom.js';

const canvas = document.getElementById('scene');
const uiRoot = document.getElementById('ui');

const params = new URLSearchParams(location.search);
// Development hosts only: a fixed RNG seed (?seed=) and save re-signing for the automated tests. On the public
// site a seed would let players predict drops and summons, so it is ignored there.
const DEV_HOST = location.protocol === 'file:' || ['localhost', '127.0.0.1', '[::1]'].includes(location.hostname);
const seed = (DEV_HOST && Number(params.get('seed'))) || ((crypto.getRandomValues(new Uint32Array(1))[0] ^ Date.now()) >>> 0);
// ?net=local joins other tabs of this browser (development and tests), ?net=off stays offline.
const netMode = params.get('net') === 'local' ? 'local' : params.get('net') === 'mesh' ? 'mesh' : params.get('net') === 'off' ? 'offline' : 'auto';
// ?slot=b keeps a separate save, so two test tabs can be two different heroes.
const saveSlot = /^[a-z0-9]{1,8}$/.test(params.get('slot') || '') ? params.get('slot') : '';

const renderer = createRenderer(canvas);
const input = createInput(canvas);
const audio = createAudio();
const particles = createParticles();
const { storage, persistent } = browserStorage();
const saves = createSaveStore(storage, saveSlot);
const store = createStore(createNewState(), saves);
setTipState(() => store.get());
const rng = createRng(seed);

const app = {
  renderer, input, audio, particles, rng, store, sprites: {}, vignette: null,
  gameActive: false, // true once the player pressed New Game or Continue
  touch: window.matchMedia('(pointer: coarse)').matches,
  toast: () => {},
};
app.toast = createToasts(uiRoot);
const screens = createScreens(uiRoot, app);
app.hud = createHud(uiRoot, app);
const story = createStoryUi(uiRoot, app);
const awaken = createAwakenUi(uiRoot, app);
app.rooms = createRooms(app);
app.guild = createGuildSession(app);
app.village = createVillageUi(uiRoot, app);
app.village.watchRooms();
// Until the network answers, the game is an offline single-player game; online features light up after.
app.online = createOnline(app, offlineNetPlaceholder());
function offlineNetPlaceholder() {
  const dead = { emit: async () => {}, on: () => () => {}, presence: async () => {}, peers: () => [], onPeers: () => () => {}, connected: () => false, leave: async () => {} };
  return { kind: 'offline', mode: 'offline', online: false, reason: 'กำลังเชื่อมต่อ…', me: { peer: 'me', id: null }, canSend: false, lobby: dead, join: async () => dead, onSendRefused: () => () => {}, close() {} };
}

const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
app.reducedMotion = reducedMotion.matches;
const PORTRAITS = portraits();
const portraitCache = new Map();
// 'hero' resolves to the portrait of the current bloodline.
app.portraitUri = (key) => {
  const race = key === 'hero' ? store.get().race?.id : null;
  const k = race ? `hero_${race}` : key;
  if (!portraitCache.has(k)) portraitCache.set(k, svgDataUri(race ? heroPortrait(RACES[race].look) : (PORTRAITS[key] || PORTRAITS.hero)));
  return portraitCache.get(k);
};
const spriteUriCache = new Map();
app.spriteUri = (key) => {
  if (!spriteUriCache.has(key)) spriteUriCache.set(key, svgDataUri((ZONE_ART[key] || PET_ART[key] || VILLAGE_ART[key])?.().svg || ''));
  return spriteUriCache.get(key);
};
const petUriCache = new Map();
app.petUri = (id) => {
  if (!petUriCache.has(id)) petUriCache.set(id, svgDataUri(PET_ART['pet_' + id]().svg));
  return petUriCache.get(id);
};
app.racePortraitUri = (raceId) => {
  const k = `race_${raceId}`;
  if (!portraitCache.has(k)) portraitCache.set(k, svgDataUri(heroPortrait(RACES[raceId]?.look || DEFAULT_LOOK)));
  return portraitCache.get(k);
};
particles.setScale(reducedMotion.matches ? 0.4 : 1);

// ---------------------------------------------------------------- art
function iconSpec(svg) {
  return { svg: svg.replace('<svg ', '<svg width="64" height="64" '), w: 64, h: 64, ax: 32, ay: 32 };
}
const ARMOR_LOOK = (def) => (def ? { main: def.art.main === '#231a17' ? '#2e2420' : def.art.main, trim: def.art.trim === '#e0b45a' ? '#c2412f' : def.art.trim, kind: def.art.kind } : {});
function artSpecs() {
  const specs = {
    mossling: CREATURES.mossling(), thorn_imp: CREATURES.thornImp(), thornback_boar: CREATURES.thornbackBoar(),
    ember_imp: CREATURES.emberImp(), cinder_beetle: CREATURES.cinderBeetle(), furnace_golem: CREATURES.furnaceGolem(),
    tree0: ART.tree(0), tree1: ART.tree(1), tree2: ART.tree(2), bush: ART.bush(), stone: ART.stone(), mushroom: ART.mushroom(),
    grass: ART.grass(), flowers: ART.flowers(), log: ART.log(), tent: ART.tent(), anvil: ART.anvil(), crates: ART.crates(), lantern: ART.lantern(),
    deadTree: ART.deadTree(), rockPile: ART.rockPile(), emberRock: ART.emberRock(),
    chest: OBJ.chest(false), chest_open: OBJ.chest(true), chest_rich: OBJ.chest(false, true), chest_rich_open: OBJ.chest(true, true),
    bonfire: OBJ.bonfireBase(), signpost: OBJ.signpost(), altar: OBJ.altar(), desk: OBJ.desk(), pedestal: OBJ.pedestalLetter(),
    dart_turret: OBJ.dartTurret(), boss_seal: OBJ.bossSeal(), lek: OBJ.lekNpc(),
    icon_gold: iconSpec(goldIconSvg()), icon_spark: iconSpec(sparkIconSvg()),
  };
  for (const [k, fn] of Object.entries(PET_ART)) specs[k] = fn();
  for (const [k, fn] of Object.entries(VILLAGE_ART)) specs[k] = fn();
  for (const [k, fn] of Object.entries(ZONE_ART)) specs[k] = fn();
  const looks = { none: {} };
  for (const def of Object.values(ITEMS)) {
    specs['icon_' + def.id] = iconSpec(itemIconSvg(def.id));
    if (def.category === 'weapon') specs['weapon_' + def.id] = weaponSprite(def.art);
    if (def.category === 'weapon' && def.art.off) specs['weapon_' + def.id + '_off'] = weaponSprite({ ...def.art, ...def.art.off });
    if (def.category === 'wings') specs['wings_' + def.id] = wingSprite(def.art);
    if (def.category === 'armor') looks[def.id] = ARMOR_LOOK(def);
  }
  for (const [id, look] of Object.entries(looks)) {
    for (const [part, spec] of Object.entries(heroParts(look))) specs[`hero_${id}_${part}`] = spec;
    // one head per bloodline (skin, hair, eyes and trait) for each armor's hood colour
    for (const race of Object.values(RACES)) specs[`hero_${id}_head_${race.id}`] = heroParts(look, race.look).head;
  }
  return specs;
}

async function loadArt() {
  const specs = artSpecs();
  const keys = Object.keys(specs);
  let done = 0;
  await Promise.all(keys.map(async (k) => {
    try { app.sprites[k] = await rasterize(specs[k]); }
    catch (e) { throw new Error(`วาดภาพ "${k}" ไม่สำเร็จ (${e.message || e})`); }
    done++; screens.loading.progress(done / keys.length);
  }));
  // twin blades with a different off-hand blade carry it on the main sprite
  for (const def of Object.values(ITEMS)) if (def.category === 'weapon' && app.sprites['weapon_' + def.id + '_off']) app.sprites['weapon_' + def.id].off = app.sprites['weapon_' + def.id + '_off'];
}

const HERO_PARTS = ['legBack', 'legFront', 'body', 'head', 'armBack', 'armFront', 'scarf', 'collar'];
app.refreshHeroSprites = () => {
  const st = store.get();
  const look = app.sprites[`hero_${st.equipment.armor?.id}_body`] ? st.equipment.armor.id : 'none';
  app.sprites.heroParts = Object.fromEntries(HERO_PARTS.map((p) => [p, app.sprites[`hero_${look}_${p}`]]));
  const race = st.race?.id;
  if (race && app.sprites[`hero_${look}_head_${race}`]) app.sprites.heroParts.head = app.sprites[`hero_${look}_head_${race}`];
  app.sprites.weapon = app.sprites['weapon_' + st.equipment.weapon.id];
  app.sprites.heroParts.wings = st.equipment.wings ? app.sprites['wings_' + st.equipment.wings.id] || null : null;
};

// Sprite set for another player's hero (their armour colours and bloodline head).
const partsCache = new Map();
app.heroPartsFor = (armorId, raceId, wingsId = null) => {
  const look = armorId && app.sprites[`hero_${armorId}_body`] ? armorId : 'none';
  const key = `${look}|${raceId || ''}|${wingsId || ''}`;
  if (!partsCache.has(key)) {
    const parts = Object.fromEntries(HERO_PARTS.map((p) => [p, app.sprites[`hero_${look}_${p}`]]));
    if (raceId && app.sprites[`hero_${look}_head_${raceId}`]) parts.head = app.sprites[`hero_${look}_head_${raceId}`];
    parts.wings = (wingsId && app.sprites['wings_' + wingsId]) || null;
    partsCache.set(key, parts);
  }
  return partsCache.get(key);
};

// The Infinite Rift's payout: deepest wave, coins, every artifact (new, levelled up, or turned into coins).
function infiniteResult(res) {
  const inf = res.reward.infinite;
  let close;
  const label = (r) => (r.kind === 'new' ? 'ใหม่!' : r.kind === 'level' ? `ระดับ ${r.lvl}` : `+${r.gold} เหรียญ`);
  const content = h('div', { class: 'modal panel inf-result', 'data-modal': 'zone-result', 'data-outcome': 'infinite', 'data-wave': inf.wave },
    h('div', { class: 'eyebrow', style: { textAlign: 'center' } }, 'รอยแยกไร้สิ้นสุด'),
    h('h2', {}, res.outcome === 'fallen' ? 'ล้มลงในรอยแยก' : 'ออกจากรอยแยก'),
    h('div', { class: 'inf-wave' }, h('small', { class: 'muted' }, 'ไปได้ถึงคลื่น'), h('b', { class: 'num' }, inf.wave), inf.wave >= inf.best && inf.wave > 0 ? h('span', { class: 'chip ok' }, 'สถิติใหม่') : h('small', { class: 'muted' }, `สถิติ ${inf.best}`)),
    h('div', { class: 'notice ok' }, `ได้รับ ${inf.coins.toLocaleString('th-TH')} เหรียญ · อาร์ติแฟกต์ ${inf.arts.length} ชิ้น`),
    inf.arts.length ? h('div', { class: 'inf-arts' }, inf.arts.map((r) => { const a = getArtifact(r.id); return h('div', { class: `inf-art r-${a.rarity}` }, artifactImg(r.id), h('b', { class: 'rc-text' }, a.name), h('small', {}, label(r))); })) : h('div', { class: 'empty-note' }, 'รอบนี้ยังไม่ได้อาร์ติแฟกต์ ลึกขึ้นอีกนิด ทุก 5 คลื่นมีผู้พิทักษ์ที่ถืออาร์ติแฟกต์เสมอ'),
    h('div', { class: 'kv' },
      h('div', {}, h('span', { class: 'muted' }, 'กำจัด'), h('b', {}, `${res.run.kills} ตัว`)),
      h('div', {}, h('span', { class: 'muted' }, 'เวลา'), h('b', {}, `${Math.floor(res.run.seconds / 60)}:${String(res.run.seconds % 60).padStart(2, '0')}`)),
      h('div', {}, h('span', { class: 'muted' }, 'คอมโบสูงสุด'), h('b', {}, `${res.run.bestCombo} ฮิต`)),
      h('div', {}, h('span', { class: 'muted' }, 'สิทธิ์ที่เหลือวันนี้'), h('b', {}, `${entriesLeft(store.get())} / ${INFINITE.entriesPerDay}`))),
    res.saveOk ? null : h('div', { class: 'notice' }, 'บันทึกเกมไม่สำเร็จ'),
    h('div', { class: 'actions' },
      inf.arts.length ? h('button', { class: 'btn', type: 'button', 'data-action': 'to-cosmos', onclick: () => { close(); setTimeout(() => app.openCosmos(), 50); } }, glyph('cosmos'), 'ใส่อาร์ติแฟกต์') : null,
      h('button', { class: 'btn primary', type: 'button', 'data-action': 'zone-done', onclick: () => close() }, zoneFrom === 'village' ? 'กลับหมู่บ้าน' : 'กลับค่าย')));
  close = screens.modal(content, { dismissable: false, onClose: () => { if (zoneFrom === 'village' && app.online.online) app.enterVillage(); else arriveCamp(null); } });
}

function buildVignette() {
  const v = renderer.view;
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(v.w / 2)); c.height = Math.max(1, Math.round(v.h / 2));
  const g = c.getContext('2d');
  const grad = g.createRadialGradient(c.width / 2, c.height / 2, Math.min(c.width, c.height) * 0.35, c.width / 2, c.height / 2, Math.hypot(c.width, c.height) * 0.6);
  grad.addColorStop(0, 'rgba(0,0,0,0)'); grad.addColorStop(1, 'rgba(8,5,4,0.6)');
  g.fillStyle = grad; g.fillRect(0, 0, c.width, c.height);
  app.vignette = c;
}

// ---------------------------------------------------------------- scenes
const scenes = { camp: createCampScene(app), battle: createDungeonScene(app), village: createVillageScene(app), match: createMatchScene(app), coop: createCoopScene(app) };
let scene = null, sceneName = '';
const ZONE = { camp: { z: 'camp', b: null }, battle: { z: 'hunt', b: 'hunt' }, village: { z: 'village', b: null }, match: { z: 'arena', b: 'duel' }, coop: { z: 'hunt', b: 'hunt' } };
function switchScene(name, params) {
  if (scene) scene.exit();
  scene = scenes[name]; sceneName = name;
  scene.enter(params || {});
  if (app.gameActive) app.online.publish(ZONE[name]);
  // friend / party / duel requests can be answered at camp and in the village
  app.village.showRequests(name === 'camp' || name === 'village');
}

// ---------------------------------------------------------------- app actions (used by UI)
// Plays any story scenes waiting at camp, one after another, then opens the requested panel.
function runCampStory(then) {
  const id = nextCampScene(store.get());
  if (id) app.playScene(id, () => { screens.renderTop(store.get()); screens.rerender(); runCampStory(then); });
  else then?.();
}

// After the camp story, a hero without a bloodline awakens it (new heroes, and saves from before v3).
function ensureBloodline(then) {
  if (store.get().race?.id) { then?.(); return; }
  awaken.openCeremony('first', () => { screens.renderTop(store.get()); screens.rerender(); then?.(); });
}

function arriveCamp(panel) {
  switchScene('camp');
  const waiting = !!nextCampScene(store.get()) || !store.get().race?.id;
  screens.showCamp(waiting ? null : panel);
  if (waiting) { screens.closePanel(true); runCampStory(() => ensureBloodline(() => { if (panel) screens.openPanel(panel); })); }
}

Object.assign(app, {
  openPanel: (id, p) => screens.openPanel(id, p),
  rerender: () => screens.rerender(),
  setUiBusy: (b) => screens.setBusy(b),
  playScene: (id, done) => story.playScene(id, done),
  replayScene: (id) => story.playScene(id, () => screens.rerender()),
  openLore: (id, done) => story.openLore(id, done),
  modal: (content, opts) => screens.modal(content, opts),
  openAwaken: (mode) => awaken.openCeremony(mode, () => screens.rerender()),
  awakenRace() {
    const r = awakenRace(store.get(), rng);
    if (!r.ok) { app.toast('ปลุกสายเลือดไปแล้ว', 'warn'); return r; }
    store.commit(r.state, { reason: 'race' });
    return r;
  },
  rerollRace() {
    const r = rerollRace(store.get(), rng);
    if (!r.ok) { app.toast(r.reason === 'no_bloodstone' ? 'ต้องมีศิลาเปลี่ยนสายเลือด (ได้จากบอส)' : 'สุ่มสายเลือดไม่สำเร็จ', 'warn'); audio.play('error'); return r; }
    store.commit(r.state, { reason: 'race' });
    return r;
  },
  canStartDuel: () => (sceneName === 'camp' || sceneName === 'village') && !story.busy && !awaken.busy && !trade,
  enterVillage() {
    if (!app.online.online) { app.toast(app.online.reason, 'warn', 'net'); audio.play('error'); return; }
    audio.unlock();
    screens.hideAll();
    app.village.show();
    switchScene('village');
  },
  leaveVillage() { app.rooms.leave(); app.village.hide(); arriveCamp(null); },
  // A 1v1 duel accepted from a player card: a match room with the inviter as host on team A.
  startDuel({ room, opponent, host }) {
    const me = app.online.me.peer;
    const roster = host ? { a: [me], b: [opponent.peer] } : { a: [opponent.peer], b: [me] };
    app.startMatch({ roomName: room, mode: '1v1', host: host ? me : opponent.peer, roster, title: `ดวลกับ ${opponent.name}` });
  },
  async startMatch({ room, roomName, mode, host, roster, title }) {
    if (!app.canStartDuel() && !room) return;
    let ch = room;
    if (!ch) {
      try { ch = await app.online.net.join(roomName); }
      catch { app.toast('เข้าสนามประลองไม่ได้ ลองใหม่อีกครั้ง', 'warn'); return; }
    }
    app.village.hide(); screens.hideAll(); closeTrade();
    matchFrom = sceneName === 'village' ? 'village' : 'camp';
    switchScene('match', { room: ch, mode, host, roster, title });
  },
  onMatchEnd(res) {
    const duel = res.mode === '1v1';
    const title = res.result === 'win' ? (duel ? 'ชนะการดวล' : 'ทีมชนะ') : res.result === 'lose' ? (duel ? 'แพ้การดวล' : 'ทีมแพ้') : 'ยกเลิกการประลอง';
    const why = { forfeit: res.result === 'win' ? 'ฝ่ายตรงข้ามออกจากสนาม' : 'คุณยอมแพ้', no_show: 'ผู้เล่นไม่เข้าสนามภายใน 20 วินาที', host_left: 'เจ้าของห้องออกจากสนาม', score: 'ชนะ 2 ใน 3 ยก' }[res.why] || '';
    const st = store.get();
    let close;
    const content = h('div', { class: 'modal panel', 'data-modal': 'duel-result', 'data-result': res.result },
      h('div', { class: 'eyebrow', style: { textAlign: 'center' } }, duel ? `ดวลกับ ${res.opponents.join(', ') || 'คู่ดวล'}` : `${MODES[res.mode].name} · ${TEAM_INFO[res.team].name}`),
      h('h2', { class: res.result === 'win' ? '' : 'lose' }, title),
      h('p', { class: 'muted', style: { margin: 0, textAlign: 'center' } }, why),
      duel ? null : h('p', { class: 'muted', style: { margin: 0, textAlign: 'center', fontSize: 'var(--step--1)' } }, `ทีมคุณ: ${res.allies.join(', ')} · ฝ่ายตรงข้าม: ${res.opponents.join(', ')}`),
      h('div', { class: 'kv' },
        h('div', {}, h('span', { class: 'muted' }, 'ผลยก'), h('b', {}, `${res.score.me} - ${res.score.them}`)),
        h('div', {}, h('span', { class: 'muted' }, 'คอมโบสูงสุด'), h('b', {}, `${res.bestCombo} ฮิต`)),
        h('div', {}, h('span', { class: 'muted' }, 'หลบสมบูรณ์'), h('b', {}, `${res.perfects} ครั้ง`)),
        h('div', {}, h('span', { class: 'muted' }, 'สถิติประลอง'), h('b', {}, `ชนะ ${st.pvp.wins} · แพ้ ${st.pvp.losses}`))),
      h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'button', 'data-action': 'duel-done', onclick: () => close() }, matchFrom === 'village' ? 'กลับหมู่บ้าน' : 'กลับค่าย')));
    close = screens.modal(content, { dismissable: false, onClose: () => { if (matchFrom === 'village' && app.online.online) app.enterVillage(); else arriveCamp(null); } });
  },
  leaveMatch() {
    const m = scenes.match;
    if (sceneName !== 'match' || !m.world || m.world.ended || matchConfirm) return;
    let close;
    const content = h('div', { class: 'modal panel', 'data-modal': 'forfeit' },
      h('h2', {}, 'ยอมแพ้?'),
      h('p', { class: 'muted', style: { margin: 0, textAlign: 'center' } }, 'ออกจากสนามตอนนี้นับเป็นแพ้ ฝ่ายตรงข้ามได้เปรียบทันที'),
      h('div', { class: 'actions' },
        h('button', { class: 'btn danger', type: 'button', 'data-action': 'forfeit', onclick: () => { close(); m.forfeit(); } }, 'ยอมแพ้'),
        h('button', { class: 'btn primary', type: 'button', onclick: () => close() }, 'สู้ต่อ')));
    matchConfirm = true;
    close = screens.modal(content, { onClose: () => { matchConfirm = false; } });
  },
  // ---- online zones
  openZones() { audio.play('click'); openZoneBoard(app); },
  openCrafting() { audio.play('click'); openCrafting(app); },
  openCosmos() { audio.play('click'); openCosmos(app); },
  infiniteLock() {
    const st = store.get();
    if (!st.progress.cleared.s1) return 'ผ่านป่าหนามสนธยาในเนื้อเรื่องก่อน';
    if (st.player.level < 6) return 'ต้องเลเวล 6 ขึ้นไป';
    if (entriesLeft(st) <= 0) return 'วันนี้ใช้สิทธิ์ครบแล้ว กลับมาใหม่พรุ่งนี้';
    return null;
  },
  startInfinite() {
    const lock = app.infiniteLock();
    if (lock) { app.toast(lock, 'warn'); return; }
    // the entry is spent the moment the rift opens
    const next = cloneState(store.get()), day = dayKey();
    if (next.infinite.day !== day) { next.infinite.day = day; next.infinite.used = 0; }
    next.infinite.used += 1;
    store.commit(next, { reason: 'infinite-entry' });
    const dead = { name: 'solo', emit: async () => {}, on: () => () => {}, presence: async () => {}, peers: () => [], onPeers: () => () => {}, connected: () => false, leave: async () => {} };
    audio.unlock();
    app.village.hide(); screens.hideAll(); closeTrade();
    zoneFrom = sceneName === 'village' ? 'village' : 'camp';
    switchScene('coop', { room: dead, zone: infiniteZone(1), host: app.online.me.peer || 'me', roster: [app.online.me.peer || 'me'], title: 'รอยแยกไร้สิ้นสุด' });
  },
  zoneLock: (id) => { const z = getZone(id); return z ? zoneLock(store.get(), z) : 'ไม่พบโซน'; },
  startZoneSolo(zoneId) {
    const z = getZone(zoneId);
    if (!z || zoneLock(store.get(), z)) return;
    const dead = { name: 'solo', emit: async () => {}, on: () => () => {}, presence: async () => {}, peers: () => [], onPeers: () => () => {}, connected: () => false, leave: async () => {} };
    app.startZone({ room: dead, zoneId, host: app.online.me.peer || 'me', roster: [app.online.me.peer || 'me'], title: z.name });
  },
  // An expedition room in the lobby that others join from the room list (village).
  async openExpedition(zoneId) {
    if (sceneName !== 'village') { if (!app.online.online) return; app.enterVillage(); }
    const r = await app.rooms.create('coop', '', zoneId);
    if (!r.ok) { app.toast(r.reason === 'view_only' ? 'บัญชีนี้ดูได้อย่างเดียว' : 'เปิดคณะสำรวจไม่สำเร็จ', 'warn'); return; }
    app.village.openRooms();
  },
  startZone({ room, zoneId, host, roster, title }) {
    const zone = getZone(zoneId);
    if (!zone) return;
    if (zoneLock(store.get(), zone)) { app.toast(`ยังเข้า${zone.name}ไม่ได้: ${zoneLock(store.get(), zone)}`, 'warn'); room.leave?.(); return; }
    audio.unlock();
    app.village.hide(); screens.hideAll(); closeTrade();
    zoneFrom = sceneName === 'village' ? 'village' : 'camp';
    switchScene('coop', { room, zone, host, roster, title });
  },
  onZoneEnd(res) {
    app.hud.hide();
    const { outcome, zone, reward, run } = res;
    if (reward?.infinite) { infiniteResult(res); return; }
    const title = outcome === 'victory' ? 'พิชิตโซน!' : outcome === 'defeat' ? 'คณะสำรวจล้ม' : outcome === 'host_left' ? 'หัวหน้าคณะออกไป' : 'ถอนตัว';
    let close;
    const content = h('div', { class: 'modal panel', 'data-modal': 'zone-result', 'data-outcome': outcome },
      h('div', { class: 'eyebrow', style: { textAlign: 'center' } }, `${zone.name}${res.party > 1 ? ` · ${res.party} คน` : ''}`),
      h('h2', { class: outcome === 'victory' ? '' : 'lose' }, title),
      reward ? h('div', { class: 'notice ok' }, `รางวัลพิชิต${reward.first ? 'ครั้งแรก' : ''}: ${reward.gold} ทอง · ประกายอำพัน ${reward.sparks} · ประสบการณ์ ${reward.xp}`) : h('p', { class: 'muted', style: { margin: 0, textAlign: 'center' } }, 'ของที่เก็บได้ระหว่างทางยังอยู่ในกระเป๋า'),
      h('div', { class: 'kv' },
        h('div', {}, h('span', { class: 'muted' }, 'กำจัด'), h('b', {}, `${run.kills} ตัว`)),
        h('div', {}, h('span', { class: 'muted' }, 'เวลา'), h('b', {}, `${Math.floor(run.seconds / 60)}:${String(run.seconds % 60).padStart(2, '0')}`)),
        h('div', {}, h('span', { class: 'muted' }, 'ทอง'), h('b', {}, `+${run.gold}`)),
        h('div', {}, h('span', { class: 'muted' }, 'ประสบการณ์'), h('b', {}, `+${run.xp}`)),
        h('div', {}, h('span', { class: 'muted' }, 'คอมโบสูงสุด'), h('b', {}, `${run.bestCombo} ฮิต`)),
        h('div', {}, h('span', { class: 'muted' }, 'หลบสมบูรณ์'), h('b', {}, `${run.perfects} ครั้ง`))),
      run.levelUps ? h('div', { class: 'notice ok' }, `เลเวลอัป ${run.levelUps} ครั้ง`) : null,
      h('div', { class: 'eyebrow' }, `ของที่ได้ (${run.items.length} ชนิด)`),
      run.items.length ? h('div', { class: 'loot-grid' }, run.items.map((it) => { const def = getItem(it.id); return h('div', { class: `cell r-${def.rarity}`, title: def.name }, itemImg(it.id), h('span', { class: 'qty' }, it.qty)); })) : h('div', { class: 'empty-note' }, 'รอบนี้ไม่ได้ไอเทม'),
      res.saveOk ? null : h('div', { class: 'notice' }, 'บันทึกเกมไม่สำเร็จ'),
      h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'button', 'data-action': 'zone-done', onclick: () => close() }, zoneFrom === 'village' ? 'กลับหมู่บ้าน' : 'กลับค่าย')));
    close = screens.modal(content, { dismissable: false, onClose: () => { if (zoneFrom === 'village' && app.online.online) app.enterVillage(); else arriveCamp(null); } });
  },
  leaveZone() {
    const c = scenes.coop;
    if (sceneName !== 'coop' || !c.world || c.world.ended || zoneConfirm) return;
    let close;
    const content = h('div', { class: 'modal panel', 'data-modal': 'zone-pause' },
      h('h2', {}, 'พักการสำรวจ'),
      c.world.inf ? h('p', { class: 'muted', style: { margin: 0, textAlign: 'center' } }, `ออกตอนนี้ได้รับเหรียญ ${c.world.inf.coins.toLocaleString('th-TH')} และอาร์ติแฟกต์ ${c.world.inf.arts.length} ชิ้นที่สะสมไว้ทั้งหมด`) :
      h('p', { class: 'muted', style: { margin: 0, textAlign: 'center' } }, c.world.party > 1 ? 'เกมไม่หยุดระหว่างเล่นกับเพื่อน ถอนตัวแล้วของที่เก็บได้ยังอยู่ แต่ไม่ได้รางวัลพิชิต' : 'ถอนตัวแล้วของที่เก็บได้ยังอยู่ แต่ไม่ได้รางวัลพิชิต'),
      settingsBlock(),
      h('div', { class: 'actions' },
        h('button', { class: 'btn danger', type: 'button', 'data-action': 'zone-retreat', onclick: () => { close(); c.retreat(); } }, 'ถอนตัว'),
        h('button', { class: 'btn primary', type: 'button', onclick: () => close() }, 'สู้ต่อ')));
    zoneConfirm = true;
    close = screens.modal(content, { onClose: () => { zoneConfirm = false; } });
  },
  // A trade accepted from a player card: both open the trade window in a 'trade-<id>' room.
  async startTrade({ room, partner, host, rid }) {
    if (trade || !app.canStartDuel()) return;
    let ch;
    try { ch = await app.online.net.join(room); }
    catch { app.toast('เปิดการแลกเปลี่ยนไม่ได้ ลองใหม่อีกครั้ง', 'warn'); return; }
    const link = createTradeLink(app, { ch, tid: rid, host, partner });
    trade = { link, ui: null };
    app.online.publish({ b: 'trade' });
    trade.ui = openTradeUi(app, link);
  },
  onTradeClosed() { trade = null; if (app.gameActive) app.online.publish({ b: ZONE[sceneName]?.b ?? null }); },
  inBattle: () => sceneName === 'battle' && !!scenes.battle.world && !scenes.battle.world.ended && !scenes.battle.world.paused,
  continueGame() {
    audio.unlock();
    app.gameActive = true;
    const storyWaiting = !!nextCampScene(store.get()) || !store.get().race?.id;
    arriveCamp(null);
    // after an update: the patch notes, once (not over a story scene that is about to play)
    if (hasUnseenNotes() && !storyWaiting) setTimeout(() => app.openPatchNotes(), 200);
  },
  openPatchNotes(opts) { return openPatchNotes(app, opts); },
  newGame() {
    audio.unlock();
    story.askName((name) => {
      app.gameActive = true;
      saves.clear();
      const fresh = createNewState();
      fresh.story.name = name;
      store.commit(fresh, { reason: 'new-game' });
      markSeen();                                   // a new hero starts on this version: nothing to announce
      app.refreshHeroSprites();
      arriveCamp('stages');
    });
  },
  renameHero(raw) {
    const next = cloneState(store.get());
    next.story.name = cleanHeroName(raw);
    store.commit(next, { reason: 'rename' });
    app.toast(`เปลี่ยนชื่อเป็น ${next.story.name} แล้ว`, 'ok');
  },
  startBattle(stageId) {
    audio.unlock();
    screens.hideAll();
    switchScene('battle', { stageId });
  },
  onBattleEnd(result) {
    app.hud.hide();
    screens.openResult(result);
  },
  goCamp(panel) { arriveCamp(panel); },
  pauseBattle() {
    if (sceneName === 'match') { app.leaveMatch(); return; }
    if (sceneName === 'coop') { app.leaveZone(); return; }
    const w = scenes.battle.world;
    if (sceneName !== 'battle' || !w || w.paused || w.ended || story.busy || awaken.busy) return;
    scenes.battle.pause();
    audio.play('click');
    screens.openPause();
  },
  resumeBattle() { if (sceneName === 'battle') scenes.battle.resume(); },
  retreat() { scenes.battle.resume(); scenes.battle.retreat(); },
  updateSettings(s) {
    const next = cloneState(store.get());
    next.settings = { ...next.settings, ...s };
    store.commit(next, { reason: 'settings' });
    audio.setVolumes(next.settings.sfx, next.settings.music);
    renderer.setShakeEnabled(next.settings.shake && !reducedMotion.matches);
  },
  deleteSave() {
    app.gameActive = false;
    saves.clear();
    store.commit(createNewState(), { reason: 'reset', persist: false });
    app.refreshHeroSprites();
    screens.showTitle({ hasSave: false, summary: null, notice: null });
    app.toast('ลบเซฟแล้ว', 'ok');
  },
});

let matchFrom = 'village', matchConfirm = false, trade = null, zoneFrom = 'camp', zoneConfirm = false;
const settingsBlock = () => null;
function closeTrade() { if (trade) trade.ui?.close(); }
let lastLook = '';
store.subscribe((st, reason) => {
  if (screens.campVisible) { screens.renderTop(st); screens.rerender(); }
  // other players see my new gear, bloodline, pet and name right away
  const look = JSON.stringify(lookOf(st));
  if (app.gameActive && look !== lastLook) { lastLook = look; app.online.refreshLook(); }
});

// Connects in the background; the game never waits for the network.
async function connectOnline() {
  let net;
  try {
    net = await Promise.race([createNet({ mode: netMode, localId: saveSlot ? `local-${saveSlot}` : null, slot: saveSlot, rtc: params.get('rtc') !== 'off', ice: params.get('ice') || '' }), new Promise((r) => setTimeout(() => r(null), 12000))]);
  } catch { net = null; }
  if (!net) net = await createNet({ mode: 'offline' });
  if (net.mode === 'offline' && netMode === 'auto' && net.reason) { /* reason is shown where online features live */ }
  app.online.destroy?.();
  app.online = createOnline(app, net);
  app.online.on('duel', (ev) => app.startDuel(ev));
  app.online.on('trade', (ev) => app.startTrade(ev));
  app.online.on('guild', async (ev) => {
    const r = await app.guild.join(ev.gid);
    if (r.ok) { app.toast(`เข้าร่วมกิลด์ ${r.name} แล้ว`, 'ok'); audio.play('success'); }
    else app.toast(r.reason === 'already_in_guild' ? 'คุณอยู่ในกิลด์อื่นอยู่แล้ว' : r.reason === 'guild_full' ? 'กิลด์เต็มแล้ว' : r.reason === 'not_invited' ? 'คำเชิญหมดอายุแล้ว' : 'เข้ากิลด์ไม่สำเร็จ', 'warn');
  });
  app.guild.attach(net.docs || null);
  let countKey = '';
  app.online.on('peers', (list) => {
    const key = `${list.length}|${list.filter((x) => x.p.zone === 'village').length}`;
    if (key !== countKey) { countKey = key; if (screens.campVisible && screens.currentPanel === 'stages') screens.rerender(); }
  });
  app.village.rewire();
  if (app.gameActive) app.online.publish(ZONE[sceneName] || ZONE.camp);
  if (screens.campVisible) screens.rerender();
}

// ---------------------------------------------------------------- lifecycle
function resize() { renderer.resize(); buildVignette(); }
window.addEventListener('resize', resize);
window.addEventListener('orientationchange', () => setTimeout(resize, 150));
const unlockAudio = () => audio.unlock();
window.addEventListener('pointerdown', unlockAudio, { capture: true });
window.addEventListener('keydown', unlockAudio, { capture: true });
reducedMotion.addEventListener?.('change', () => particles.setScale(reducedMotion.matches ? 0.4 : 1));

const loop = createLoop((dt) => {
  if (!scene) return;
  scene.update(dt);
  scene.render();
});
loop.onHidden(() => {
  // Persist whatever was picked up so far and pause the fight while the tab is hidden.
  if (app.gameActive) saves.save(store.get());
  if (sceneName === 'battle') app.pauseBattle();
  audio.suspend();
});
document.addEventListener('visibilitychange', () => { if (!document.hidden) audio.resume(); });

window.addEventListener('error', (e) => {
  console.error(e.error || e.message);
  app.toast('เกิดข้อผิดพลาดในเกม รายละเอียดอยู่ใน console', 'warn', 'err');
});

// Read-only hook for automated tests and debugging. It does not change game state.
window.__EMBERHOLD = {
  get state() { return JSON.parse(JSON.stringify(store.get())); },
  ...(DEV_HOST ? { devResign: (key) => saves.resign(key), devWound: (f) => scenes.coop.devWound(f) } : {}),
  get scene() { return sceneName; },
  get battle() {
    const w = scenes.battle.world;
    if (!w || sceneName !== 'battle' || !w.room) return null;
    const rt = w.room;
    return {
      phase: w.phase, stage: w.stage.id, paused: w.paused, ended: w.ended, fading: w.fadeDir !== 0,
      room: { id: rt.def.id, type: rt.def.type, cleared: rt.cleared, chestOpened: rt.chestOpened, bonfireUsed: rt.bonfireUsed },
      keys: w.keys, unsealed: w.unsealed,
      doors: w.doors.map((d) => ({ dir: d.dir, to: d.to })),
      objects: w.objects.map((o) => ({ kind: o.kind, x: Math.round(o.x), y: Math.round(o.y), id: o.id || null, key: !!o.def?.key })),
      interact: w.interactTarget ? w.interactTarget.kind : null,
      visited: [...w.rooms.values()].filter((r) => r.visited).map((r) => r.def.id),
      rooms: w.dungeon.rooms.map((r) => ({ id: r.id, type: r.type, doors: doorsOf(w.dungeon, r).map((d) => ({ dir: d.dir, to: d.to })), cleared: w.rooms.get(r.id).cleared, key: !!r.chest?.key })),
      enemies: w.enemies.filter((e) => !e.dead).map((e) => ({ id: e.id, x: Math.round(e.x), y: Math.round(e.y), hp: e.hp, state: e.state, warn: Math.round((e.warn || 0) * 100) / 100, spawning: e.spawning > 0 })),
      player: { x: Math.round(w.player.x), y: Math.round(w.player.y), hp: Math.ceil(w.player.hp), maxHp: w.player.maxHp, dead: w.player.dead, swings: w.player.swings, potionCd: w.player.potionCd.left, shield: w.player.shield,
                wtype: w.player.wtype.id, move: w.player.move ? { kind: w.player.move.kind, step: w.player.move.step, phase: w.player.move.phase, name: w.player.move.def.name } : null,
                dodges: w.player.dodges, moveCounts: { ...w.player.moveCounts }, charging: w.player.charging, chargeReady: w.player.chargeReady, empowered: w.player.empowerT > 0, rush: !!w.player.rush,
                buffs: { ...w.player.buffs }, atk: w.player.stats.atk, speed: w.player.stats.speed },
      skills: w.skills.map((s) => (s ? { id: s.id, cd: s.cd } : null)),
      raceSkill: w.raceSkill ? { id: w.raceSkill.id, cd: w.raceSkill.cd } : null,
      pet: w.pet ? { id: w.pet.id, x: Math.round(w.pet.x), y: Math.round(w.pet.y), cd: w.pet.cd } : null,
      combo: { ...w.combo }, perfects: w.perfects, breaks: w.breaks, slowmo: w.slowT > 0,
      boss: (() => { const b = w.enemies.find((e) => e.type.boss && !e.dead); return b ? { poise: Math.round(b.poise ?? 100), broken: b.brokenT > 0, hp: b.hp } : null; })(),
      traps: w.traps.length, drops: w.drops.length, projectiles: w.projectiles.length, shots: w.shots.length, zones: w.zones.length,
    };
  },
  get online() {
    const o = app.online;
    return { mode: o.mode, online: o.online, canSend: o.canSend(), me: o.me, peers: o.peers.map((x) => ({ peer: x.peer, by: x.by, name: x.p.name, zone: x.p.zone, busy: x.p.busy, race: x.p.race, weapon: x.p.weapon })),
             requests: o.requests.map((r) => ({ rid: r.rid, kind: r.kind, from: r.from.name })), party: o.party ? { leader: o.party.leader, members: o.party.members.map((m) => m.name) } : null, chat: o.chat.map((c) => ({ ch: c.ch, name: c.name, text: c.text, me: c.me })), links: o.net?.stats?.() || null };
  },
  get village() { return sceneName === 'village' ? scenes.village.snapshot() : null; },
  get arena() { return sceneName === 'match' ? scenes.match.snapshot() : null; },
  get coop() { return sceneName === 'coop' ? scenes.coop.snapshot() : null; },
  get guild() { const g = app.guild.current; return g ? { id: g.id, name: g.name, tag: g.tag, notice: g.notice, leader: g.leader, members: Object.fromEntries(Object.entries(g.members).map(([k, m]) => [k, { name: m.name, role: m.role }])) } : null; },
  get room() { const c = app.rooms.current; return c ? { id: c.id, mode: c.mode, host: c.amHost, roster: c.roster, ready: { ...c.ready } } : null; },
  get rooms() { return app.rooms.list(); },
  get trade() { if (!trade) return null; const s = trade.link.state; return { mine: s.mine, theirs: s.theirs, myLock: s.myLock, theirLock: s.theirLock, applied: s.applied }; },
  get camera() { return { x: Math.round(renderer.cam.x), y: Math.round(renderer.cam.y), zoom: Math.round(renderer.cam.zoom * 1000) / 1000 }; },
  get dialogue() { return story.busy; },
  get awakening() { return awaken.busy; },
  persistent,
  seed,
};

async function boot() {
  resize();
  // Validate content at boot so broken data fails loudly instead of silently mis-dropping.
  const problems = Object.values(ALL_ENEMIES).flatMap((e) => validateDropTable(e.drops, e.id));
  if (problems.length) console.error('Drop table problems:', problems);

  screens.loading.progress(0, 'กำลังวาดตัวละครและฉาก…');
  try { await loadArt(); }
  catch (e) { screens.loading.error(`${e.message} ลองรีโหลดหน้า`); console.error(e); return; }
  try { await document.fonts?.ready; } catch { /* fonts are optional */ }

  const loaded = saves.load();
  let notice = loaded.error || null;
  if (loaded.state) {
    store.commit(loaded.state, { reason: 'load', persist: false });
    if (loaded.warnings?.length) notice = `ซ่อมแซมเซฟแล้ว: ${loaded.warnings.join(' · ')}`;
  }
  if (!persistent) notice = (notice ? notice + ' · ' : '') + 'เบราว์เซอร์นี้ไม่อนุญาตให้บันทึก ความคืบหน้าจะหายเมื่อปิดหน้า';
  const st = store.get();
  audio.setVolumes(st.settings.sfx, st.settings.music);
  renderer.setShakeEnabled(st.settings.shake && !reducedMotion.matches);
  app.refreshHeroSprites();

  switchScene('camp');
  loop.start();
  connectOnline();
  screens.showTitle({
    hasSave: !!loaded.state,
    summary: loaded.state ? { level: st.player.level, gold: st.gold, cleared: Object.keys(st.progress.cleared).length } : null,
    notice,
  });
}

boot();
