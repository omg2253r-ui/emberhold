// Online zone run (ดันเจี้ยนรวม): up to 4 players fight through 2 rooms and a boss room of one of the ten zones.
// The host (whoever opened the run) simulates the monsters and the zone mechanic and shares them:
//   • presence `en` — every monster's position, HP and pose (absolute state, ~12×/s)
//   • presence `rs` — room index and phase (fight / clear / victory / defeat)
//   • 'match' events — strikes, pools, projectiles, gusts, contact hits, damage numbers, kills (batched ~10×/s)
// Every player simulates their own hero, resolves telegraphed strikes / pools / projectiles against their own hero,
// and reports their hits on monsters to the host. Loot is personal: each player rolls their own drops on a kill.
// Alone (or offline) the same scene runs with the local player as host and nobody else in the room.
import { BALANCE } from '../config/balance.js';
import { getItem } from '../data/items.js';
import { rarityOf } from '../data/rarity.js';
import { getEnemy } from '../data/enemies.js';
import { ZONE_ROOM, PARTY_HP_SCALE, clearReward } from '../data/zones.js';
import { ZONE_ENEMY_IDS } from '../data/enemies.js';
import { cloneState } from '../core/state.js';
import { computeDamage, comboBonus } from '../systems/combat.js';
import { rollDrops, rollGold } from '../systems/loot.js';
import { addItem, removeItem, countItem } from '../systems/inventory.js';
import { computeStats } from '../systems/stats.js';
import { grantXpInPlace } from '../systems/progression.js';
import { slottedSkills } from '../systems/skills.js';
import { createPlayer, updatePlayer, damagePlayer, applyStats, inPerfectWindow } from '../battle/player.js';
import { createEnemy, updateEnemy, separate } from '../battle/enemies.js';
import '../battle/zoneBehaviours.js';
import { createDrop, updateDrop, drawDrop } from '../battle/drops.js';
import { createFx } from '../battle/fx.js';
import { createSkillBar, tickSkills, castSkill, updateSnares, drawSnares } from '../battle/skills.js';
import { drawHero } from '../battle/heroDraw.js';
import { playerPose } from '../battle/weaponPose.js';
import { createShot, updateShots, drawShot, updateZones, drawZones, updateCones } from '../battle/playerShots.js';
import { applyBurn, applyMark, poiseHit, tickStatus, drawStatus } from '../battle/status.js';
import { createRaceSkill, tickRaceSkill, castRaceSkill } from '../battle/raceSkills.js';
import { createPetEntity, updatePet, drawPet } from '../battle/pets.js';
import { activePet } from '../systems/pets.js';
import { createEffects, updateEffects, addStrike, addPool, addShot, addGust, drawPools, drawStrikes, drawShots, drawGusts } from '../battle/strikes.js';
import { createMechanic, ZONE_FLAGS, drawMechanicFloor } from '../battle/zoneMechanics.js';
import { fighterPresence, updateRemoteFighter } from '../online/pvp.js';
import { lookOf, readPresence, PROTOCOL } from '../online/protocol.js';
import { paintZoneRoom } from './zoneBackdrop.js';

const CB = BALANCE.combat;
const A = ZONE_ROOM;
const GONE_AFTER = 4;
const REVIVE_TIME = 2.5, REVIVE_RANGE = 85;
const SEND_EVERY = 0.083;          // presence ~12×/s (shares the room's ~40 msg/s budget with events)
const EVENTS_EVERY = 0.1;
const EVENT_BYTES = 3300;
const PORTAL = { x: A.w - 140, y: A.h / 2 + 20, r: 80 };
const ENTRY = { x: 170, y: A.h / 2 + 20 };

const num = (v, lo, hi, d = 0) => (typeof v === 'number' && Number.isFinite(v) ? Math.max(lo, Math.min(hi, v)) : d);

export function createCoopScene(app) {
  const { renderer, input, store, audio, sprites, rng } = app;
  const ctx = renderer.ctx;
  let w = null;

  // ------------------------------------------------------------ world
  function makeWorld({ room, zone, host, roster, title }) {
    const st = store.get();
    const stats = computeStats(st);
    const me = app.online.me.peer || 'me';
    const party = Math.max(1, roster.length);
    const wd = {
      room, zone, host, amHost: host === me || !host, me, roster: [...roster], party, title,
      arena: { w: A.w, h: A.h }, wallPad: A.wall, flags: ZONE_FLAGS[zone.mechanic] || {},
      rng, time: 0, stopT: 0, slowT: 0, phase: 'waiting', phaseT: 0, ri: 0, rphase: 'fight', wave: -1, queue: [],
      player: createPlayer(stats, ENTRY.x, ENTRY.y), enemies: [], views: new Map(), allies: new Map(), drops: [],
      fxs: createEffects(), fx: createFx(), particles: app.particles,
      skills: createSkillBar(slottedSkills(st)), raceSkill: createRaceSkill(st.race?.id, stats.skillCdMult),
      pet: createPetEntity(activePet(st), ENTRY.x - 40, ENTRY.y),
      shots: [], zones: [], cones: [], snares: [],
      combo: { n: 0, t: 0, best: 0 }, perfects: 0, breaks: 0, keys: 0, lastStandUsed: false, vacuum: false,
      run: { gold: 0, sparks: 0, xp: 0, kills: 0, items: new Map(), levelUps: 0, start: performance.now(), bestCombo: 0, perfects: 0 },
      ended: false, paused: false, outbox: [], evAcc: 0, sendAcc: 0, nextId: 1, reviveT: 0, darkT: 0, slide: { vx: 0, vy: 0 },
      floor: null, unsub: [], lastRs: '', hostGone: 0, mech: null, seenHost: false, lastFullWarn: -10, statusMods: { slow: 1, ice: false },
      look: lookOf(st), seenRooms: new Set(),
    };
    wd.mech = wd.amHost ? createMechanic(zone, wd) : null;
    for (const peer of roster) if (peer !== me) wd.allies.set(peer, { peer, r: BALANCE.player.radius, goneT: 0, seen: false, x: null, y: null, hp: 1, maxHp: 1, vx: 0, vy: 0, name: '…' });
    installWorldApi(wd);
    return wd;
  }

  // The API the shared combat code and the zone behaviours call.
  function installWorldApi(wd) {
    const p = wd.player;
    wd.sfx = (n, o) => audio.play(n, o);
    wd.shake = (m, t) => renderer.shake(m, t);
    wd.hitStop = (t) => { wd.stopT = Math.max(wd.stopT, Math.min(0.08, t)); };
    wd.screenToWorld = (sx, sy) => renderer.screenToWorld(sx, sy);
    wd.toast = (...a) => app.toast(...a);
    wd.announce = (text) => { app.hud.banner(text, ''); if (wd.amHost) queue(['ann', String(text).slice(0, 60)]); };
    wd.clampBody = (b) => { b.x = Math.max(A.wall + b.r, Math.min(A.w - A.wall - b.r, b.x)); b.y = Math.max(A.wall + b.r + 20, Math.min(A.h - A.wall + 10, b.y)); };
    wd.cutProjectiles = (cx, cy, dir, range, arc) => 0;
    wd.addSnare = (z) => wd.snares.push(z);
    wd.addHazard = (h) => wd.strike({ shape: h.type === 'line' ? 'line' : 'circle', x: h.x, y: h.y, r: h.r, angle: h.angle, len: h.len, width: h.width, dur: h.dur, mult: 0, owner: h.owner });
    wd.addCone = (c) => wd.cones.push(c);
    wd.addZone = (z) => { wd.zones.push({ ...z, t: 0, done: false }); audio.play('cast', { power: 1.6 }); };
    wd.firePlayerShot = (o) => wd.shots.push(createShot(o));
    wd.usePotion = () => usePotion();
    wd.collect = (d) => collect(d);
    wd.onPlayerSwing = (def, kind) => {
      const t = p.wtype.id;
      if (t === 'bow') audio.play('bow', { power: kind === 'charged' ? 1.6 : 1 });
      else if (t === 'staff') audio.play('cast', { power: kind === 'charged' ? 1.6 : def.power });
      else audio.play('swing', { power: Math.min(1.8, 0.7 + def.power * 0.45) });
    };
    wd.onPlayerDash = (blink) => audio.play(blink ? 'blink' : 'dash');
    wd.onChargeReady = () => audio.play('charge');
    wd.onLastStand = () => { app.hud.banner('ผู้ไม่มอด', 'รอดจากความตาย'); audio.play('roar'); };
    wd.onPlayerDeath = () => { audio.play('defeat'); renderer.shake(10, 0.5); if (wd.party > 1) app.hud.banner('ถูกล้ม', 'ให้เพื่อนยืนข้างตัวเพื่อชุบชีวิต'); };
    wd.perfectDodge = () => {
      if (p.perfectUsed || p.dead) return;
      p.perfectUsed = true; wd.slowT = CB.perfect.slowmo; p.empowerT = CB.perfect.empowerT; p.dodges = Math.min(p.dodgeMax, p.dodges + 1);
      wd.perfects += 1; wd.run.perfects += 1;
      wd.fx.callout(p.x, p.y - 120, 'หลบสมบูรณ์!', '#bfe3ff'); wd.fx.ring(p.x, p.y - 30, 20, 120, '#bfe3ff', 0.5, 6);
      audio.play('perfect'); app.hud.flash?.('perfect');
    };

    // --- my hits on monsters (host: apply now; others: report to the host)
    wd.playerStrike = (e, power, o = {}) => {
      if (!e || e.dead || e.spawning > 0 || e.untargetable) return null;
      const st = p.stats, b = p.buffs;
      let mult = power * (1 + comboBonus(wd.combo.n) + (b.blessT > 0 ? b.bless : 0) + (b.ashT > 0 && wd.raceSkill ? wd.raceSkill.v.dmg : 0));
      if (o.src === 'skill' || o.src === 'race') mult *= st.skillPower || 1;
      const empowered = p.empowerT > 0 && (o.src === 'melee' || o.src === 'proj' || o.src === undefined);
      if (empowered) { mult *= 1 + CB.perfect.empowerPower; p.empowerT = 0; }
      const crit = st.crit + (o.critBonus || 0) + (b.focusT > 0 && wd.raceSkill ? wd.raceSkill.v.crit || 0 : 0);
      const counts = o.src !== 'burn' && o.src !== 'pet';
      if (counts) bumpCombo();
      const pkt = { atk: st.atk, crit: Math.min(0.75, crit), critMult: st.critMult, forceCrit: !!(o.forceCrit || empowered), power: mult, heavy: o.src === 'skill' || o.src === 'race' ? Math.max(power, 1.2) : power, kx: o.kx || 0, ky: o.ky || 0, stun: o.stun || 0, burn: !!(o.burn || b.ashT > 0 || (st.ignite > 0 && rng.next() < st.ignite)), src: o.src || 'melee' };
      if (wd.amHost) return applyHit(e, pkt, wd.me);
      queue(['hit', e.id, pkt]);
      e.flash = 1;
      wd.particles.burst(e.x, e.y - e.r, 6, { color: ['#fff8ea', '#f3e6c8'], speedMin: 80, speedMax: 240, life: 0.25, size: 2.5, drag: 5, glow: true });
      audio.play('hit');
      return { amount: 0, crit: false };
    };
    wd.petStrike = (e, power, o = {}) => wd.playerStrike(e, power, { ...o, src: 'pet' });

    // --- monster side (host only); `wd.player` is the monster's current target while its behaviour runs
    wd.hitPlayer = (e, mult, kx, ky, fire = false) => {
      const t = wd.player;
      if (!t || t.dead) return false;
      if (t === p) return hurtMe(e, mult, kx, ky, fire);
      queue(['hurt', t.peer, Math.round(mult * 100) / 100, Math.round(e.atk), Math.round(kx), Math.round(ky), fire ? 1 : 0]);
      return true;
    };
    wd.strike = (s) => {
      const atk = Math.round(s.owner?.atk ?? 10);
      addStrike(wd.fxs, { ...s, owner: { atk, crit: 0, critMult: 1.5 } });
      queue(['s', packStrike(s, atk)]);
    };
    wd.pool = (pl) => {
      const atk = Math.round(pl.owner?.atk ?? wd.zoneAtk ?? 10);
      addPool(wd.fxs, { ...pl, owner: { atk, crit: 0, critMult: 1 } });
      queue(['p', { x: Math.round(pl.x), y: Math.round(pl.y), r: pl.r, dur: pl.dur, kind: pl.kind, mult: pl.mult || 0, atk }]);
    };
    wd.shoot = (e, o) => {
      const atk = Math.round(e?.atk ?? 10);
      const tgt = o.homing ? (wd.player === p ? wd.me : wd.player?.peer) : null;
      addShot(wd.fxs, { ...o, owner: { atk, crit: 0, critMult: 1.5 }, target: tgt === wd.me ? 'me' : tgt });
      queue(['b', { ...o, x: Math.round(o.x), y: Math.round(o.y), angle: Math.round(o.angle * 1000) / 1000, atk, target: tgt, pool: o.pool || null, orbit: o.orbit || null }]);
    };
    wd.gust = (angle, dur, force) => { addGust(wd.fxs, { angle, dur, force }); queue(['g', Math.round(angle * 1000) / 1000, dur, force]); };
    wd.darkPulse = (t) => { wd.darkT = Math.max(wd.darkT, t); queue(['dark', t]); };
    wd.spawnEnemy = (id, x, y) => spawnEnemy(id, x, y);
    wd.selfDestruct = (e) => { killEnemy(e, false); };
    wd.damageEnemy = (e, dmg, kx, ky, opt = {}) => damageEnemy(e, dmg, kx, ky, opt);
    wd.trapHitEnemy = () => {};
    Object.defineProperty(wd, 'players', { get: () => targets() });
  }

  // ------------------------------------------------------------ outgoing events (host and my hits)
  function queue(ev) { if (w && w.party > 1) w.outbox.push(ev); }
  function flush() {
    if (!w.outbox.length) return;
    let batch = [], size = 0;
    for (const ev of w.outbox) {
      const s = JSON.stringify(ev).length;
      if (size + s > EVENT_BYTES && batch.length) { w.room.emit('match', { k: 'ev', l: batch }); batch = []; size = 0; }
      batch.push(ev); size += s;
    }
    if (batch.length) w.room.emit('match', { k: 'ev', l: batch });
    w.outbox.length = 0;
  }
  function packStrike(s, atk) {
    const r = (v) => (typeof v === 'number' ? Math.round(v * 100) / 100 : undefined);
    return { shape: s.shape, x: r(s.x), y: r(s.y), r: r(s.r), inner: r(s.inner), angle: r(s.angle), len: r(s.len), width: r(s.width), arc: typeof s.arc === 'number' ? r(s.arc) : undefined,
      lob: s.arc && typeof s.arc === 'object' ? { x: r(s.arc.x), y: r(s.arc.y) } : undefined, w: r(s.w), h: r(s.h),
      dur: r(s.dur), mult: r(s.mult), fire: s.fire ? 1 : 0, kb: r(s.kb), tone: s.tone, meteor: s.meteor ? 1 : 0, then: s.then || undefined, atk };
  }

  // ------------------------------------------------------------ incoming events
  function onMessage(m) {
    if (!w || m.sameTab) return;
    const d = m.data || {};
    if (d.k !== 'ev' || !Array.isArray(d.l)) return;
    const fromHost = m.peer === w.host;
    const fromMember = w.allies.has(m.peer);
    if (!fromHost && !fromMember) return;
    for (const ev of d.l.slice(0, 120)) {
      if (!Array.isArray(ev)) continue;
      const [k] = ev;
      if (k === 'hit' && w.amHost && fromMember) {
        const e = w.enemies.find((x) => x.id === ev[1]);
        if (e) applyHit(e, ev[2] || {}, m.peer);
        continue;
      }
      if (!fromHost || w.amHost) continue;
      if (k === 's') receiveStrike(ev[1]);
      else if (k === 'p') { const pl = ev[1] || {}; addPool(w.fxs, { x: num(pl.x, 0, A.w), y: num(pl.y, 0, A.h), r: num(pl.r, 10, 300, 60), dur: num(pl.dur, 0.2, 30, 3), kind: pl.kind, mult: num(pl.mult, 0, 2), owner: { atk: num(pl.atk, 0, 500, 10), crit: 0, critMult: 1 } }); }
      else if (k === 'b') receiveShot(ev[1]);
      else if (k === 'g') addGust(w.fxs, { angle: num(ev[1], -10, 10), dur: num(ev[2], 0.2, 4, 1.2), force: num(ev[3], 0, 600, 240) });
      else if (k === 'dark') w.darkT = Math.max(w.darkT, num(ev[1], 0, 10));
      else if (k === 'ann') app.hud.banner(String(ev[1] || '').slice(0, 60), '');
      else if (k === 'hurt' && ev[1] === w.me) hurtMe({ atk: num(ev[3], 0, 500, 10), crit: 0, critMult: 1.5 }, num(ev[2], 0, 5, 1), num(ev[4], -900, 900), num(ev[5], -900, 900), !!ev[6]);
      else if (k === 'dmg') { const v = w.views.get(ev[1]); if (v) { w.fx.number(v.x, v.y - v.r * 2 - 10, Math.max(1, ev[2] | 0), ev[3] ? 'crit' : 'hit'); v.flash = 1; } }
      else if (k === 'kill') onKill(ev[1], ev[2], num(ev[3], 0, A.w), num(ev[4], 0, A.h), !!ev[5]);
      else if (k === 'spawn') { w.fx.ring(num(ev[2], 0, A.w), num(ev[3], 0, A.h) - 10, 10, 60, '#e0b45a', 0.5, 4); audio.play('spawn'); }
    }
  }
  function receiveStrike(s) {
    if (!s || typeof s !== 'object' || !['circle', 'ring', 'line', 'cone', 'rect'].includes(s.shape)) return;
    const pool = s.then?.pool;
    addStrike(w.fxs, {
      shape: s.shape, x: num(s.x, -500, 3000), y: num(s.y, -500, 3000), r: num(s.r, 0, 2000), inner: num(s.inner, 0, 2000), angle: num(s.angle, -20, 20), len: num(s.len, 0, 3000), width: num(s.width, 0, 600),
      arc: s.lob ? { x: num(s.lob.x, -500, 3000), y: num(s.lob.y, -500, 3000) } : num(s.arc, 0, 7), w: num(s.w, 0, 3000), h: num(s.h, 0, 3000),
      dur: num(s.dur, 0.05, 6, 1), mult: num(s.mult, 0, 4), fire: !!s.fire, kb: s.kb == null ? undefined : num(s.kb, -900, 900), tone: typeof s.tone === 'string' ? s.tone.slice(0, 10) : 'fire', meteor: !!s.meteor,
      then: pool ? { pool: { kind: String(pool.kind || 'poison').slice(0, 8), r: num(pool.r, 10, 300, 60), dur: num(pool.dur, 0.2, 20, 3), mult: num(pool.mult, 0, 2) } } : undefined,
      owner: { atk: num(s.atk, 0, 500, 10), crit: 0, critMult: 1.5 },
    });
  }
  function receiveShot(o) {
    if (!o || typeof o !== 'object') return;
    addShot(w.fxs, {
      x: num(o.x, -200, 3000), y: num(o.y, -200, 3000), angle: num(o.angle, -20, 20), speed: num(o.speed, 0, 1500, 300), r: num(o.r, 2, 80, 10), mult: num(o.mult, 0, 4, 1),
      kind: typeof o.kind === 'string' ? o.kind.slice(0, 10) : 'orb', homing: num(o.homing, 0, 5), pierce: !!o.pierce, life: num(o.life, 0.2, 10, 4), fire: !!o.fire, ground: !!o.ground,
      pool: o.pool ? { kind: String(o.pool.kind || 'poison').slice(0, 8), r: num(o.pool.r, 10, 300, 60), dur: num(o.pool.dur, 0.2, 20, 3) } : null,
      orbit: o.orbit ? { cx: num(o.orbit.cx, 0, 3000), cy: num(o.orbit.cy, 0, 3000), r0: num(o.orbit.r0, 0, 500), grow: num(o.orbit.grow, -200, 400), spin: num(o.orbit.spin, -10, 10) } : null,
      target: o.target === w.me ? 'me' : typeof o.target === 'string' ? o.target : null, owner: { atk: num(o.atk, 0, 500, 10), crit: 0, critMult: 1.5 },
    });
  }

  // ------------------------------------------------------------ monsters (host)
  function spawnEnemy(id, x, y) {
    const def = getEnemy(id);
    if (!def) return null;
    const e = createEnemy(id, x, y, 1);
    e.id = w.nextId++;
    e.ti = ZONE_ENEMY_IDS.indexOf(def.id);
    e.maxHp = e.hp = Math.round(def.hp * (1 + PARTY_HP_SCALE * (w.party - 1)));
    e.zid = def.id;
    w.enemies.push(e);
    w.fx.ring(x, y - 10, 10, 60, '#e0b45a', 0.5, 4);
    audio.play('spawn');
    queue(['spawn', e.id, Math.round(x), Math.round(y)]);
    if (def.boss) { app.hud.setBoss(def.name, 1); audio.play('roar'); renderer.shake(8, 0.5); }
    return e;
  }

  function applyHit(e, pkt, from) {
    if (e.dead || e.untargetable) return null;
    const power = num(pkt.power, 0, 20), atk = num(pkt.atk, 0, 600);
    if (!(power > 0) || !(atk > 0)) return null;
    let mult = power;
    if (e.markT > 0) mult *= 1 + (e.mark || 0);
    if (e.brokenT > 0) mult *= 1 + CB.poise.breakBonus;
    // shields: a guarded front takes much less; the feather monk answers with a counter
    if (e.type.guardFront && e.guarding) {
      const hitFrom = Math.atan2((from === w.me ? w.player.y : w.allies.get(from)?.y ?? e.y) - e.y, (from === w.me ? w.player.x : w.allies.get(from)?.x ?? e.x) - e.x);
      let d = hitFrom - (e.ai.face ?? 0); while (d > Math.PI) d -= Math.PI * 2; while (d < -Math.PI) d += Math.PI * 2;
      if (Math.abs(d) < 1.2) { mult *= 1 - e.type.guardFront; w.fx.number(e.x, e.y - e.r * 2 - 26, 'โล่!', 'info'); }
    }
    if (e.type.ai === 'counter' && e.guarding) { mult *= 0.3; e.ai.countered = true; }
    const dmg = computeDamage({ atk, crit: num(pkt.crit, 0, 0.75), critMult: num(pkt.critMult, 1, 6, 1.5), forceCrit: !!pkt.forceCrit }, e, rng, mult);
    damageEnemy(e, dmg, num(pkt.kx, -900, 900), num(pkt.ky, -900, 900), { power: num(pkt.heavy, 0, 5, 1), src: pkt.src });
    if (!e.dead) {
      if (pkt.stun && !e.type.boss) e.hitstun = Math.max(e.hitstun, num(pkt.stun, 0, 2));
      if (pkt.src !== 'burn' && poiseHit(e, num(pkt.heavy, 0, 5, 1))) onPoiseBreak(e);
      if (pkt.burn && pkt.src !== 'burn') applyBurn(e);
    }
    return dmg;
  }

  function damageEnemy(e, dmg, kx, ky, opt = {}) {
    if (e.dead) return;
    e.hp = Math.max(0, e.hp - dmg.amount);
    e.flash = opt.src === 'burn' ? 0.4 : 1;
    e.vx += kx / e.type.mass; e.vy += ky / e.type.mass;
    if (!e.type.boss && opt.src !== 'burn') {
      if ((opt.power ?? 1) >= (e.type.interruptAt ?? 1.2)) { e.hitstun = Math.max(e.hitstun, 0.2); if (e.state === 'windup') { e.state = 'recover'; e.t = 0; e.warn = 0; } }
      else if (!(e.flinchCd > 0)) { e.hitstun = Math.max(e.hitstun, 0.07); e.flinchCd = 0.5; }
    }
    w.fx.number(e.x, e.y - e.r * 2 - 10, dmg.amount, dmg.crit ? 'crit' : opt.src === 'burn' ? 'burn' : 'hit');
    if (opt.src !== 'burn') w.particles.burst(e.x, e.y - e.r, dmg.crit ? 14 : 7, { color: dmg.crit ? ['#ffcf5a', '#fff3c4', '#ff8a3d'] : ['#fff8ea', '#f3e6c8'], speedMin: 90, speedMax: 300, life: 0.3, size: dmg.crit ? 3.5 : 2.5, drag: 5, glow: true });
    if (opt.src !== 'burn') audio.play(dmg.crit ? 'crit' : 'hit');
    queue(['dmg', e.id, dmg.amount, dmg.crit ? 1 : 0]);
    if (e.type.boss) app.hud.setBoss(e.type.name, e.hp / e.maxHp);
    if (e.hp <= 0) {
      if (e.type.revive && !e.revived) { e.revived = true; e.hp = 1; e.state = 'ash'; e.t = 0; e.warn = 0; w.fx.callout(e.x, e.y - 90, 'ลุกจากเถ้า…', '#ff8a3d'); return; }
      killEnemy(e, true);
    }
  }

  function onPoiseBreak(e) {
    w.breaks += 1;
    e.state = 'rest'; e.t = 0; e.warn = 0; if (e.ai) e.ai.z = 0;
    for (let i = w.fxs.strikes.length - 1; i >= 0; i--) if (w.fxs.strikes[i].ownerId === e.id) w.fxs.strikes.splice(i, 1);
    w.fx.callout(e.x, e.y - e.r * 2 - 40, 'เสียหลัก!', '#f5d48a');
    audio.play('crit'); renderer.shake(8, 0.3);
  }

  function killEnemy(e, rewarded) {
    if (e.dead) return;
    e.dead = true; e.deathT = 0;
    if (e.type.split) for (let i = 0; i < e.type.split.count; i++) spawnEnemy(e.type.split.id, e.x + (i ? 40 : -40), e.y + 10);
    queue(['kill', e.id, e.ti, Math.round(e.x), Math.round(e.y), rewarded ? 1 : 0]);
    onKill(e.id, e.ti, e.x, e.y, rewarded);
  }

  // Everyone (host included) runs this when a monster dies: effects, and MY personal rewards.
  function onKill(id, ti, x, y, rewarded) {
    const def = getEnemy(ZONE_ENEMY_IDS[ti]);
    const v = w.views.get(id);
    if (v) { v.dead = true; v.deathT = 0; }
    if (!def) return;
    audio.play('enemyDie');
    w.particles.burst(x, y - (def.radius || 20), def.boss ? 60 : 16, { color: def.particles || ['#8a3b2e', '#5d6b3a', '#b5603f'], speedMin: 80, speedMax: def.boss ? 420 : 240, life: 0.7, size: def.boss ? 6 : 4, drag: 3, shape: 1 });
    if (def.boss) { renderer.shake(14, 0.6); app.hud.setBoss(null); }
    if (!rewarded || w.player.dead) return;
    const p = w.player;
    if (p.stats.healOnKill > 0) { const heal = Math.round(p.maxHp * p.stats.healOnKill); p.hp = Math.min(p.maxHp, p.hp + heal); w.fx.number(p.x, p.y - 96, `+${heal}`, 'heal'); }
    const next = cloneState(store.get());
    next.stats.kills += 1;
    const levels = grantXpInPlace(next, def.xp);
    store.commit(next, { reason: 'kill', persist: false });
    w.run.xp += def.xp; w.run.kills += 1;
    if (levels > 0) {
      w.run.levelUps += levels;
      applyStats(p, computeStats(next));
      p.hp = Math.min(p.maxHp, p.hp + Math.round(p.maxHp * 0.25));
      audio.play('levelup'); app.hud.banner(`เลเวล ${next.player.level}`, 'ได้แต้มสกิล 1 แต้ม');
    }
    const gold = Math.round(rollGold(def.gold, rng) * (p.stats.goldMult || 1));
    if (def.sparks) w.drops.push(createDrop('spark', 'spark', def.sparks, x, y, rng));
    const coins = Math.min(4, Math.max(1, Math.round(gold / 10)));
    for (let i = 0; i < coins; i++) w.drops.push(createDrop('gold', 'gold', Math.max(1, Math.round(gold / coins)), x, y, rng));
    for (const d of rollDrops(def.drops, rng)) w.drops.push(createDrop('item', d.id, d.qty, x, y, rng));
  }

  // Who the monsters can go after: me and every party member still standing here.
  function targets() {
    const list = [];
    if (!w.player.dead) list.push(w.player);
    for (const a of w.allies.values()) if (a.seen && a.goneT < GONE_AFTER && !a.ko && a.x != null) list.push(a);
    return list;
  }
  function pickTarget(e, list) {
    const cur = e.ai.tgt && list.includes(e.ai.tgt) ? e.ai.tgt : null;
    if (cur && (e.ai.tgtT || 0) > 0) return cur;
    let best = list[0], bd = Infinity;
    for (const t of list) { const d = Math.hypot(t.x - e.x, t.y - e.y) * (t === cur ? 0.8 : 1); if (d < bd) { bd = d; best = t; } }
    e.ai.tgt = best; e.ai.tgtT = 2 + rng.next();
    return best;
  }

  // ------------------------------------------------------------ my hero
  function hurtMe(owner, mult, kx, ky, fire = false, tick = false) {
    const p = w.player;
    if (p.dead || w.rphase === 'victory') return false;
    if (p.iframes > 0 && !tick) { if (inPerfectWindow(p)) w.perfectDodge(); return false; }
    const st = p.stats;
    const def = st.def * (st.lowHpDef && p.hp < p.maxHp * 0.3 ? 1 + st.lowHpDef : 1);
    let amount = computeDamage(owner, { def }, rng, mult).amount;
    if (fire && st.fireReduce) amount = Math.max(1, Math.round(amount * (1 - st.fireReduce)));
    if (tick) {
      p.hp = Math.max(0, p.hp - amount);
      w.fx.number(p.x, p.y - 70, amount, 'player');
      if (p.hp <= 0) { p.dead = true; p.deathT = 0; p.move = null; w.onPlayerDeath(); }
      return true;
    }
    if (!damagePlayer(p, amount, kx, ky, w)) return false;
    if (w.combo.n >= 5) w.fx.callout(p.x, p.y - 120, 'คอมโบขาด', '#ff9a8a');
    w.combo.n = 0;
    audio.play('hurt'); renderer.shake(7, 0.22); app.hud.hurt();
    w.particles.burst(p.x, p.y - 30, 10, { color: ['#c2412f', '#ff6b57'], speedMin: 80, speedMax: 220, life: 0.4, size: 3, drag: 4 });
    return true;
  }

  function bumpCombo() {
    w.combo.n += 1; w.combo.t = 0;
    if (w.combo.n > w.combo.best) w.combo.best = w.combo.n;
    if (w.combo.n > w.run.bestCombo) w.run.bestCombo = w.combo.n;
    for (const t of CB.combo.tiers) if (w.combo.n === t.at) { audio.play('wave'); w.fx.callout(w.player.x, w.player.y - 120, `คอมโบ ${t.at}! ดาเมจ +${Math.round(t.bonus * 100)}%`, '#ffd08a'); }
  }

  function usePotion() {
    const p = w.player;
    if (p.potionCd.left > 0) { app.toast(`ยาพร้อมใช้ในอีก ${p.potionCd.left.toFixed(1)} วินาที`, 'warn', 'potion-cd'); audio.play('error'); return; }
    const st = store.get();
    if (countItem(st, 'p_tonic') <= 0) { app.toast('ไม่มียาฟื้นพลังในกระเป๋า', 'warn', 'potion-none'); audio.play('error'); return; }
    if (p.hp >= p.maxHp) { app.toast('พลังชีวิตเต็มอยู่แล้ว', 'info', 'potion-full'); return; }
    const r = removeItem(st, 'p_tonic', 1);
    if (!r.ok) return;
    store.commit(r.state, { reason: 'potion', persist: false });
    const before = p.hp;
    p.hp = Math.min(p.maxHp, p.hp + Math.round(p.maxHp * CB.potion.healPct));
    p.potionCd.left = CB.potion.cooldown;
    w.fx.number(p.x, p.y - 80, `+${p.hp - before}`, 'heal');
    audio.play('potion');
  }

  function collect(d) {
    const st = store.get();
    if (d.kind === 'spark' || d.kind === 'gold') {
      const next = cloneState(st);
      if (d.kind === 'spark') { next.sparks = (next.sparks || 0) + d.qty; w.run.sparks += d.qty; audio.play('pickup', { rarity: 3 }); }
      else { next.gold += d.qty; w.run.gold += d.qty; audio.play('gold'); }
      store.commit(next, { reason: d.kind, persist: false });
      w.fx.number(w.player.x + 18, w.player.y - 90, d.kind === 'spark' ? `ประกาย +${d.qty}` : `+${d.qty}`, 'info');
      return true;
    }
    const r = addItem(st, d.id, d.qty);
    if (!r.ok) {
      if (w.time - w.lastFullWarn > 3) { app.toast('กระเป๋าเต็ม ขายหรือใช้ของก่อนเก็บเพิ่ม', 'warn', 'bag-full'); audio.play('error'); w.lastFullWarn = w.time; }
      return false;
    }
    store.commit(r.state, { reason: 'loot', persist: false });
    w.run.items.set(d.id, (w.run.items.get(d.id) || 0) + d.qty);
    const def = getItem(d.id), rar = rarityOf(def.rarity);
    app.toast(`${def.name} ×${d.qty}`, 'loot', null, { itemId: d.id, rarity: def.rarity });
    audio.play('pickup', { rarity: rar.order });
    return true;
  }

  // ------------------------------------------------------------ rooms (host decides, everyone follows `rs`)
  function startRoom(ri) {
    w.ri = ri; w.rphase = 'fight'; w.phaseT = 0; w.wave = -1; w.queue.length = 0;
    w.enemies.length = 0; w.views.clear();
    w.fxs.strikes.length = 0; w.fxs.pools.length = 0; w.fxs.shots.length = 0; w.fxs.gusts.length = 0;
    const p = w.player;
    // walking into a new room picks up whatever was left behind and wakes downed heroes
    for (const d of w.drops) collect(d);
    w.drops.length = 0;
    if (p.dead) { p.dead = false; p.deathT = 0; p.hp = Math.round(p.maxHp * 0.5); p.iframes = 1.5; }
    p.x = ENTRY.x + (rng.next() - 0.5) * 40; p.y = ENTRY.y + (rng.next() - 0.5) * 160; p.vx = p.vy = 0;
    if (w.pet) { w.pet.x = p.x - 40; w.pet.y = p.y; }
    w.floor = paintZoneRoom(w.zone.theme, A, ri * 31 + w.zone.n * 7);
    const def = w.zone.rooms[ri];
    app.hud.roomTitle(def === 'boss' ? `ห้องบอส · ${w.zone.name}` : `${w.zone.name} · ห้อง ${ri + 1}/${w.zone.rooms.length}`, w.zone.mechanicText);
    if (w.amHost) { w.mech?.reset(ri); publishRs(); }
  }

  function nextWave() {
    const def = w.zone.rooms[w.ri];
    const waves = def === 'boss' ? [[[w.zone.boss, 1]]] : [def.slice(0, Math.ceil(def.length / 2)), def.slice(Math.ceil(def.length / 2))];
    w.wave += 1;
    if (w.wave >= waves.length) return false;
    let i = 0;
    for (const [id, count] of waves[w.wave]) for (let c = 0; c < count; c++) {
      const boss = getEnemy(id)?.boss;
      const x = boss ? A.w * 0.62 : A.w * (0.45 + rng.next() * 0.42), y = boss ? A.h * 0.48 : A.h * (0.25 + rng.next() * 0.55);
      w.queue.push({ id, x, y, delay: 0.25 + i * 0.18 });
      i++;
    }
    return true;
  }

  function hostRoomFlow(dt) {
    for (let i = w.queue.length - 1; i >= 0; i--) { const q = w.queue[i]; q.delay -= dt; if (q.delay <= 0) { spawnEnemy(q.id, q.x, q.y); w.queue.splice(i, 1); } }
    const everyoneDown = targets().length === 0 && w.phaseT > 1;
    if (everyoneDown && w.rphase !== 'defeat' && w.rphase !== 'victory') { w.rphase = 'defeat'; w.phaseT = 0; publishRs(); onPhase('defeat'); return; }
    if (w.rphase === 'fight') {
      const alive = w.queue.length > 0 || w.enemies.some((e) => !e.dead && e.zid !== 'z_pylon');
      if (!alive && w.phaseT > 0.6) {
        w.enemies.forEach((e) => { if (e.zid === 'z_pylon' && !e.dead) killEnemy(e, false); });
        if (!nextWave()) {
          const last = w.ri >= w.zone.rooms.length - 1;
          w.rphase = last ? 'victory' : 'clear'; w.phaseT = 0; publishRs(); onPhase(w.rphase);
        } else w.phaseT = 0;
      }
    } else if (w.rphase === 'clear') {
      // the portal opens: everyone standing walks in (or 10 s after the first one does)
      const standing = targets();
      const inside = standing.filter((t) => Math.hypot(t.x - PORTAL.x, t.y - PORTAL.y) < PORTAL.r);
      if (inside.length) w.portalT = (w.portalT || 0) + dt; else w.portalT = 0;
      if (standing.length && (inside.length === standing.length || w.portalT > 10)) { w.portalT = 0; startRoom(w.ri + 1); nextWave(); }
    }
  }

  function publishRs() { w.room.presence({ rs: { ri: w.ri, ph: w.rphase } }); }

  // phase changes are shown the same way for the host and everyone else
  function onPhase(ph) {
    if (ph === 'clear') { audio.play('unlock'); app.hud.banner('ห้องนี้สงบแล้ว', 'เดินเข้าประตูมิติทางขวาเพื่อไปต่อ'); w.vacuum = true; }
    else if (ph === 'victory') { audio.play('victory'); app.hud.banner('พิชิตโซน!', w.zone.name); w.vacuum = true; }
    else if (ph === 'defeat') { audio.play('defeat'); app.hud.banner('คณะสำรวจล้มทั้งหมด', ''); }
  }

  function followHost(dt) {
    const hostP = w.room.peers().find((x) => x.peer === w.host);
    const ally = w.allies.get(w.host);
    if (!hostP || ally?.goneT > GONE_AFTER) {
      if (ally?.seen || w.phaseT > 20) finish('host_left');
      return;
    }
    w.seenHost = true;
    const raw = hostP.presence || {};
    // monsters as the host sees them
    if (Array.isArray(raw.en)) readEnemies(raw.en, dt);
    const rs = raw.rs;
    if (rs && typeof rs === 'object') {
      const key = `${rs.ri}|${rs.ph}`;
      if (key !== w.lastRs) {
        w.lastRs = key;
        const ri = Math.max(0, Math.min(w.zone.rooms.length - 1, rs.ri | 0));
        if (ri !== w.ri || w.phase === 'waiting') { w.phase = 'run'; startRoom(ri); }
        if (['clear', 'victory', 'defeat'].includes(rs.ph) && w.rphase !== rs.ph) { w.rphase = rs.ph; w.phaseT = 0; onPhase(rs.ph); }
        else if (rs.ph === 'fight') w.rphase = 'fight';
      }
    }
  }

  function readEnemies(list, dt) {
    const seen = new Set();
    for (const row of list.slice(0, 60)) {
      if (!Array.isArray(row)) continue;
      const [id, ti, x, y, hp, maxHp, warn, flags, hidden, z] = row;
      const def = getEnemy(ZONE_ENEMY_IDS[ti]);
      if (!def || typeof id !== 'number') continue;
      seen.add(id);
      let v = w.views.get(id);
      if (!v) { v = { id, type: def, r: def.radius, x, y, sx: 1, sy: 1, ai: {}, spawning: 0, dead: false, flash: 0, isView: true }; w.views.set(id, v); }
      v.tx = num(x, 0, A.w); v.ty = num(y, 0, A.h);
      const k = Math.min(1, dt * 12);
      v.x += (v.tx - v.x) * k; v.y += (v.ty - v.y) * k;
      v.hp = num(hp, 0, 1e7); v.maxHp = num(maxHp, 1, 1e7, 1); v.warn = num(warn, 0, 10) / 10;
      v.flip = !!(flags & 1); v.guarding = !!(flags & 2); v.untargetable = !!(flags & 4); v.hidden = num(hidden, 0, 10) / 10; v.ai.z = num(z, 0, 300);
      if (def.boss) app.hud.setBoss(def.name, v.hp / v.maxHp);
    }
    for (const [id, v] of w.views) if (!seen.has(id) && !v.dead) { v.dead = true; v.deathT = 0; }
  }

  function packEnemies() {
    return w.enemies.filter((e) => !e.dead || e.deathT < 0.05).slice(0, 40).map((e) => [
      e.id, e.ti, Math.round(e.x), Math.round(e.y), Math.ceil(e.hp), e.maxHp, Math.round((e.warn || 0) * 10),
      (e.flip ? 1 : 0) | (e.guarding ? 2 : 0) | (e.untargetable ? 4 : 0), Math.round((e.hidden || 0) * 10), Math.round(e.ai?.z || 0),
    ]);
  }

  // ------------------------------------------------------------ allies
  function readAllies(dt) {
    const peers = w.room.peers();
    const byPeer = new Map(peers.map((x) => [x.peer, x]));
    for (const a of w.allies.values()) {
      const x = byPeer.get(a.peer);
      const raw = x?.presence;
      if (!raw || raw.v !== PROTOCOL || x.sameTab) { a.goneT += dt; continue; }
      a.goneT = 0; a.seen = true;
      const px = a.x, py = a.y;
      updateRemoteFighter(a, raw, dt);
      if (px != null && dt > 0) { a.vx = (a.x - px) / dt; a.vy = (a.y - py) / dt; }
      const c = readPresence(raw);
      a.name = c?.name || 'นักล่า'; a.look = c ? { a: c.armor, r: c.race, w: c.weapon, pet: c.pet } : a.look;
      a.ko = raw.st === 'ko'; a.dead = a.ko;
      if (a.newActive) remoteSwingFx(a);
    }
  }

  function remoteSwingFx(r) {
    const d = r.move?.def; if (!d) return;
    const t = r.wtype.trail, h = d.hit;
    if (h.shape === 'arc') {
      if (['thrust', 'stab', 'stabB'].includes(d.anim)) w.fx.thrust(r.x, r.y - 18, r.move.dir, h.range, t.color, t.glow, d.power);
      else w.fx.slash(r.x, r.y - 18, r.move.dir, (h.arc * Math.PI) / 180, h.range * 0.82, d.power * t.width, t.color, d.anim === 'slashUp' || d.anim === 'heavyUp', t.glow);
    } else if (h.shape === 'circle') {
      const ox = r.x + Math.cos(r.move.dir) * (h.forward || 0), oy = r.y - 10 + Math.sin(r.move.dir) * (h.forward || 0);
      w.fx.ring(ox, oy, 12, h.r, t.glow, 0.42, 8);
    }
  }

  // A downed hero gets back up when a friend stands beside them long enough.
  function reviveCheck(dt) {
    const p = w.player;
    if (!p.dead || w.party < 2) { w.reviveT = 0; return; }
    const helper = [...w.allies.values()].some((a) => a.seen && !a.ko && a.goneT < GONE_AFTER && a.x != null && Math.hypot(a.x - p.x, a.y - p.y) < REVIVE_RANGE);
    w.reviveT = helper ? w.reviveT + dt : Math.max(0, w.reviveT - dt * 0.5);
    if (w.reviveT >= REVIVE_TIME) {
      w.reviveT = 0; p.dead = false; p.deathT = 0; p.hp = Math.round(p.maxHp * 0.4); p.iframes = 2;
      w.fx.ring(p.x, p.y - 30, 10, 120, '#9fe0a0', 0.7, 6); audio.play('levelup'); app.hud.banner('กลับมาสู้ต่อ!', 'เพื่อนช่วยพยุงขึ้น');
    }
  }

  // ------------------------------------------------------------ end
  function finish(outcome) {
    if (w.ended) return;
    w.ended = true;
    input.setEnabled(false);
    for (const d of w.drops) collect(d);
    w.drops.length = 0;
    const next = cloneState(store.get());
    next.stats.runs += 1;
    let reward = null;
    if (outcome === 'victory') {
      const first = !next.zones.cleared[w.zone.id];
      reward = clearReward(w.zone, first);
      next.zones.cleared[w.zone.id] = (next.zones.cleared[w.zone.id] || 0) + 1;
      const secs = Math.round((performance.now() - w.run.start) / 1000);
      if (!next.zones.best[w.zone.id] || secs < next.zones.best[w.zone.id]) next.zones.best[w.zone.id] = secs;
      next.gold += reward.gold; next.sparks += reward.sparks;
      w.run.levelUps += grantXpInPlace(next, reward.xp);
      w.run.gold += reward.gold; w.run.sparks += reward.sparks; w.run.xp += reward.xp;
      reward.first = first;
    }
    const save = store.commit(next, { reason: 'zone-end' });
    app.onZoneEnd({
      outcome, zone: w.zone, reward, saveOk: save.ok, party: w.party,
      run: { gold: w.run.gold, sparks: w.run.sparks, xp: w.run.xp, kills: w.run.kills, levelUps: w.run.levelUps, bestCombo: w.run.bestCombo, perfects: w.run.perfects,
             items: [...w.run.items.entries()].map(([id, qty]) => ({ id, qty })), seconds: Math.round((performance.now() - w.run.start) / 1000) },
    });
  }

  // ------------------------------------------------------------ frame
  function update(dt) {
    if (!w || w.ended) return;
    const intent = input.poll();
    if (intent.pause) { app.leaveZone(); }
    if (w.stopT > 0) { w.stopT -= dt; renderer.update(dt); return; }
    if (w.slowT > 0) w.slowT -= dt;
    const edt = w.slowT > 0 ? dt * CB.perfect.timeScale : dt;
    w.time += edt; w.phaseT += dt;
    if (w.darkT > 0) w.darkT -= dt;
    w.fx.update(dt); w.particles.update(edt); renderer.update(dt);
    tickSkills(w.skills, dt); tickRaceSkill(w.raceSkill, dt);

    readAllies(dt);
    if (w.amHost) {
      if (w.phase === 'waiting') {
        const all = [...w.allies.values()];
        if (all.every((a) => a.seen) || w.phaseT > 12) { w.phase = 'run'; startRoom(0); nextWave(); }
      }
    } else followHost(dt);
    if (w.ended) return;

    // my hero
    const p = w.player;
    const prevX = p.x, prevY = p.y;
    if (!p.dead) {
      if (intent.skill >= 0) castSkill(w.skills, intent.skill, w);
      if (intent.race) castRaceSkill(w);
      w.enemies = w.amHost ? w.enemies : [...w.views.values()].filter((v) => !v.dead && !v.untargetable);
      updatePlayer(p, intent, dt, w);
      // zone ground: sand and webs slow, ice keeps you sliding
      const mods = w.statusMods;
      if (mods.slow < 1 && !(p.dashT > 0)) { p.x = prevX + (p.x - prevX) * mods.slow; p.y = prevY + (p.y - prevY) * mods.slow; }
      if ((w.flags.slippery || mods.ice) && !(p.dashT > 0)) {
        const vx = (p.x - prevX) / Math.max(dt, 1e-3), vy = (p.y - prevY) / Math.max(dt, 1e-3);
        const k = Math.min(1, dt * 3.2);
        w.slide.vx += (vx - w.slide.vx) * k; w.slide.vy += (vy - w.slide.vy) * k;
        p.x = prevX + w.slide.vx * dt; p.y = prevY + w.slide.vy * dt;
      } else { w.slide.vx = (p.x - prevX) / Math.max(dt, 1e-3); w.slide.vy = (p.y - prevY) / Math.max(dt, 1e-3); }
      w.clampBody(p);
      let regen = p.stats.regen || 0;
      if (p.buffs.bloomT > 0 && w.raceSkill) regen += w.raceSkill.v.heal / w.raceSkill.v.duration;
      if (regen > 0 && p.hp < p.maxHp) p.hp = Math.min(p.maxHp, p.hp + p.maxHp * regen * dt);
    } else p.deathT += dt;
    p.vx = (p.x - prevX) / Math.max(dt, 1e-3); p.vy = (p.y - prevY) / Math.max(dt, 1e-3);
    reviveCheck(dt);
    w.combo.t += dt;
    if (w.combo.n > 0 && w.combo.t > CB.combo.resetAfter) w.combo.n = 0;

    // monsters (host simulates; their target is set per monster)
    if (w.amHost && w.phase === 'run') {
      const list = targets();
      for (const e of w.enemies) {
        if (list.length && !e.dead) { e.ai.tgtT = (e.ai.tgtT || 0) - edt; w.player = pickTarget(e, list); }
        updateEnemy(e, edt, w);
        w.player = p;
        tickStatus(e, edt, w);
      }
      separate(w.enemies);
      for (let i = w.enemies.length - 1; i >= 0; i--) if (w.enemies[i].dead && w.enemies[i].deathT > 0.6) w.enemies.splice(i, 1);
      w.mech?.update(edt, list);
      hostRoomFlow(dt);
      const boss = w.enemies.find((e) => e.type.boss && !e.dead);
      if (boss) app.hud.setPoise?.(boss.poise ?? CB.poise.max, boss.brokenT > 0);
    } else {
      for (const v of w.views.values()) { if (v.flash > 0) v.flash -= dt * 6; if (v.dead) v.deathT += dt; }
      for (const [id, v] of w.views) if (v.dead && v.deathT > 0.6) w.views.delete(id);
    }

    // effects against my own hero
    w.statusMods = updateEffects(w.fxs, edt, {
      me: p, arena: A, particles: w.particles, sfx: (n) => audio.play(n), shake: (m, t) => renderer.shake(m, t),
      hurt: (owner, mult, kx, ky, fire, tick) => hurtMe(owner, mult, kx, ky, fire, tick),
      posOf: (peer) => w.allies.get(peer) || null,
    });
    for (let i = w.drops.length - 1; i >= 0; i--) if (!updateDrop(w.drops[i], dt, w)) w.drops.splice(i, 1);
    if (w.vacuum && w.drops.length === 0) w.vacuum = false;
    updateSnares(w.snares, edt, w);
    updateShots(w.shots, dt, w);
    updateZones(w.zones, dt, w);
    updateCones(w.cones, dt, w);
    if (!p.dead) updatePet(w.pet, dt, w);

    // the end: solo death ends the run at once; victory waits for the loot to fly in
    if (w.party === 1 && p.dead && p.deathT > 1.6 && w.rphase !== 'victory') { finish('defeat'); return; }
    if (w.rphase === 'victory' && w.phaseT > 2.4 && w.drops.length === 0) { finish('victory'); return; }
    if (w.rphase === 'victory' && w.phaseT > 6) { finish('victory'); return; }
    if (w.rphase === 'defeat' && w.phaseT > 2) { finish('defeat'); return; }

    // network
    w.sendAcc += dt;
    if (w.sendAcc >= SEND_EVERY && w.party > 1) {
      w.sendAcc = 0;
      const pres = fighterPresence(p, w.look, p.dead ? 'ko' : w.phase === 'waiting' ? 'ready' : 'fight');
      if (w.amHost) { pres.en = packEnemies(); pres.rs = { ri: w.ri, ph: w.rphase }; }
      w.room.presence(pres);
    }
    w.evAcc += dt;
    if (w.evAcc >= EVENTS_EVERY) { w.evAcc = 0; flush(); }

    // in the portal?
    w.inPortal = w.rphase === 'clear' && Math.hypot(p.x - PORTAL.x, p.y - PORTAL.y) < PORTAL.r;
    app.hud.setInteract(w.rphase === 'clear' ? (w.inPortal ? (w.party > 1 ? 'รอเพื่อนเข้าประตู…' : 'กำลังเข้าประตู…') : 'เดินเข้าประตูมิติทางขวา') : null);
    camera(dt);
    app.hud.update(p, w);
  }

  function camera(dt) {
    const cam = renderer.cam, v = renderer.view, p = w.player;
    const landscape = app.touch && v.w > v.h;
    const top = landscape ? 50 : app.touch ? 130 : 60, bottom = landscape ? 8 : app.touch ? 240 : 76;
    const byH = (v.h - top - bottom) / (A.h - A.wall * 2 + 60), byW = v.w / (A.w + 40);
    cam.zoom = Math.max(0.5, Math.min(1.2, v.w < v.h ? byH : Math.min(byW, byH)));
    const hw = v.w / 2 / cam.zoom, hh = (v.h - top - bottom) / 2 / cam.zoom, shiftY = (top - bottom) / 2 / cam.zoom;
    const tx = A.w <= hw * 2 ? A.w / 2 : Math.max(hw, Math.min(A.w - hw, p.x));
    const ty = (A.h - A.wall * 2 <= hh * 2 ? A.h / 2 : Math.max(hh + A.wall / 2, Math.min(A.h - hh - A.wall / 2, p.y - 30))) - shiftY;
    const k = Math.min(1, dt * 7);
    cam.x += (tx - cam.x) * k; cam.y += (ty - cam.y) * k;
  }

  // ------------------------------------------------------------ drawing
  function drawShadow(x, y, rx) { ctx.fillStyle = 'rgba(12,8,6,0.38)'; ctx.beginPath(); ctx.ellipse(x, y, rx, rx * 0.35, 0, 0, Math.PI * 2); ctx.fill(); }

  function drawEnemy(e) {
    const s = sprites[e.type.sprite];
    if (!s) return;
    const z = e.ai?.z || 0;
    const spawnK = e.spawning > 0 ? 1 - e.spawning / 0.7 : 1;
    const hid = e.hidden || 0;
    drawShadow(e.x, e.y, e.r * (1 - z / 160) * spawnK * (1 - hid * 0.6));
    if (hid >= 0.95) return;
    const alpha = (e.dead ? Math.max(0, 1 - (e.deathT || 0) / 0.5) : spawnK) * (1 - hid * 0.85);
    const scale = (e.type.boss ? 1.0 : 0.72) * (e.type.scale || 1);
    renderer.sprite(s, e.x, e.y - z, { flip: e.type.faces ? e.flip : false, sx: (e.sx || 1) * scale * spawnK, sy: (e.sy || 1) * scale * spawnK, flash: e.flash > 0 ? e.flash : (e.warn ? 0.25 + 0.35 * Math.abs(Math.sin(w.time * 22)) : 0), alpha });
    if (!e.isView) drawStatus(ctx, e, w.time, s.h * scale + z);
    if (e.guarding && !e.dead) {
      ctx.save(); ctx.strokeStyle = e.type.ai === 'counter' ? 'rgba(191,227,255,0.85)' : 'rgba(255,207,90,0.8)'; ctx.lineWidth = 4;
      const a = e.ai?.face ?? (e.flip ? Math.PI : 0);
      ctx.beginPath(); if (e.type.ai === 'counter') ctx.ellipse(e.x, e.y - 40, 40, 52, 0, 0, Math.PI * 2); else ctx.arc(e.x, e.y - 30, e.r + 16, a - 0.9, a + 0.9); ctx.stroke(); ctx.restore();
    }
    if (e.warn > 0 && !e.dead) {
      const hy = e.y - s.h * scale - 12 - z;
      ctx.fillStyle = '#e0503a'; ctx.strokeStyle = '#1a100c'; ctx.lineWidth = 3; ctx.font = '900 22px system-ui, sans-serif'; ctx.textAlign = 'center';
      ctx.strokeText('!', e.x, hy); ctx.fillText('!', e.x, hy);
    }
    if (!e.type.boss && !e.dead && e.hp < e.maxHp) {
      const bw = e.r * 1.8, by = e.y - s.h * scale - 4 - z;
      ctx.fillStyle = 'rgba(20,12,9,0.8)'; ctx.fillRect(e.x - bw / 2 - 1, by - 1, bw + 2, 6);
      ctx.fillStyle = '#c2412f'; ctx.fillRect(e.x - bw / 2, by, bw * (e.hp / e.maxHp), 4);
    }
  }

  function drawMe(p) {
    drawShadow(p.x, p.y, 22);
    if (p.charging && p.charge > 0) {
      const k = Math.min(1, p.charge / p.wtype.chargeTime);
      ctx.save(); ctx.strokeStyle = p.chargeReady ? '#fff3c4' : 'rgba(224,180,90,0.85)'; ctx.lineWidth = p.chargeReady ? 5 : 3;
      ctx.beginPath(); ctx.ellipse(p.x, p.y, 36, 13, 0, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * k); ctx.stroke(); ctx.restore();
    }
    const blink = p.iframes > 0 && !p.dead && p.dashT <= 0 && Math.floor(w.time * 20) % 2 === 0;
    const base = { flip: p.flip, time: w.time, walkT: p.walkT, moving: p.moving, wp: playerPose(p, w.time), type: p.wtype, scale: 0.95, vx: p.vx, speed: p.stats.speed };
    for (const g of p.ghosts) drawHero(renderer, sprites.heroParts, sprites.weapon, { ...base, x: g.x, y: g.y, flip: g.flip, walkT: g.walkT, dashing: true, flash: 0.85, alpha: 0.28 * (g.t / g.max) });
    drawHero(renderer, sprites.heroParts, sprites.weapon, { ...base, x: p.x, y: p.y, dashing: p.dashT > 0 || !!p.lunge || !!p.rush, flash: p.flash > 0 ? p.flash : 0, alpha: p.blink && p.dashT > 0 ? 0.12 : blink ? 0.45 : 1, deathT: p.dead ? p.deathT : null });
    if (p.dead && w.party > 1) reviveRing(p, w.reviveT / REVIVE_TIME);
  }

  function drawAlly(a) {
    if (a.x == null) return;
    const look = a.look || {};
    drawShadow(a.x, a.y, 22);
    ctx.strokeStyle = 'rgba(159,224,160,0.8)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(a.x, a.y, 26, 10, 0, 0, Math.PI * 2); ctx.stroke();
    drawHero(renderer, app.heroPartsFor(look.a, look.r), sprites['weapon_' + (getItem(look.w)?.id || 'w_rust_blade')], {
      x: a.x, y: a.y, flip: a.flip, time: w.time, walkT: a.walkT, moving: a.moving, wp: playerPose(a, w.time), type: a.wtype, scale: 0.95,
      dashing: a.dashT > 0 || !!a.rush, alpha: a.goneT > GONE_AFTER ? 0.35 : 1, deathT: a.ko ? 0.5 : null, vx: a.vx || 0, speed: 230,
    });
    ctx.font = '700 14px "Bai Jamjuree", system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.lineWidth = 4; ctx.strokeStyle = '#1a100c'; ctx.fillStyle = '#9fe0a0';
    ctx.strokeText(a.name, a.x, a.y - 112); ctx.fillText(a.name, a.x, a.y - 112);
    const frac = Math.max(0, a.hp / (a.maxHp || 1));
    ctx.fillStyle = 'rgba(20,12,9,0.85)'; ctx.fillRect(a.x - 35, a.y - 104, 70, 8); ctx.fillStyle = '#7fc77a'; ctx.fillRect(a.x - 34, a.y - 103, 68 * frac, 6);
    if (a.ko) { ctx.fillStyle = '#ffb3a4'; ctx.font = '700 12px "Bai Jamjuree", system-ui, sans-serif'; ctx.fillText('ล้ม — ยืนข้างๆ เพื่อช่วย', a.x, a.y - 124); }
  }

  function reviveRing(p, k) {
    ctx.save(); ctx.strokeStyle = 'rgba(20,12,9,0.7)'; ctx.lineWidth = 6; ctx.beginPath(); ctx.arc(p.x, p.y - 60, 22, 0, Math.PI * 2); ctx.stroke();
    ctx.strokeStyle = '#9fe0a0'; ctx.beginPath(); ctx.arc(p.x, p.y - 60, 22, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * Math.min(1, k)); ctx.stroke(); ctx.restore();
  }

  function drawPortal() {
    if (w.rphase !== 'clear') return;
    const t = w.time;
    ctx.save(); ctx.translate(PORTAL.x, PORTAL.y - 50);
    ctx.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 4; i++) {
      ctx.strokeStyle = `rgba(${i % 2 ? '191,227,255' : '224,180,90'},${0.7 - i * 0.12})`; ctx.lineWidth = 6 - i;
      ctx.beginPath(); ctx.ellipse(0, 0, 46 + i * 8 + Math.sin(t * 3 + i) * 3, 74 + i * 8, 0, 0, Math.PI * 2); ctx.stroke();
    }
    const g = ctx.createRadialGradient(0, 0, 4, 0, 0, 70); g.addColorStop(0, 'rgba(255,243,196,0.75)'); g.addColorStop(1, 'rgba(95,168,236,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(0, 0, 50, 76, 0, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    if (Math.random() < 0.4) w.particles.spawn({ x: PORTAL.x + (Math.random() - 0.5) * 80, y: PORTAL.y - 20, vx: 0, vy: -60, life: 0.9, size: 3, size2: 0.5, color: '#bfe3ff', drag: 0.5, glow: true });
  }

  function render() {
    if (!w) return;
    const v = renderer.view;
    renderer.screenSpace();
    ctx.fillStyle = '#0e0a08'; ctx.fillRect(0, 0, v.w, v.h);
    renderer.worldSpace();
    if (!w.floor) w.floor = paintZoneRoom(w.zone.theme, A, w.zone.n * 7);
    ctx.drawImage(w.floor, 0, 0);
    drawMechanicFloor(ctx, w.zone, w.time);
    drawPools(ctx, w.fxs, w.time);
    drawStrikes(ctx, w.fxs, w.time);
    drawZones(ctx, w.zones, w.time);
    drawSnares(ctx, w.snares, w.time);
    drawPortal();
    for (const d of w.drops) drawDrop(ctx, d, sprites, w.time);
    const list = [];
    const enemies = w.amHost ? w.enemies : [...w.views.values()];
    for (const e of enemies) list.push({ y: e.y, f: () => drawEnemy(e) });
    for (const a of w.allies.values()) if (a.seen) list.push({ y: a.y ?? 0, f: () => drawAlly(a) });
    list.push({ y: w.player.y, f: () => drawMe(w.player) });
    if (w.pet && !w.player.dead) list.push({ y: w.pet.y, f: () => drawPet(renderer, w.pet, sprites, w.time) });
    list.sort((a, b) => a.y - b.y);
    for (const o of list) o.f();
    drawShots(ctx, w.fxs, w.time);
    for (const s of w.shots) drawShot(ctx, s, w.time);
    w.fx.drawWorld(ctx);
    w.particles.draw(ctx);
    drawGusts(ctx, w.fxs, A, w.time);
    w.fx.drawNumbers(ctx);
    // darkness: only the light around heroes (and lanterns) cuts through
    const dark = w.flags.dark ? 0.86 : w.darkT > 0 ? Math.min(0.8, w.darkT) : 0;
    if (dark > 0) drawDarkness(dark);
    renderer.screenSpace();
    if (app.vignette) ctx.drawImage(app.vignette, 0, 0, v.w, v.h);
    drawPartyList();
    if (w.phase === 'waiting') {
      ctx.font = '700 20px "Bai Jamjuree", system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = '#f3e6c8';
      ctx.fillText('รอเพื่อนร่วมทีมเข้าโซน…', v.w / 2, v.h * 0.35);
    }
  }

  let darkCanvas = null;
  function drawDarkness(alpha) {
    const v = renderer.view;
    if (!darkCanvas) darkCanvas = document.createElement('canvas');
    if (darkCanvas.width !== Math.round(v.w / 2) || darkCanvas.height !== Math.round(v.h / 2)) { darkCanvas.width = Math.max(1, Math.round(v.w / 2)); darkCanvas.height = Math.max(1, Math.round(v.h / 2)); }
    const g = darkCanvas.getContext('2d');
    g.globalCompositeOperation = 'source-over';
    g.clearRect(0, 0, darkCanvas.width, darkCanvas.height);
    g.fillStyle = `rgba(6,4,10,${alpha})`; g.fillRect(0, 0, darkCanvas.width, darkCanvas.height);
    g.globalCompositeOperation = 'destination-out';
    const cam = renderer.cam;
    const toScreen = (x, y) => ({ x: ((x - cam.x) * cam.zoom + v.w / 2) / 2, y: ((y - cam.y) * cam.zoom + v.h / 2) / 2 });
    const light = (x, y, r) => {
      const s = toScreen(x, y), rr = (r * cam.zoom) / 2;
      const grad = g.createRadialGradient(s.x, s.y, rr * 0.3, s.x, s.y, rr);
      grad.addColorStop(0, 'rgba(0,0,0,1)'); grad.addColorStop(1, 'rgba(0,0,0,0)');
      g.fillStyle = grad; g.beginPath(); g.arc(s.x, s.y, rr, 0, Math.PI * 2); g.fill();
    };
    light(w.player.x, w.player.y - 30, 300);
    for (const a of w.allies.values()) if (a.x != null) light(a.x, a.y - 30, 220);
    for (const s of w.fxs.strikes) if (s.mult > 0) light(s.x, s.y, Math.max(80, s.r || 0) + 40);
    for (const s of w.fxs.shots) light(s.x, s.y, 70);
    if (w.rphase === 'clear') light(PORTAL.x, PORTAL.y - 40, 200);
    renderer.screenSpace();
    ctx.drawImage(darkCanvas, 0, 0, v.w, v.h);
    renderer.worldSpace();
  }

  function drawPartyList() {
    if (w.party < 2) return;
    const v = renderer.view;
    const x0 = app.touch && v.w < v.h ? 12 : 14, y0 = app.touch && v.w < v.h ? 128 : 84;
    let y = y0;
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    for (const a of w.allies.values()) {
      ctx.fillStyle = 'rgba(15,11,9,0.7)'; ctx.fillRect(x0, y - 11, 150, 22);
      ctx.font = '700 12px "Bai Jamjuree", system-ui, sans-serif'; ctx.fillStyle = a.ko ? '#ffb3a4' : a.goneT > GONE_AFTER ? '#7d6d58' : '#9fe0a0';
      ctx.fillText(a.name || '…', x0 + 6, y);
      ctx.fillStyle = '#2a1a14'; ctx.fillRect(x0 + 84, y - 4, 60, 8);
      ctx.fillStyle = a.ko ? '#5a3a30' : '#7fc77a'; ctx.fillRect(x0 + 84, y - 4, 60 * Math.max(0, (a.hp || 0) / (a.maxHp || 1)), 8);
      y += 26;
    }
    ctx.textBaseline = 'alphabetic';
  }

  return {
    enter(params) {
      app.particles.clear();
      app.refreshHeroSprites();
      w = makeWorld(params);
      w.unsub.push(params.room.on('match', onMessage));
      input.setEnabled(true); input.reset();
      app.hud.show(w); app.hud.setMode('coop');
      audio.startMusic('battle');
      params.room.presence({ ...fighterPresence(w.player, w.look, 'ready'), en: null, rs: null });
      if (w.amHost && w.party === 1) { w.phase = 'run'; startRoom(0); nextWave(); }
    },
    exit() {
      if (w) { for (const u of w.unsub) u(); w.room.leave?.(); }
      input.setEnabled(false); app.hud.hide(); app.hud.setMode('dungeon'); app.hud.setBoss(null); audio.stopMusic();
      w = null;
    },
    update, render,
    get world() { return w; },
    retreat() { if (w && !w.ended) finish('retreat'); },
    snapshot() {
      if (!w) return null;
      const enemies = w.amHost ? w.enemies : [...w.views.values()];
      return {
        zone: w.zone.id, host: w.amHost, party: w.party, phase: w.phase, room: w.ri, rphase: w.rphase, ended: w.ended,
        me: { x: Math.round(w.player.x), y: Math.round(w.player.y), hp: Math.ceil(w.player.hp), maxHp: w.player.maxHp, dead: w.player.dead },
        enemies: enemies.filter((e) => !e.dead).map((e) => ({ id: e.id, type: e.type.id, x: Math.round(e.x), y: Math.round(e.y), hp: Math.ceil(e.hp), maxHp: e.maxHp, untargetable: !!e.untargetable, boss: !!e.type.boss })),
        allies: [...w.allies.values()].map((a) => ({ name: a.name, x: Math.round(a.x || 0), y: Math.round(a.y || 0), ko: !!a.ko, seen: a.seen })),
        strikes: w.fxs.strikes.length, pools: w.fxs.pools.length, shots: w.fxs.shots.length, portal: { x: PORTAL.x, y: PORTAL.y }, kills: w.run.kills,
      };
    },
  };
}
