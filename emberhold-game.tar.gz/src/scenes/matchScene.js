// PvP match (1v1 duel, 2v2, 3v3): best of 3 rounds, last team standing wins a round. Everyone fights with the full
// kit (weapon combos, charge, dodge + perfect dodge, skills, bloodline skill); pets stay home, no potions.
// Each client simulates its own hero and shares it as presence in the match room; attackers report hits, the
// victim applies them with its own defence and dodge window (src/online/pvp.js). The room host owns the round
// state and shares it as presence too (`mt`), so a late or dropped message never desyncs the score.
import { BALANCE } from '../config/balance.js';
import { computeStats } from '../systems/stats.js';
import { slottedSkills } from '../systems/skills.js';
import { cloneState } from '../core/state.js';
import { createPlayer, updatePlayer, damagePlayer, inPerfectWindow } from '../battle/player.js';
import { createFx } from '../battle/fx.js';
import { createSkillBar, tickSkills, castSkill, updateSnares, drawSnares } from '../battle/skills.js';
import { createRaceSkill, tickRaceSkill, castRaceSkill } from '../battle/raceSkills.js';
import { createShot, updateShots, drawShot, updateZones, drawZones, updateCones } from '../battle/playerShots.js';
import { drawHero } from '../battle/heroDraw.js';
import { playerPose } from '../battle/weaponPose.js';
import { PVP, hitPacket, resolveHit, fighterPresence, updateRemoteFighter } from '../online/pvp.js';
import { lookOf, readPresence, PROTOCOL } from '../online/protocol.js';
import { getMode, teamOf, roundOutcome, matchWinner, spawnFor, TEAM_INFO, ROUNDS_TO_WIN } from '../online/match.js';
import { getItem } from '../data/items.js';

const CB = BALANCE.combat;
export const ARENAS = Object.freeze({
  '1v1': { w: 1000, h: 640, wall: 60 },
  '2v2': { w: 1180, h: 720, wall: 60 },
  '3v3': { w: 1320, h: 800, wall: 60 },
});
const GONE_AFTER = 3;        // seconds without presence = left the match
const WAIT_LIMIT = 20;       // seconds the host waits for everyone to arrive
const SHOT_KINDS = ['arrow', 'bigArrow', 'bolt', 'knife', 'feather'];

export function createMatchScene(app) {
  const { renderer, input, store, audio, sprites, rng } = app;
  const ctx = renderer.ctx;
  let w = null;
  let floor = null, floorKey = '';

  const meId = () => app.online.me.peer;

  function makeWorld({ room, mode, host, roster, title }) {
    const st = store.get();
    const stats = computeStats(st);
    const p = createPlayer(stats, 0, 0);
    const A = ARENAS[mode] || ARENAS['1v1'];
    const me = meId();
    const wd = {
      room, mode, size: getMode(mode).size, host, amHost: host === me, roster, title, A, me, team: teamOf(roster, me) || 'a',
      rng, time: 0, stopT: 0, slowT: 0, player: p, enemies: [], fighters: new Map(), fx: createFx(), particles: app.particles,
      skills: createSkillBar(slottedSkills(st)), raceSkill: createRaceSkill(st.race?.id, stats.skillCdMult), pet: null,
      shots: [], zones: [], cones: [], snares: [], ghostShots: [], combo: { n: 0, t: 0, best: 0 }, keys: 0, perfects: 0, kos: 0,
      phase: 'waiting', phaseT: 0, round: 0, score: { a: 0, b: 0 }, ended: false, paused: false, hostGone: 0, lastMt: '',
      unsub: [], lastStandUsed: false, look: lookOf(st), arena: A,
    };
    for (const t of ['a', 'b']) for (const peer of roster[t]) if (peer !== me) wd.fighters.set(peer, { peer, team: t, r: BALANCE.player.radius, goneT: 0, seen: false, x: null, y: null, hp: 1, maxHp: 1 });
    // --- the world API the shared combat code calls
    wd.sfx = (n, o) => audio.play(n, o);
    wd.shake = (m, t) => renderer.shake(m, t);
    wd.hitStop = (t) => { wd.stopT = Math.max(wd.stopT, Math.min(0.06, t)); };
    wd.screenToWorld = (sx, sy) => renderer.screenToWorld(sx, sy);
    wd.toast = (...a) => app.toast(...a);
    wd.clampBody = (b) => { b.x = Math.max(A.wall + b.r, Math.min(A.w - A.wall - b.r, b.x)); b.y = Math.max(A.wall + b.r + 10, Math.min(A.h - A.wall, b.y)); };
    wd.cutProjectiles = () => 0;
    wd.addSnare = (z) => wd.snares.push(z);
    wd.addHazard = () => {};
    wd.addCone = (c) => wd.cones.push(c);
    wd.addZone = (z) => { wd.zones.push({ ...z, t: 0, done: false }); audio.play('cast', { power: 1.6 }); send({ k: 'zone', x: Math.round(z.x), y: Math.round(z.y), r: z.r, delay: z.delay }); };
    wd.firePlayerShot = (o) => {
      wd.shots.push(createShot(o));
      send({ k: 'shot', kind: o.kind, x: Math.round(o.x), y: Math.round(o.y), a: Math.round(o.angle * 100) / 100, sp: o.speed, r: o.r });
    };
    wd.usePotion = () => { app.toast('ห้ามใช้ยาระหว่างประลอง', 'warn', 'pvp-potion'); audio.play('error'); };
    wd.onPlayerSwing = (def, kind) => {
      const t = p.wtype.id;
      if (t === 'bow') audio.play('bow', { power: kind === 'charged' ? 1.6 : 1 });
      else if (t === 'staff') audio.play('cast', { power: kind === 'charged' ? 1.6 : def.power });
      else audio.play('swing', { power: Math.min(1.8, 0.7 + def.power * 0.45) });
    };
    wd.onPlayerDash = (blink) => audio.play(blink ? 'blink' : 'dash');
    wd.onChargeReady = () => audio.play('charge');
    wd.onLastStand = () => { app.hud.banner('ผู้ไม่มอด', 'รอดจากหมัดสุดท้าย'); audio.play('roar'); };
    wd.onPlayerDeath = () => { audio.play('defeat'); app.hud.banner('ถูกล้ม', wd.size > 1 ? 'รอเพื่อนร่วมทีม' : ''); };
    // Hits I land become hit reports to that opponent.
    wd.playerStrike = (e, power, o = {}) => {
      if (!e.peer || e.team === wd.team || wd.phase !== 'fight' || o.src === 'burn') return null;
      const empowered = p.empowerT > 0 && (o.src === 'melee' || o.src === 'proj');
      if (empowered) p.empowerT = 0;
      const pkt = hitPacket(p.stats, power * (empowered ? 1 + CB.perfect.empowerPower : 1), { ...o, forceCrit: o.forceCrit || empowered }, p);
      pkt.to = e.peer;
      send(pkt);
      wd.combo.n += 1; wd.combo.t = 0; wd.combo.best = Math.max(wd.combo.best, wd.combo.n);
      wd.particles.burst(e.x, e.y - 30, 8, { color: ['#fff8ea', '#f3e6c8'], speedMin: 90, speedMax: 260, life: 0.25, size: 2.5, drag: 5, glow: true });
      audio.play('hit');
      return { amount: 0, crit: false };
    };
    wd.petStrike = () => null;
    return wd;
  }

  function send(data) { w?.room.emit('match', data); }
  function setMt(mt) { w.room.presence({ mt }); w.lastMt = JSON.stringify(mt); }

  // ------------------------------------------------------------ messages from the match room
  function onMessage(m) {
    if (!w || m.sameTab) return;
    const f = w.fighters.get(m.peer);
    if (!f) return;                                    // only seated players talk in this room
    const d = m.data || {};
    const p = w.player;
    const foe = f.team !== w.team;
    if (d.k === 'forfeit') { f.left = true; f.goneT = 99; f.seen = true; f.ko = true; return; }   // they left: down for the rest of the match
    if (d.k === 'hit' && foe && d.to === w.me && w.phase === 'fight' && !p.dead) {
      if (p.iframes > 0) {
        if (inPerfectWindow(p)) perfectDodge();
        send({ k: 'miss', to: m.peer });
        return;
      }
      const r = resolveHit(d, p.stats, p, rng);
      if (!r) return;
      if (damagePlayer(p, r.amount, r.kx, r.ky, w)) {
        audio.play('hurt'); renderer.shake(6, 0.2); app.hud.hurt();
        w.combo.n = 0;
        send({ k: 'struck', to: m.peer, amount: r.amount, crit: r.crit });
      }
    } else if (d.k === 'struck' && d.to === w.me) {
      w.fx.number(f.x, f.y - 80, Math.max(1, d.amount | 0), d.crit ? 'crit' : 'hit');
      if (d.crit) renderer.shake(4, 0.12);
    } else if (d.k === 'miss' && d.to === w.me) {
      w.fx.number(f.x, f.y - 80, 'หลบ', 'info');
    } else if (d.k === 'shot' && foe) {
      const a = Number(d.a) || 0, sp = Math.min(1600, Number(d.sp) || 600);
      w.ghostShots.push({ ...createShot({ kind: SHOT_KINDS.includes(d.kind) ? d.kind : 'bolt', x: +d.x || 0, y: +d.y || 0, angle: a, speed: sp, r: Math.min(14, +d.r || 8), power: 0 }), life: 1.1 });
    } else if (d.k === 'zone' && foe) {
      w.zones.push({ x: +d.x || 0, y: +d.y || 0, r: Math.min(220, +d.r || 100), delay: Math.min(1.5, +d.delay || 0.5), power: 0, opts: {}, t: 0, done: false, ghost: true });
    }
  }

  function perfectDodge() {
    const p = w.player;
    if (p.perfectUsed) return;
    p.perfectUsed = true; p.empowerT = CB.perfect.empowerT; p.dodges = Math.min(p.dodgeMax, p.dodges + 1);
    w.slowT = 0.25; w.perfects += 1;
    w.fx.callout(p.x, p.y - 120, 'หลบสมบูรณ์!', '#bfe3ff');
    w.fx.ring(p.x, p.y - 30, 20, 120, '#bfe3ff', 0.5, 6);
    audio.play('perfect'); app.hud.flash?.('perfect');
  }

  // ------------------------------------------------------------ rounds
  function mySeat() { return Math.max(0, w.roster[w.team].indexOf(w.me)); }
  function resetFighter() {
    const p = w.player, at = spawnFor(w.team, mySeat(), w.size, w.A);
    p.x = at.x; p.y = at.y; p.vx = p.vy = 0; p.hp = p.maxHp; p.dead = false; p.deathT = 0; p.move = null; p.shield = 0; p.rush = null;
    p.dodges = p.dodgeMax; p.iframes = 0; p.flip = w.team === 'b'; p.facing = w.team === 'b' ? Math.PI : 0;
    w.shots.length = 0; w.ghostShots.length = 0; w.zones.length = 0; w.cones.length = 0; w.snares.length = 0; w.combo.n = 0;
    w.lastStandUsed = false;
  }

  function startRound(n) {
    if (!w || w.ended) return;
    w.round = n; w.phase = 'countdown'; w.phaseT = 0;
    resetFighter();
    app.hud.banner(`ยกที่ ${n}`, scoreText());
    audio.play('wave');
  }

  function endRound(winTeam, score) {
    if (w.phase === 'roundEnd' || w.ended) return;
    w.phase = 'roundEnd'; w.phaseT = 0;
    w.score = { ...score };
    const mine = winTeam === w.team;
    app.hud.banner(winTeam === 'draw' ? 'เสมอ' : mine ? 'ชนะยกนี้' : 'เสียยกนี้', scoreText());
    audio.play(winTeam === 'draw' ? 'wave' : mine ? 'victory' : 'defeat');
  }

  function scoreText() {
    const other = w.team === 'a' ? 'b' : 'a';
    return `${TEAM_INFO[w.team].name} ${w.score[w.team]} - ${w.score[other]} ${TEAM_INFO[other].name}`;
  }

  // Who is still standing: me from my own hero, others from their presence (gone = down).
  function aliveMap() {
    const alive = { [w.me]: !w.player.dead };
    for (const f of w.fighters.values()) alive[f.peer] = f.seen && f.goneT < GONE_AFTER && !f.ko && f.hp > 0;
    return alive;
  }

  function finishMatch(result, why) {
    if (!w || w.ended) return;
    w.ended = true; w.phase = 'done';
    input.setEnabled(false);
    if (result === 'win' || result === 'lose') {
      const next = cloneState(store.get());
      if (result === 'win') next.pvp.wins += 1; else next.pvp.losses += 1;
      store.commit(next, { reason: 'pvp' });
    }
    const other = w.team === 'a' ? 'b' : 'a';
    const names = (t) => w.roster[t].map((peer) => (peer === w.me ? store.get().story.name : w.fighters.get(peer)?.name || 'นักล่า'));
    app.onMatchEnd({
      result, why, mode: w.mode, title: w.title,
      score: { me: w.score[w.team], them: w.score[other] }, team: w.team,
      allies: names(w.team), opponents: names(other), opponent: { name: names(other).join(', ') },
      perfects: w.perfects, bestCombo: w.combo.best,
    });
  }

  // ------------------------------------------------------------ frame
  let sendAcc = 0;
  function readFighters(dt) {
    const peers = w.room.peers();
    const byPeer = new Map(peers.map((x) => [x.peer, x]));
    let hostMt = null;
    for (const f of w.fighters.values()) {
      if (f.left) { f.goneT = 99; continue; }        // forfeited: out for good, even while their page is still open
      const x = byPeer.get(f.peer);
      const raw = x?.presence;
      if (!raw || raw.v !== PROTOCOL || x.sameTab) { f.goneT += dt; continue; }
      f.goneT = 0; f.seen = true;
      updateRemoteFighter(f, raw, dt);
      const c = readPresence(raw);
      f.name = c?.name || 'นักล่า'; f.look = c ? { a: c.armor, r: c.race, w: c.weapon } : f.look;
      f.ko = raw.st === 'ko';
      f.dead = f.ko || f.hp <= 0; f.spawning = 0;
      f.type = { boss: false, mass: 1.4, radius: 20 }; f.def = 0;
      if (f.peer === w.host) hostMt = raw.mt || null;
      if (f.newActive && f.team !== w.team) remoteSwingFx(f);
      else if (f.newActive) remoteSwingFx(f, 0.5);
    }
    return hostMt;
  }

  function hostFlow() {
    const alive = aliveMap();
    // a whole side left the match (forfeit or closed the game): it ends now
    if (w.phase !== 'waiting') {
      const goneSide = ['a', 'b'].find((t) => w.roster[t].length && w.roster[t].every((peer) => peer !== w.me && (w.fighters.get(peer)?.goneT || 0) > GONE_AFTER));
      if (goneSide) { const winner = goneSide === 'a' ? 'b' : 'a'; setMt({ st: 'done', sc: w.score, win: winner }); finishMatch(winner === w.team ? 'win' : 'lose', 'forfeit'); return; }
    }
    if (w.phase === 'waiting') {
      const all = [...w.fighters.values()];
      const ready = all.every((f) => f.seen && f.status === 'ready');
      const others = all.filter((f) => f.team !== w.team && f.seen);
      if ((ready && w.phaseT > 0.6) || (w.phaseT > WAIT_LIMIT && others.length)) { setMt({ st: 'countdown', rd: 1, sc: w.score }); startRound(1); }
      else if (w.phaseT > WAIT_LIMIT) { setMt({ st: 'done', sc: w.score, win: null }); finishMatch('cancel', 'no_show'); }
    } else if (w.phase === 'countdown' && w.phaseT >= PVP.countdown) {
      w.phase = 'fight'; w.phaseT = 0; setMt({ st: 'fight', rd: w.round, sc: w.score }); fightBanner();
    } else if (w.phase === 'fight') {
      const out = roundOutcome(w.roster, alive);
      if (out) {
        const sc = { ...w.score };
        if (out !== 'draw') sc[out] += 1;
        setMt({ st: 'roundEnd', rd: w.round, sc, rw: out });
        endRound(out, sc);
      }
    } else if (w.phase === 'roundEnd' && w.phaseT > 2.4) {
      const win = matchWinner(w.score);
      // nobody left on one side for good (everyone there closed the game): end now
      const gone = (t) => w.roster[t].every((peer) => peer !== w.me && (w.fighters.get(peer)?.goneT || 0) > GONE_AFTER);
      const forfeit = gone('a') ? 'b' : gone('b') ? 'a' : null;
      if (win || forfeit) {
        const winner = win || forfeit;
        setMt({ st: 'done', sc: w.score, win: winner });
        finishMatch(winner === w.team ? 'win' : 'lose', win ? 'score' : 'forfeit');
        return;
      }
      setMt({ st: 'countdown', rd: w.round + 1, sc: w.score });
      startRound(w.round + 1);
    }
    // a side that emptied out mid-round loses that round at once (handled by aliveMap: gone = down)
  }

  function followHost(mt) {
    const hostF = w.fighters.get(w.host);
    if (!hostF || hostF.goneT > GONE_AFTER) {
      if (hostF?.seen || w.phaseT > WAIT_LIMIT) {
        w.hostGone += 1;
        // the host left: in a duel that is a forfeit, in a team match the room is closed without a result
        if (w.size === 1) finishMatch('win', 'forfeit'); else finishMatch('cancel', 'host_left');
      }
      return;
    }
    if (!mt || typeof mt !== 'object') return;
    const key = JSON.stringify(mt);
    if (key === w.lastMt) return;
    w.lastMt = key;
    const rd = Math.max(0, Math.min(9, mt.rd | 0));
    const sc = { a: Math.max(0, Math.min(ROUNDS_TO_WIN, mt.sc?.a | 0)), b: Math.max(0, Math.min(ROUNDS_TO_WIN, mt.sc?.b | 0)) };
    if (mt.st === 'countdown' && rd !== w.round) { w.score = sc; startRound(rd); }
    else if (mt.st === 'fight' && rd !== w.round) { w.score = sc; startRound(rd); w.phaseT = PVP.countdown; }
    else if (mt.st === 'fight' && w.phase === 'countdown') { w.phase = 'fight'; w.phaseT = 0; fightBanner(); }
    else if (mt.st === 'roundEnd') endRound(['a', 'b', 'draw'].includes(mt.rw) ? mt.rw : 'draw', sc);
    else if (mt.st === 'done') {
      w.score = sc;
      if (mt.win === 'a' || mt.win === 'b') finishMatch(mt.win === w.team ? 'win' : 'lose', 'score');
      else finishMatch('cancel', 'no_show');
    }
  }

  function fightBanner() { app.hud.banner('สู้!', ''); audio.play('roar'); }

  function update(dt) {
    if (!w) return;
    const intent = input.poll();
    if (intent.pause && !w.ended) app.leaveMatch();
    const p = w.player;
    w.phaseT += dt;
    if (w.slowT > 0) w.slowT -= dt;
    if (w.stopT > 0) w.stopT -= dt;
    w.time += dt;
    w.fx.update(dt); w.particles.update(dt); renderer.update(dt);

    const mt = readFighters(dt);
    w.enemies = w.phase === 'fight' ? [...w.fighters.values()].filter((f) => f.team !== w.team && f.seen && !f.dead && f.goneT < GONE_AFTER && f.x != null) : [];
    if (w.amHost) hostFlow(); else followHost(mt);
    if (w.ended) return;
    // non-hosts run their own countdown so the fight starts without waiting for another message
    if (!w.amHost && w.phase === 'countdown' && w.phaseT >= PVP.countdown) { w.phase = 'fight'; w.phaseT = 0; fightBanner(); }

    // my hero
    const fighting = w.phase === 'fight' && !p.dead;
    tickSkills(w.skills, dt); tickRaceSkill(w.raceSkill, dt);
    const myIntent = fighting ? intent : { ...intent, attack: false, attackHeld: false, dash: false, skill: -1, race: false, potion: false };
    if (fighting && intent.skill >= 0) castSkill(w.skills, intent.skill, w);
    if (fighting && intent.race) castRaceSkill(w);
    if (w.phase !== 'fight') { myIntent.mx = 0; myIntent.my = 0; }
    updatePlayer(p, myIntent, dt, w);
    w.clampBody(p);
    w.combo.t += dt; if (w.combo.n > 0 && w.combo.t > CB.combo.resetAfter) w.combo.n = 0;
    updateShots(w.shots, dt, w);
    updateZones(w.zones.filter((z) => !z.ghost), dt, w);
    for (let i = w.zones.length - 1; i >= 0; i--) {
      const z = w.zones[i];
      if (z.ghost) { z.t += dt; if (z.t > z.delay + 0.35) w.zones.splice(i, 1); else if (!z.done && z.t >= z.delay) { z.done = true; renderer.shake(6, 0.2); audio.play('slam'); } }
      else if (z.t >= z.delay + 0.35) w.zones.splice(i, 1);
    }
    updateCones(w.cones, dt, w);
    updateSnares(w.snares, dt, w);
    const A = w.A;
    for (let i = w.ghostShots.length - 1; i >= 0; i--) {
      const s = w.ghostShots[i]; s.t += dt; s.life -= dt; s.x += s.vx * dt; s.y += s.vy * dt;
      if (s.life <= 0 || Math.hypot(s.x - p.x, s.y - (p.y - 30)) < s.r + p.r || s.x < 0 || s.y < 0 || s.x > A.w || s.y > A.h) w.ghostShots.splice(i, 1);
    }

    // share my fighter ~15×/s (presence shares the room's ~40 msg/s budget with hit and shot events)
    sendAcc += dt;
    if (sendAcc >= 0.066) { sendAcc = 0; w.room.presence(fighterPresence(p, w.look, w.phase === 'waiting' ? 'ready' : p.dead ? 'ko' : 'fight')); }

    camera(dt);
    app.hud.update(p, w);
    const foes = [...w.fighters.values()].filter((f) => f.team !== w.team && f.seen);
    const hp = foes.reduce((n, f) => n + Math.max(0, f.goneT > GONE_AFTER ? 0 : f.hp), 0), max = foes.reduce((n, f) => n + (f.maxHp || 1), 0);
    if (max) app.hud.setBoss(w.size === 1 ? `${foes[0]?.name || 'คู่ดวล'} · ${w.score[w.team]} - ${w.score[w.team === 'a' ? 'b' : 'a']}` : scoreText(), hp / max);
  }

  function camera(dt) {
    const cam = renderer.cam, v = renderer.view, A = w.A, p = w.player;
    const landscape = app.touch && v.w > v.h;
    const top = landscape ? 50 : app.touch ? 130 : 96, bottom = landscape ? 10 : app.touch ? 240 : 80;
    const fit = Math.min(v.w / (A.w + 40), (v.h - top - bottom) / (A.h + 20));
    if (fit >= 0.55) {
      cam.zoom = Math.min(1.3, fit);
      cam.x = A.w / 2; cam.y = A.h / 2 - (top - bottom) / 2 / cam.zoom;
      return;
    }
    // narrow phone: follow the action instead of shrinking the whole arena
    cam.zoom = 0.62;
    let mx = p.x, my = p.y;
    const foe = w.size === 1 ? [...w.fighters.values()][0] : null;
    if (foe && foe.x != null) { mx = (p.x + foe.x) / 2; my = (p.y + foe.y) / 2; }
    const halfW = v.w / 2 / cam.zoom;
    const tx = A.w < halfW * 2 ? A.w / 2 : Math.max(halfW - 20, Math.min(A.w - halfW + 20, mx));
    const k = Math.min(1, dt * 6);
    cam.x += (tx - cam.x) * k; cam.y += (my - 30 - (top - bottom) / 2 / cam.zoom - cam.y) * k;
  }

  function remoteSwingFx(r, alpha = 1) {
    const d = r.move?.def; if (!d) return;
    const t = r.wtype.trail, h = d.hit;
    if (h.shape === 'arc') {
      if (['thrust', 'stab', 'stabB'].includes(d.anim)) w.fx.thrust(r.x, r.y - 18, r.move.dir, h.range, t.color, t.glow, d.power * alpha);
      else w.fx.slash(r.x, r.y - 18, r.move.dir, (h.arc * Math.PI) / 180, h.range * 0.82, d.power * t.width * alpha, t.color, d.anim === 'slashUp' || d.anim === 'heavyUp', t.glow);
    } else if (h.shape === 'circle') {
      const ox = r.x + Math.cos(r.move.dir) * (h.forward || 0), oy = r.y - 10 + Math.sin(r.move.dir) * (h.forward || 0);
      w.fx.ring(ox, oy, 12, h.r, t.glow, 0.42, 8);
    }
    audio.play('swing', { power: Math.min(1.6, 0.6 + d.power * 0.4) * alpha });
  }

  // ------------------------------------------------------------ drawing
  function paintFloor(A) {
    const c = document.createElement('canvas'); c.width = A.w; c.height = A.h;
    const g = c.getContext('2d');
    g.fillStyle = '#2a211b'; g.fillRect(0, 0, A.w, A.h);
    const grad = g.createRadialGradient(A.w / 2, A.h / 2, 40, A.w / 2, A.h / 2, A.w * 0.6);
    grad.addColorStop(0, '#6b5a48'); grad.addColorStop(1, '#3a2e25');
    g.fillStyle = grad; g.fillRect(A.wall, A.wall, A.w - A.wall * 2, A.h - A.wall * 2);
    // team halves, faintly tinted
    g.fillStyle = 'rgba(224,89,63,0.07)'; g.fillRect(A.wall, A.wall, A.w / 2 - A.wall, A.h - A.wall * 2);
    g.fillStyle = 'rgba(95,191,168,0.07)'; g.fillRect(A.w / 2, A.wall, A.w / 2 - A.wall, A.h - A.wall * 2);
    g.strokeStyle = 'rgba(224,180,90,0.35)'; g.lineWidth = 6;
    g.beginPath(); g.ellipse(A.w / 2, A.h / 2 + 20, A.w * 0.36, A.h * 0.32, 0, 0, Math.PI * 2); g.stroke();
    g.beginPath(); g.moveTo(A.w / 2, A.wall + 30); g.lineTo(A.w / 2, A.h - A.wall - 30); g.stroke();
    let seed = 3; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
    for (let i = 0; i < 400; i++) { g.fillStyle = `rgba(20,14,10,${(0.08 + rnd() * 0.12).toFixed(2)})`; g.fillRect(A.wall + rnd() * (A.w - A.wall * 2), A.wall + rnd() * (A.h - A.wall * 2), 3 + rnd() * 6, 2 + rnd() * 3); }
    const block = (x, y, bw, bh) => { g.fillStyle = ['#6b6460', '#77706a', '#5f5854'][Math.abs(Math.round(x * 7 + y * 3)) % 3]; g.fillRect(x + 1, y + 1, bw - 2, bh - 2); g.strokeStyle = '#2a221d'; g.lineWidth = 2; g.strokeRect(x + 1, y + 1, bw - 2, bh - 2); };
    for (let y = 0; y < A.wall; y += 20) for (let x = (y / 20) % 2 ? -24 : 0; x < A.w; x += 48) { block(x, y, 48, 20); block(x, A.h - A.wall + y, 48, 20); }
    for (let x = 0; x < A.wall; x += 30) for (let y = A.wall; y < A.h - A.wall; y += 20) { block(x, y, 30, 20); block(A.w - A.wall + x, y, 30, 20); }
    g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(A.wall, A.wall, A.w - A.wall * 2, 14);
    g.strokeStyle = '#3a2e25'; g.lineWidth = 4; g.strokeRect(A.wall, A.wall, A.w - A.wall * 2, A.h - A.wall * 2);
    for (const [x, col] of [[A.w * 0.25, TEAM_INFO.a.color], [A.w * 0.75, TEAM_INFO.b.color]]) {
      g.fillStyle = col; g.strokeStyle = '#1a100c'; g.lineWidth = 3;
      g.beginPath(); g.moveTo(x - 26, 4); g.lineTo(x + 26, 4); g.lineTo(x + 26, 50); g.lineTo(x, 40); g.lineTo(x - 26, 50); g.closePath(); g.fill(); g.stroke();
      g.fillStyle = '#f5d48a'; g.beginPath(); g.arc(x, 22, 7, 0, Math.PI * 2); g.fill();
    }
    return c;
  }

  function drawFighter(f, isMe) {
    const team = isMe ? w.team : f.team;
    const col = TEAM_INFO[team].color;
    ctx.fillStyle = 'rgba(12,8,6,0.4)'; ctx.beginPath(); ctx.ellipse(f.x, f.y, 22, 8, 0, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = col; ctx.globalAlpha = 0.75; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(f.x, f.y, 26, 10, 0, 0, Math.PI * 2); ctx.stroke(); ctx.globalAlpha = 1;
    const look = isMe ? null : (f.look || {});
    const parts = isMe ? sprites.heroParts : app.heroPartsFor(look.a, look.r);
    const weapon = isMe ? sprites.weapon : sprites['weapon_' + (getItem(look.w)?.id || 'w_rust_blade')];
    const down = isMe ? f.dead : (f.dead || f.goneT > GONE_AFTER);
    drawHero(renderer, parts, weapon, {
      x: f.x, y: f.y, flip: f.flip, time: w.time, walkT: f.walkT, moving: f.moving, wp: playerPose(f, w.time), type: f.wtype, scale: 0.95,
      dashing: f.dashT > 0 || !!f.rush, flash: f.flash || 0, alpha: f.blink && f.dashT > 0 ? 0.15 : (!isMe && f.goneT > GONE_AFTER ? 0.4 : 1), deathT: down ? (f.deathT || 0.4) : null, vx: f.vx || 0, speed: 230,
    });
    const name = isMe ? store.get().story.name : (f.name || 'นักล่า');
    ctx.font = '700 15px "Bai Jamjuree", system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
    ctx.lineWidth = 4; ctx.strokeStyle = '#1a100c'; ctx.fillStyle = isMe ? '#f5d48a' : team === w.team ? '#9fe0a0' : '#ffb3a4';
    ctx.strokeText(name, f.x, f.y - 112); ctx.fillText(name, f.x, f.y - 112);
    const bw = 70, frac = Math.max(0, f.hp / (f.maxHp || 1));
    ctx.fillStyle = 'rgba(20,12,9,0.85)'; ctx.fillRect(f.x - bw / 2 - 1, f.y - 104, bw + 2, 8);
    ctx.fillStyle = team === w.team ? '#7fc77a' : '#c2412f'; ctx.fillRect(f.x - bw / 2, f.y - 103, bw * frac, 6);
  }

  function render() {
    if (!w) return;
    const v = renderer.view, A = w.A;
    renderer.screenSpace();
    ctx.fillStyle = '#120d0b'; ctx.fillRect(0, 0, v.w, v.h);
    renderer.worldSpace();
    const key = `${A.w}x${A.h}`;
    if (key !== floorKey) { floor = paintFloor(A); floorKey = key; }
    ctx.drawImage(floor, 0, 0);
    for (const [x, y] of [[A.wall, A.wall], [A.w - A.wall, A.wall]]) renderer.sprite(sprites.v_pillar, x, y + 40, {});
    drawZones(ctx, w.zones, w.time);
    drawSnares(ctx, w.snares, w.time);
    const list = [{ f: w.player, me: true }];
    for (const f of w.fighters.values()) if (f.seen && f.x != null) list.push({ f, me: false });
    list.sort((a, b) => a.f.y - b.f.y);
    for (const o of list) drawFighter(o.f, o.me);
    for (const [x, y] of [[A.wall, A.h - A.wall], [A.w - A.wall, A.h - A.wall]]) renderer.sprite(sprites.v_pillar, x, y + 40, {});
    for (const s of w.shots) drawShot(ctx, s, w.time);
    for (const s of w.ghostShots) drawShot(ctx, s, w.time);
    w.fx.drawWorld(ctx);
    w.particles.draw(ctx);
    w.fx.drawNumbers(ctx);
    renderer.screenSpace();
    if (app.vignette) ctx.drawImage(app.vignette, 0, 0, v.w, v.h);
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    if (w.phase === 'countdown') {
      const n = Math.max(1, Math.ceil(PVP.countdown - w.phaseT));
      ctx.font = '400 72px "Chonburi", serif';
      ctx.lineWidth = 8; ctx.strokeStyle = '#1a100c'; ctx.fillStyle = '#f5d48a';
      ctx.strokeText(String(n), v.w / 2, v.h * 0.4); ctx.fillText(String(n), v.w / 2, v.h * 0.4);
    } else if (w.phase === 'waiting') {
      ctx.font = '700 20px "Bai Jamjuree", system-ui, sans-serif'; ctx.fillStyle = '#f3e6c8';
      const here = [...w.fighters.values()].filter((f) => f.seen).length + 1, all = w.fighters.size + 1;
      ctx.fillText(`รอผู้เล่นเข้าสนาม ${here}/${all}…`, v.w / 2, v.h * 0.35);
    } else if (w.phase === 'fight' && w.player.dead && w.size > 1) {
      ctx.font = '700 16px "Bai Jamjuree", system-ui, sans-serif'; ctx.fillStyle = '#ffb3a4';
      ctx.fillText('คุณถูกล้ม — รอจบยก', v.w / 2, v.h * 0.3);
    }
  }

  return {
    enter(params) {
      app.particles.clear();
      app.refreshHeroSprites();
      w = makeWorld(params);
      resetFighter();
      w.unsub.push(params.room.on('match', onMessage));
      input.setEnabled(true); input.reset();
      app.hud.show(w); app.hud.setMode('arena');
      audio.startMusic('battle');
      params.room.presence({ ...fighterPresence(w.player, w.look, 'ready'), mt: null });
    },
    exit() {
      if (w) { for (const u of w.unsub) u(); w.room.leave(); }
      input.setEnabled(false); app.hud.hide(); app.hud.setMode('dungeon'); audio.stopMusic();
      w = null;
    },
    update, render,
    get world() { return w; },
    // I give up: I record a loss; the others see my hero leave (down for the rest of the match)
    forfeit() { if (!w || w.ended) return; send({ k: 'forfeit' }); finishMatch('lose', 'forfeit'); },
    snapshot() {
      if (!w) return null;
      return {
        mode: w.mode, phase: w.phase, round: w.round, score: { ...w.score }, team: w.team, host: w.amHost, ended: w.ended,
        me: { x: Math.round(w.player.x), y: Math.round(w.player.y), hp: Math.ceil(w.player.hp), maxHp: w.player.maxHp, dead: w.player.dead },
        fighters: [...w.fighters.values()].map((f) => ({ peer: f.peer, team: f.team, name: f.name || null, x: Math.round(f.x || 0), y: Math.round(f.y || 0), hp: f.hp, maxHp: f.maxHp, ko: !!f.ko, seen: f.seen })),
        remote: (() => { const f = [...w.fighters.values()].find((x) => x.team !== w.team && x.seen); return f ? { x: Math.round(f.x || 0), y: Math.round(f.y || 0), hp: f.hp, maxHp: f.maxHp } : null; })(),
        perfects: w.perfects,
      };
    },
  };
}
