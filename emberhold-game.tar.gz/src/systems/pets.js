// Pet summoning, collection and the passive bonuses of the active pet. Pure, atomic transactions.
import { PETS, PET_IDS, TIER_ODDS, SUMMON_COST, PITY, MAX_STARS, DUPLICATE_REFUND, getPet, petValues } from '../data/pets.js';
import { cloneState } from '../core/state.js';

const ORDER = { common: 0, rare: 1, epic: 2, legendary: 3 };

function pickTier(r, guaranteed) {
  const tiers = Object.entries(TIER_ODDS).filter(([t]) => !guaranteed || ORDER[t] >= ORDER.epic);
  const total = tiers.reduce((a, [, p]) => a + p, 0);
  let x = r * total;
  for (const [t, p] of tiers) { x -= p; if (x < 0) return t; }
  return tiers[tiers.length - 1][0];
}

// Rolls one pet. `pity` = summons since the last epic-or-better (before this one).
export function rollPet(rng, pity) {
  const guaranteed = pity + 1 >= PITY;
  const tier = pickTier(rng.next(), guaranteed);
  const ids = PET_IDS.filter((id) => PETS[id].rarity === tier);
  const id = ids[Math.min(ids.length - 1, Math.floor(rng.next() * ids.length))];
  return { id, tier, guaranteed };
}

export function summonCost(count) { return SUMMON_COST * count; }

export function summonPets(state, rng, count = 1) {
  if (!Number.isInteger(count) || count < 1 || count > 10) return { ok: false, reason: 'bad_count' };
  const cost = summonCost(count);
  if (state.sparks < cost) return { ok: false, reason: 'not_enough_sparks', cost };
  const next = cloneState(state);
  next.sparks -= cost;
  const results = [];
  for (let i = 0; i < count; i++) {
    const roll = rollPet(rng, next.pets.pity);
    next.pets.summons += 1;
    next.pets.pity = ORDER[roll.tier] >= ORDER.epic ? 0 : next.pets.pity + 1;
    const owned = next.pets.owned[roll.id];
    let refund = 0, stars = 1, isNew = false;
    if (!owned) { next.pets.owned[roll.id] = { stars: 1 }; isNew = true; }
    else if (owned.stars < MAX_STARS) { owned.stars += 1; stars = owned.stars; }
    else { refund = DUPLICATE_REFUND; next.sparks += refund; stars = owned.stars; }
    if (isNew && !next.pets.active) next.pets.active = roll.id; // first pet joins right away
    results.push({ id: roll.id, tier: roll.tier, stars, isNew, refund, guaranteed: roll.guaranteed });
  }
  return { ok: true, state: next, results, cost };
}

export function setActivePet(state, id) {
  if (id !== null && !getPet(id)) return { ok: false, reason: 'unknown_pet' };
  if (id !== null && !state.pets.owned[id]) return { ok: false, reason: 'not_owned' };
  if (state.pets.active === id) return { ok: false, reason: 'already_active' };
  const next = cloneState(state);
  next.pets.active = id;
  return { ok: true, state: next };
}

export function activePet(state) {
  const id = state.pets?.active;
  const pet = getPet(id);
  if (!pet || !state.pets.owned[id]) return null;
  const stars = state.pets.owned[id].stars;
  return { id, pet, stars, v: petValues(pet, stars) };
}

// Passive effects of the active pet for computeStats.
export function petPassives(state) {
  const b = { magnet: 0, goldMult: 0, skillCd: 0, skillPower: 0, allPct: 0, perfectRefund: 0 };
  const a = activePet(state);
  if (!a) return b;
  for (const k of Object.keys(b)) if (typeof a.v[k] === 'number') b[k] = a.v[k];
  return b;
}

export function pityLeft(state) {
  return Math.max(1, PITY - state.pets.pity);
}
