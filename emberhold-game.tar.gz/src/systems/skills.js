// Skill points, learning, slotting and passive bonuses. Pure, atomic transactions like the other systems.
import { SKILLS, SKILL_SLOTS, SKILL_RESET_COST, getSkill, rankValues } from '../data/skills.js';
import { cloneState } from '../core/state.js';

export function rankOf(state, id) {
  return state.skills.ranks[id] || 0;
}

// One point per level after the first.
export function skillPoints(state) {
  const total = Math.max(0, state.player.level - 1);
  const spent = Object.values(state.skills.ranks).reduce((a, r) => a + r, 0);
  return { total, spent, free: Math.max(0, total - spent) };
}

export function isUnlocked(state, id) {
  const s = getSkill(id);
  if (!s) return false;
  if (s.unlock.level != null && state.player.level < s.unlock.level) return false;
  if (s.unlock.flag && !state.story.flags[s.unlock.flag]) return false;
  return true;
}

export function unlockText(skill) {
  if (skill.unlock.flag === 'mem_thorns') return 'ปลดล็อกเมื่อความทรงจำแรกกลับมา (ด่านป่าหนาม)';
  if (skill.unlock.flag === 'mem_ward') return 'ปลดล็อกเมื่อพบจดหมายของดาว (เหมืองถ่านร้าง)';
  return `ปลดล็อกที่เลเวล ${skill.unlock.level}`;
}

export function canLearn(state, id) {
  const s = getSkill(id);
  if (!s) return { ok: false, reason: 'unknown_skill' };
  if (!isUnlocked(state, id)) return { ok: false, reason: 'skill_locked' };
  if (rankOf(state, id) >= s.maxRank) return { ok: false, reason: 'skill_max' };
  if (skillPoints(state).free <= 0) return { ok: false, reason: 'no_points' };
  return { ok: true };
}

export function learn(state, id) {
  const c = canLearn(state, id);
  if (!c.ok) return c;
  const next = cloneState(state);
  const r = (next.skills.ranks[id] || 0) + 1;
  next.skills.ranks[id] = r;
  // A newly learned active skill goes into the first empty slot automatically.
  if (r === 1 && SKILLS[id].kind === 'active' && !next.skills.slots.includes(id)) {
    const empty = next.skills.slots.indexOf(null);
    if (empty >= 0) next.skills.slots[empty] = id;
  }
  return { ok: true, state: next, rank: r };
}

export function equipSkill(state, id, slot) {
  const s = getSkill(id);
  if (!s || s.kind !== 'active') return { ok: false, reason: 'not_active' };
  if (!Number.isInteger(slot) || slot < 0 || slot >= SKILL_SLOTS) return { ok: false, reason: 'bad_slot' };
  if (rankOf(state, id) <= 0) return { ok: false, reason: 'not_learned' };
  const next = cloneState(state);
  const prev = next.skills.slots.indexOf(id);
  if (prev >= 0) next.skills.slots[prev] = next.skills.slots[slot]; // swap
  next.skills.slots[slot] = id;
  return { ok: true, state: next };
}

export function unequipSkill(state, slot) {
  if (!Number.isInteger(slot) || slot < 0 || slot >= SKILL_SLOTS || !state.skills.slots[slot]) return { ok: false, reason: 'bad_slot' };
  const next = cloneState(state);
  next.skills.slots[slot] = null;
  return { ok: true, state: next };
}

export function resetSkills(state) {
  if (skillPoints(state).spent === 0) return { ok: false, reason: 'nothing_to_reset' };
  if (state.gold < SKILL_RESET_COST) return { ok: false, reason: 'not_enough_gold' };
  const next = cloneState(state);
  next.gold -= SKILL_RESET_COST;
  next.skills.ranks = {};
  next.skills.slots = new Array(SKILL_SLOTS).fill(null);
  return { ok: true, state: next, cost: SKILL_RESET_COST };
}

// Sum of passive effects, consumed by computeStats.
export function passiveBonuses(state) {
  const b = { crit: 0, hpPct: 0, spd: 0, dashCd: 0, trapReduce: 0, healOnKill: 0 };
  for (const [id, rank] of Object.entries(state.skills.ranks)) {
    const s = getSkill(id);
    if (!s || s.kind !== 'passive' || rank <= 0) continue;
    const v = rankValues(s, rank);
    for (const k of Object.keys(b)) if (v[k] != null) b[k] += v[k];
  }
  return b;
}

// Active skills currently slotted, with their numbers, for the battle.
export function slottedSkills(state) {
  return state.skills.slots.map((id) => (id && rankOf(state, id) > 0 ? { id, rank: rankOf(state, id), skill: SKILLS[id], v: rankValues(SKILLS[id], rankOf(state, id)) } : null));
}
