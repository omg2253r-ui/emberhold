// Derives the player's combat stats from level + equipment. The HUD, the equipment panel
// and the battle simulation all call computeStats, so displayed stats always equal gameplay stats.
import { BALANCE } from '../config/balance.js';
import { getItem, EQUIP_SLOTS } from '../data/items.js';
import { passiveBonuses } from './skills.js';
import { raceStats, raceAbility } from './race.js';
import { petPassives } from './pets.js';

const STAT_KEYS = ['atk', 'def', 'hp', 'crit', 'critMult', 'spd'];

export function upgradeMultiplier(lvl) {
  return 1 + BALANCE.upgrade.statGrowthPerLevel * Math.max(0, lvl | 0);
}

// Stats of one equipment instance at its upgrade level.
export function itemStats(instance) {
  const def = instance && getItem(instance.id);
  if (!def || !def.stats) return {};
  const m = upgradeMultiplier(instance.lvl);
  const out = {};
  for (const k of STAT_KEYS) {
    if (def.stats[k] == null) continue;
    const v = def.stats[k] * m;
    out[k] = (k === 'atk' || k === 'def' || k === 'hp') ? Math.round(v) : Math.round(v * 1000) / 1000;
  }
  return out;
}

export function baseStats(level) {
  const p = BALANCE.player;
  const l = Math.max(1, level | 0) - 1;
  return {
    hp: Math.round(p.baseHp + p.hpPerLevel * l),
    atk: Math.round(p.baseAtk + p.atkPerLevel * l),
    def: Math.round(p.baseDef + p.defPerLevel * l),
    crit: p.baseCrit,
    critMult: p.baseCritMult,
    spd: 0,
  };
}

const r2 = (v) => Math.round(v * 100) / 100;
const r3 = (v) => Math.round(v * 1000) / 1000;

// Level + gear + passive skills + bloodline + active pet. Percent bonuses apply after flat ones.
export function computeStats(state) {
  const s = baseStats(state.player.level);
  for (const slot of EQUIP_SLOTS) {
    const it = itemStats(state.equipment[slot]);
    for (const k of Object.keys(it)) s[k] = (s[k] || 0) + it[k];
  }
  const pb = state.skills ? passiveBonuses(state) : { crit: 0, hpPct: 0, spd: 0, dashCd: 0, trapReduce: 0, healOnKill: 0 };
  const rs = raceStats(state), ra = raceAbility(state);
  const pp = state.pets ? petPassives(state) : { magnet: 0, goldMult: 0, skillCd: 0, skillPower: 0, allPct: 0, perfectRefund: 0 };
  s.crit += pb.crit + rs.crit; s.spd += pb.spd + rs.spd; s.critMult += rs.critMult;
  const weapon = getItem(state.equipment.weapon?.id);
  return {
    maxHp: Math.round(s.hp * (1 + pb.hpPct + rs.hpPct + pp.allPct)),
    atk: Math.round(s.atk * (1 + rs.atkPct + pp.allPct)),
    def: Math.round(s.def * (1 + rs.defPct + pp.allPct)),
    crit: Math.min(BALANCE.combat.critChanceCap, r3(s.crit)),
    critMult: r2(s.critMult),
    speed: Math.round(BALANCE.player.baseSpeed * (1 + s.spd)),
    spdBonus: r3(s.spd),
    // dodge / traps / sustain
    dashCdMult: r2((1 - pb.dashCd) * (1 - (ra.dodgeCd || 0))),
    perfectBonus: ra.perfectBonus || 0,
    trapReduce: Math.min(0.8, r3(pb.trapReduce + (ra.trapReduce || 0))),
    healOnKill: pb.healOnKill,
    regen: ra.regen || 0,
    lowHpDef: ra.lowHpDef || 0,
    fireReduce: ra.fireReduce || 0,
    ignite: ra.ignite || 0,
    lastStand: !!ra.lastStand,
    // economy / skills (bloodline + pet)
    goldMult: r2(1 + (ra.goldMult || 0) + pp.goldMult),
    magnetMult: r2(1 + pp.magnet),
    skillCdMult: r2(1 - pp.skillCd),
    skillPower: r2(1 + pp.skillPower),
    perfectRefund: pp.perfectRefund,
    wtype: weapon?.wtype || 'sword',
  };
}

// Simple score for comparing gear in the UI ("better/worse" arrows).
export function gearScore(stats) {
  return (stats.atk || 0) * 3 + (stats.def || 0) * 2.5 + (stats.hp || 0) * 0.35
    + (stats.crit || 0) * 120 + (stats.critMult || 0) * 40 + (stats.spd || 0) * 150;
}
