// Bloodline (race): current race card, re-roll with a Bloodstone, and the odds.
import { h, glyph, itemImg } from '../dom.js';
import { REROLL_ITEM } from '../../data/races.js';
import { countItem } from '../../systems/inventory.js';
import { raceCard, raceOddsTable } from '../raceUi.js';

export function createBloodlinePanel(app) {
  return {
    id: 'bloodline', title: 'สายเลือด', icon: 'race',
    badge: () => !app.store.get().race?.id,
    render(body) {
      const st = app.store.get();
      const stones = countItem(st, REROLL_ITEM);
      if (!st.race?.id) {
        body.replaceChildren(
          h('div', { class: 'empty-note' }, 'สายเลือดยังหลับใหลอยู่ ปลุกครั้งแรกได้ฟรี'),
          h('button', { class: 'btn primary', type: 'button', 'data-action': 'open-awaken', onclick: () => app.openAwaken('first') }, glyph('dice'), 'ปลุกสายเลือด'),
          h('div', { class: 'eyebrow' }, 'โอกาสของแต่ละสายเลือด'), raceOddsTable());
        return;
      }
      body.replaceChildren(
        raceCard(app, st.race.id),
        h('div', { class: 'reroll-box' },
          h('div', { class: 'aw-cost' }, itemImg(REROLL_ITEM), h('span', {}, `ศิลาเปลี่ยนสายเลือด ${stones} ก้อน`), h('small', { class: 'faint' }, 'ได้จากบอสเท่านั้น (หมูป่าหลังหนาม 35% · โกเลมเตาหลอม 50%)')),
          h('button', { class: 'btn gold', type: 'button', 'data-action': 'open-reroll', disabled: stones < 1, title: stones < 1 ? 'ต้องมีศิลาเปลี่ยนสายเลือด' : '', onclick: () => app.openAwaken('reroll') }, glyph('dice'), 'สุ่มสายเลือดใหม่')),
        h('details', { class: 'odds-box', open: true },
          h('summary', {}, glyph('dice'), 'โอกาสของแต่ละสายเลือด'),
          h('div', { class: 'eyebrow' }, 'สุ่มใหม่จะไม่ได้เผ่าเดิม โอกาสคำนวณจากเผ่าที่เหลือ'),
          raceOddsTable(st.race.id, st.race.id)),
        h('small', { class: 'faint' }, `ปลุกและเปลี่ยนสายเลือดมาแล้ว ${st.race.rolls} ครั้ง`));
    },
  };
}
