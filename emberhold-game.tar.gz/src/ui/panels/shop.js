// Merchant: buy supplies and gear, sell what you don't need.
import { h, glyph, itemImg, rarityClass, confirmButton, fmt } from '../dom.js';
import { SHOP_STOCK } from '../../data/shop.js';
import { getItem, isStackable, isEquipment } from '../../data/items.js';
import { rarityOf } from '../../data/rarity.js';
import { buy, sell, sellPrice, isStockUnlocked } from '../../systems/shop.js';
import { sortedSlots, canAdd } from '../../systems/inventory.js';
import { getStage } from '../../data/stages.js';
import { reasonText, CATEGORY_NAME } from '../format.js';
import { itemStats } from '../../systems/stats.js';
import { fmtStat, statName } from '../format.js';

export function createShopPanel(app) {
  let mode = 'buy';
  const qty = new Map();

  function statSummary(id) {
    const s = itemStats({ id, lvl: 0 });
    return Object.entries(s).map(([k, v]) => `${statName(k)} ${fmtStat(k, v, { sign: true })}`).join(' · ');
  }

  return {
    id: 'shop', title: 'ร้านค้า', icon: 'shop',
    render(body) {
      const st = app.store.get();
      const seg = h('div', { class: 'segmented', role: 'group', 'aria-label': 'โหมดร้านค้า' },
        h('button', { type: 'button', 'aria-pressed': String(mode === 'buy'), 'data-mode': 'buy', onclick: () => { mode = 'buy'; app.audio.play('tab'); app.rerender(); } }, 'ซื้อ'),
        h('button', { type: 'button', 'aria-pressed': String(mode === 'sell'), 'data-mode': 'sell', onclick: () => { mode = 'sell'; app.audio.play('tab'); app.rerender(); } }, 'ขาย'));

      let rows;
      if (mode === 'buy') {
        rows = SHOP_STOCK.map((entry) => {
          const def = getItem(entry.itemId);
          const open = isStockUnlocked(st, entry);
          const stack = isStackable(def);
          const n = stack ? (qty.get(entry.itemId) || 1) : 1;
          const cost = entry.price * n;
          const short = st.gold < cost;
          const full = !canAdd(st, entry.itemId, n);
          const stepper = stack ? h('div', { class: 'stepper' },
            h('button', { type: 'button', 'aria-label': 'ลดจำนวน', disabled: n <= 1, onclick: () => { qty.set(entry.itemId, Math.max(1, n - 1)); app.audio.play('click'); app.rerender(); } }, '−'),
            h('span', { class: 'num', 'data-qty': entry.itemId }, n),
            h('button', { type: 'button', 'aria-label': 'เพิ่มจำนวน', disabled: n >= 10, onclick: () => { qty.set(entry.itemId, Math.min(10, n + 1)); app.audio.play('click'); app.rerender(); } }, '+')) : null;
          const reason = !open ? `ปลดล็อกหลังผ่าน ${getStage(entry.requires)?.name}` : short ? 'ทองไม่พอ' : full ? 'กระเป๋าเต็ม' : null;
          const buyBtn = h('button', { class: 'btn primary small', type: 'button', 'data-buy': entry.itemId, disabled: !!reason, title: reason || '' }, open ? 'ซื้อ' : glyph('lock'));
          buyBtn.addEventListener('click', () => {
            if (buyBtn.disabled) return;
            buyBtn.disabled = true; // guards a double click before the re-render
            const r = buy(app.store.get(), entry.itemId, n);
            if (!r.ok) { app.toast(reasonText(r.reason), 'warn'); app.audio.play('error'); app.rerender(); return; }
            app.store.commit(r.state, { reason: 'buy' });
            app.audio.play('buy');
            app.toast(`ซื้อ ${def.name} ×${n} (−${fmt(r.cost)} ทอง)`, 'ok');
          });
          return h('div', { class: `row ${rarityClass(def.rarity)}` },
            h('div', { class: 'art' }, itemImg(def.id)),
            h('div', { class: 'info' }, h('b', { class: 'rc-text' }, def.name),
              h('small', {}, isEquipment(def) ? statSummary(def.id) : def.desc),
              reason ? h('small', { style: { color: 'var(--danger)' } }, reason) : null),
            h('div', { class: 'buy' }, h('span', { class: `price ${short && open ? 'short' : ''}` }, itemImg('gold'), h('span', { class: 'num' }, fmt(cost))), stepper, buyBtn));
        });
      } else {
        const items = sortedSlots(st).filter((it) => sellPrice(it) > 0);
        rows = items.length ? items.map((it) => {
          const def = getItem(it.id), r = rarityOf(def.rarity);
          const each = sellPrice(it);
          const risky = isEquipment(def) && (r.order >= 2 || it.lvl > 0);
          const doSell = (n) => {
            const res = sell(app.store.get(), it.uid, n);
            if (!res.ok) { app.toast(reasonText(res.reason), 'warn'); app.audio.play('error'); return; }
            app.store.commit(res.state, { reason: 'sell' });
            app.audio.play('buy');
            app.toast(`ขาย ${def.name}${n > 1 ? ' ×' + n : ''} ได้ ${fmt(res.earned)} ทอง`, 'ok');
          };
          const btns = [];
          if (it.qty > 1) btns.push(h('button', { class: 'btn small', type: 'button', 'data-sell-one': it.uid, onclick: (e) => { e.currentTarget.disabled = true; doSell(1); } }, `ขาย 1 (${each})`));
          btns.push(risky
            ? confirmButton(`ขาย ${fmt(each * it.qty)}`, 'ยืนยันขาย', () => doSell(it.qty), 'btn danger small')
            : h('button', { class: 'btn danger small', type: 'button', 'data-sell': it.uid, onclick: (e) => { e.currentTarget.disabled = true; doSell(it.qty); } }, it.qty > 1 ? `ขายทั้งหมด ${fmt(each * it.qty)}` : `ขาย ${fmt(each)}`));
          return h('div', { class: `row ${rarityClass(def.rarity)}` },
            h('div', { class: 'art' }, itemImg(def.id), it.lvl ? h('span', { class: 'lvl-tag' }, `+${it.lvl}`) : null),
            h('div', { class: 'info' }, h('b', { class: 'rc-text' }, def.name, it.lvl ? ` +${it.lvl}` : ''), h('small', {}, `${CATEGORY_NAME[def.category]} · มี ${it.qty} · ชิ้นละ ${fmt(each)} ทอง`)),
            h('div', { class: 'buy' }, btns));
        }) : [h('div', { class: 'empty-note' }, 'ไม่มีของที่ขายได้ (ของที่สวมอยู่ต้องถอดก่อนจึงจะขายได้)')];
      }
      body.replaceChildren(seg, h('div', { class: 'rows' }, rows));
    },
  };
}
