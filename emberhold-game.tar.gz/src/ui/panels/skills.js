// Skill panel: spend points, see what each rank does, choose which actives go in the 3 slots.
import { h, glyph, confirmButton } from '../dom.js';
import { SKILLS, SKILL_SLOTS, SKILL_RESET_COST, rankValues } from '../../data/skills.js';
import { skillPoints, isUnlocked, unlockText, rankOf, learn, equipSkill, unequipSkill, resetSkills } from '../../systems/skills.js';
import { reasonText } from '../format.js';

const REASONS = { skill_locked: 'ยังไม่ปลดล็อก', skill_max: 'ระดับสูงสุดแล้ว', no_points: 'แต้มสกิลไม่พอ', nothing_to_reset: 'ยังไม่ได้เรียนสกิลใด' };

export function createSkillsPanel(app) {
  function act(r, msg, sound = 'tab') {
    if (!r.ok) { app.toast(REASONS[r.reason] || reasonText(r.reason), 'warn'); app.audio.play('error'); return; }
    app.store.commit(r.state, { reason: 'skills' });
    if (msg) app.toast(msg, 'ok');
    app.audio.play(sound);
  }

  function card(st, s) {
    const rank = rankOf(st, s.id), open = isUnlocked(st, s.id), pts = skillPoints(st).free;
    const pips = h('span', { class: 'pips', 'aria-label': `ระดับ ${rank}/${s.maxRank}` }, Array.from({ length: s.maxRank }, (_, i) => h('i', { class: i < rank ? 'on' : '' })));
    const cur = rank > 0 ? s.desc(rankValues(s, rank)) : null;
    const next = rank < s.maxRank ? s.desc(rankValues(s, rank + 1)) : null;
    const cdLine = s.kind === 'active' ? h('span', { class: 'chip' }, `คูลดาวน์ ${rankValues(s, Math.max(1, rank)).cooldown} วิ`) : h('span', { class: 'chip' }, 'ติดตัว');
    const actions = [];
    if (open && rank < s.maxRank) {
      actions.push(h('button', { class: 'btn primary small', type: 'button', 'data-learn': s.id, disabled: pts <= 0, onclick: () => act(learn(app.store.get(), s.id), rank === 0 ? `เรียน «${s.name}» แล้ว` : `«${s.name}» ระดับ ${rank + 1}`, 'levelup') },
        rank === 0 ? 'เรียน (1 แต้ม)' : 'เพิ่มระดับ (1 แต้ม)'));
    }
    if (s.kind === 'active' && rank > 0) {
      const slots = st.skills.slots;
      actions.push(h('div', { class: 'slot-pick', role: 'group', 'aria-label': 'เลือกช่อง' }, Array.from({ length: SKILL_SLOTS }, (_, i) =>
        h('button', { class: `slot-chip ${slots[i] === s.id ? 'on' : ''}`, type: 'button', 'data-equip': `${s.id}:${i}`, 'aria-pressed': String(slots[i] === s.id),
          onclick: () => (slots[i] === s.id ? act(unequipSkill(app.store.get(), i), null, 'click') : act(equipSkill(app.store.get(), s.id, i), `ใส่ «${s.name}» ช่อง ${i + 1}`, 'click')) }, `ช่อง ${i + 1}`))));
    }
    return h('article', { class: `skill-card ${open ? '' : 'locked'} ${rank > 0 ? 'learned' : ''}`, 'data-skill': s.id },
      h('div', { class: 'skill-top' },
        h('span', { class: 'skill-ic' }, glyph(open ? s.icon : 'lock')),
        h('div', { class: 'skill-meta' }, h('b', {}, s.name), h('div', { class: 'row-meta' }, pips, cdLine))),
      cur ? h('p', { class: 'skill-desc' }, h('span', { class: 'tag' }, 'ตอนนี้'), cur) : null,
      next ? h('p', { class: 'skill-desc next' }, h('span', { class: 'tag' }, rank === 0 ? 'ระดับ 1' : `ระดับ ${rank + 1}`), next) : null,
      h('p', { class: 'skill-lore' }, open ? s.lore : unlockText(s)),
      actions.length ? h('div', { class: 'actions' }, actions) : null);
  }

  return {
    id: 'skills', title: 'สกิล', icon: 'whirl',
    badge: () => skillPoints(app.store.get()).free > 0,
    render(body) {
      const st = app.store.get();
      const pts = skillPoints(st);
      const slotRow = h('div', { class: 'skill-slots' }, st.skills.slots.map((id, i) => h('div', { class: `skill-slot ${id ? 'on' : ''}` },
        h('span', { class: 'n' }, app.touch ? `ช่อง ${i + 1}` : `ปุ่ม ${i + 1}`),
        id ? h('span', { class: 'skill-ic' }, glyph(SKILLS[id].icon)) : h('span', { class: 'skill-ic empty' }),
        h('span', { class: 'nm' }, id ? SKILLS[id].name : 'ว่าง'))));
      const actives = Object.values(SKILLS).filter((s) => s.kind === 'active');
      const passives = Object.values(SKILLS).filter((s) => s.kind === 'passive');
      body.replaceChildren(
        h('div', { class: 'points-bar' },
          h('div', {}, h('div', { class: 'eyebrow' }, 'แต้มสกิล'), h('b', { class: 'num big-num', 'data-points': '' }, pts.free), h('span', { class: 'muted' }, ` / ${pts.total} · ได้ 1 แต้มทุกเลเวล`)),
          pts.spent > 0 ? confirmButton(`รีเซ็ต (${SKILL_RESET_COST} ทอง)`, 'ยืนยันรีเซ็ต', () => act(resetSkills(app.store.get()), 'คืนแต้มสกิลทั้งหมดแล้ว'), 'btn small') : null),
        h('div', { class: 'eyebrow' }, 'ช่องสกิลในการต่อสู้'), slotRow,
        h('div', { class: 'eyebrow' }, 'สกิลกดใช้'), ...actives.map((s) => card(st, s)),
        h('div', { class: 'eyebrow' }, 'สกิลติดตัว'), ...passives.map((s) => card(st, s)));
    },
  };
}
