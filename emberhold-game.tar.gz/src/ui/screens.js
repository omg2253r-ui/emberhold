// Title screen, camp shell (top bar + dock + panel sheet), result / pause / settings modals.
import { h, glyph, itemImg, rarityClass, confirmButton, fmt } from './dom.js';
import { GAME_VERSION, hasUnseenNotes } from '../data/changelog.js';
import { getItem } from '../data/items.js';
import { getStage } from '../data/stages.js';
import { xpToNext } from '../config/balance.js';
import { createStagesPanel } from './panels/stages.js';
import { createGearPanel } from './panels/gear.js';
import { createForgePanel } from './panels/forge.js';
import { createShopPanel } from './panels/shop.js';
import { createSkillsPanel } from './panels/skills.js';
import { createJournalPanel } from './panels/journal.js';
import { createBloodlinePanel } from './panels/bloodline.js';
import { createPetsPanel } from './panels/pets.js';
import { currentGoal } from '../systems/story.js';
import { HERO_NAME_MAX } from '../core/state.js';

const LOGO = `<svg viewBox="0 0 72 72" aria-hidden="true"><circle cx="36" cy="36" r="33" fill="#17110e" stroke="#e0b45a" stroke-width="2"/><circle cx="36" cy="36" r="27" fill="none" stroke="#8f6f37" stroke-width="1"/>
<path d="M36 12c6 9 14 14 14 25a14 14 0 0 1-28 0c0-7 4-11 7-15 0 6 3 9 6 10-2-8 0-14 1-20z" fill="#c2412f" stroke="#241712" stroke-width="2" stroke-linejoin="round"/>
<path d="M36 30c3 5 7 8 7 13a7 7 0 0 1-14 0c0-4 3-7 4-9 0 3 2 5 3 5 0-4 0-6 0-9z" fill="#f5d48a"/><path d="M22 58h28" stroke="#e0b45a" stroke-width="2.5" stroke-linecap="round"/></svg>`;

const unseen = () => (hasUnseenNotes() ? h('i', { class: 'new-dot', 'aria-label': 'มีอัปเดตใหม่' }) : null);

export function createScreens(root, app) {
  // ------------------------------------------------------------ loading
  const loadBar = h('i');
  const loadMsg = h('div', { class: 'muted' }, 'กำลังวาดตัวละคร…');
  const loading = h('div', { class: 'layer' }, h('div', { class: 'screen-center' }, h('div', { class: 'loading' }, h('div', { class: 'logo' }, h('span', { class: 'mark', html: LOGO })), h('div', { class: 'bar' }, loadBar), loadMsg)));

  // ------------------------------------------------------------ title
  const titleNotice = h('div', { hidden: true });
  const titleSummary = h('div', { class: 'save-summary' });
  const continueBtn = h('button', { class: 'btn primary', type: 'button', 'data-action': 'continue', onclick: () => app.continueGame() }, 'เล่นต่อ');
  const newBtnHost = h('div', { style: { display: 'grid' } });
  const title = h('div', { class: 'layer', hidden: true },
    h('div', { class: 'screen-center' },
      h('div', { class: 'title-card panel' },
        h('div', { class: 'logo' }, h('span', { class: 'mark', html: LOGO }), h('h1', {}, 'EMBERHOLD'), h('div', { class: 'sub' }, 'นักล่าแห่งป่าหนาม')),
        h('p', { class: 'muted', style: { margin: 0, fontSize: 'var(--step--1)' } }, 'ล่าสัตว์ร้ายในป่าหนาม เก็บวัตถุดิบ แล้วกลับมาตีบวกอาวุธที่ค่ายริมกองไฟ'),
        titleNotice,
        h('div', { class: 'menu' }, continueBtn, newBtnHost),
        titleSummary,
        h('button', { class: 'whats-new', type: 'button', 'data-action': 'whats-new', onclick: () => app.openPatchNotes() }, glyph('star'), `มีอะไรใหม่ · v${GAME_VERSION.replace(/\.0$/, '')}`, unseen()),
        h('small', { class: 'faint' }, 'เกมบันทึกอัตโนมัติในเบราว์เซอร์นี้'))));

  function showTitle({ hasSave, summary, notice }) {
    for (const l of [loading, camp, title]) l.hidden = l !== title;
    continueBtn.hidden = !hasSave;
    titleSummary.replaceChildren(...(summary ? [h('span', {}, `เลเวล ${summary.level}`), h('span', {}, `ทอง ${fmt(summary.gold)}`), h('span', {}, `ผ่านด่าน ${summary.cleared}`)] : []));
    titleNotice.hidden = !notice;
    if (notice) { titleNotice.className = 'notice'; titleNotice.textContent = notice; }
    newBtnHost.replaceChildren(hasSave
      ? confirmButton('เริ่มเกมใหม่', 'กดอีกครั้ง: ลบเซฟเดิมแล้วเริ่มใหม่', () => app.newGame(), 'btn')
      : h('button', { class: 'btn primary', type: 'button', 'data-action': 'new-game', onclick: () => app.newGame() }, 'เริ่มผจญภัย'));
    (hasSave ? continueBtn : newBtnHost.firstChild).focus({ preventScroll: true });
  }

  // ------------------------------------------------------------ camp
  const panels = [createStagesPanel(app), createGearPanel(app), createSkillsPanel(app), createBloodlinePanel(app), createPetsPanel(app), createForgePanel(app), createShopPanel(app), createJournalPanel(app)];
  let current = null;
  const lvNum = h('div', { class: 'lv-num num' }, '1');
  const xpFill = h('i'), xpText = h('span', { class: 'name num' });
  const goalBtn = h('button', { class: 'goal-line', type: 'button', 'data-action': 'goal', onclick: () => openPanel('journal') }, glyph('crown'), h('span', {}));
  const goldPill = h('div', { class: 'gold-pill', 'aria-label': 'ทอง' }, itemImg('gold'), h('span', { class: 'num', 'data-gold': '' }, '0'));
  const settingsBtn = h('button', { class: 'btn icon', type: 'button', 'aria-label': 'ตั้งค่า', 'data-action': 'settings', onclick: () => openSettings() }, glyph('gear'));
  const topbar = h('div', { class: 'topbar' },
    h('div', { class: 'lv-badge' }, lvNum, h('div', { class: 'lv-meta' }, xpText, h('div', { class: 'xpbar' }, xpFill), goalBtn)),
    goldPill, settingsBtn);
  const tabs = panels.map((p) => h('button', { class: 'tab', type: 'button', role: 'tab', 'aria-selected': 'false', 'data-tab': p.id, onclick: () => togglePanel(p.id) }, glyph(p.icon), h('span', {}, p.short || p.title), h('i', { class: 'dot', hidden: true })));
  const dock = h('nav', { class: 'dock', role: 'tablist', 'aria-label': 'เมนูค่าย' }, tabs);
  const sheetTitle = h('h2', {});
  const sheetBody = h('div', { class: 'sheet-body' });
  const sheet = h('section', { class: 'sheet panel', hidden: true, 'aria-live': 'polite' },
    h('div', { class: 'sheet-head' }, sheetTitle, h('button', { class: 'btn icon ghost', type: 'button', 'aria-label': 'ปิด', 'data-action': 'close-sheet', onclick: () => closePanel(false) }, glyph('close'))),
    sheetBody);
  const camp = h('div', { class: 'layer', hidden: true }, topbar, sheet, dock);

  function renderPanel() {
    if (!current) return;
    const p = panels.find((x) => x.id === current);
    sheetTitle.textContent = p.title;
    p.render(sheetBody);
  }
  function openPanel(id, params) {
    const p = panels.find((x) => x.id === id);
    if (!p) return;
    if (current !== id) sheetBody.scrollTop = 0;
    current = id; p.open?.(params);
    tabs.forEach((t) => t.setAttribute('aria-selected', String(t.dataset.tab === id)));
    sheet.hidden = false;
    sheet.style.animation = 'none'; void sheet.offsetWidth; sheet.style.animation = '';
    app.audio.play('tab');
    renderPanel();
  }
  function closePanel(silent = false) {
    current = null; sheet.hidden = true;
    tabs.forEach((t) => t.setAttribute('aria-selected', 'false'));
    if (!silent) app.audio.play('click');
  }
  function togglePanel(id) { if (current === id) closePanel(); else openPanel(id); }

  let lastGold = null;
  function renderTop(st) {
    lvNum.textContent = st.player.level;
    const need = xpToNext(st.player.level);
    xpText.textContent = `${st.story.name} · ประสบการณ์ ${st.player.xp}/${need}`;
    goalBtn.lastChild.textContent = currentGoal(st).text;
    panels.forEach((p, i) => { tabs[i].querySelector('.dot').hidden = !(p.badge && p.badge()); });
    xpFill.style.width = `${Math.min(100, (st.player.xp / need) * 100)}%`;
    goldPill.querySelector('[data-gold]').textContent = fmt(st.gold);
    if (lastGold != null && st.gold !== lastGold) { goldPill.classList.remove('bump'); void goldPill.offsetWidth; goldPill.classList.add('bump'); }
    lastGold = st.gold;
  }

  function showCamp(openId) {
    for (const l of [loading, title, camp]) l.hidden = l !== camp;
    document.body.classList.add('in-camp');
    lastGold = null;
    renderTop(app.store.get());
    if (openId) openPanel(openId); else if (current) renderPanel();
  }

  // ------------------------------------------------------------ modals
  const modalHost = h('div', { class: 'layer' });
  function modal(content, { onClose = null, dismissable = true } = {}) {
    const back = h('div', { class: 'modal-back', role: 'dialog', 'aria-modal': 'true' }, content);
    if (dismissable) back.addEventListener('pointerdown', (e) => { if (e.target === back) close(); });
    const onKey = (e) => { if (e.key === 'Escape' && dismissable) close(); };
    window.addEventListener('keydown', onKey);
    function close() { window.removeEventListener('keydown', onKey); back.remove(); onClose?.(); }
    modalHost.append(back);
    setTimeout(() => content.querySelector('button')?.focus({ preventScroll: true }), 30);
    return close;
  }

  function settingsRows() {
    const st = app.store.get();
    const s = st.settings;
    const sfx = h('input', { type: 'range', min: 0, max: 100, value: Math.round(s.sfx * 100), id: 'set-sfx', 'aria-label': 'ระดับเสียงเอฟเฟกต์' });
    const mus = h('input', { type: 'range', min: 0, max: 100, value: Math.round(s.music * 100), id: 'set-music', 'aria-label': 'ระดับเสียงดนตรี' });
    const shake = h('input', { type: 'checkbox', class: 'switch', id: 'set-shake', 'aria-label': 'สั่นหน้าจอ' });
    shake.checked = s.shake;
    const apply = () => app.updateSettings({ sfx: sfx.value / 100, music: mus.value / 100, shake: shake.checked });
    sfx.addEventListener('change', () => { apply(); app.audio.play('hit'); });
    mus.addEventListener('change', apply);
    shake.addEventListener('change', apply);
    const nameIn = h('input', { type: 'text', id: 'set-name', maxlength: String(HERO_NAME_MAX), value: st.story.name, 'aria-label': 'ชื่อนักล่า', class: 'text-in' });
    nameIn.addEventListener('change', () => app.renameHero(nameIn.value));
    // Full screen (and landscape lock where the phone allows it). Hidden where the browser cannot go full screen.
    const fsRow = document.fullscreenEnabled ? h('div', { class: 'setting' }, glyph('shake'), 'เต็มจอ / แนวนอน',
      h('button', { class: 'btn small', type: 'button', 'data-action': 'fullscreen', onclick: async () => {
        try {
          if (document.fullscreenElement) { await document.exitFullscreen(); return; }
          await document.documentElement.requestFullscreen({ navigationUI: 'hide' });
          if (app.touch) await screen.orientation?.lock?.('landscape').catch(() => {});
        } catch { app.toast('เบราว์เซอร์นี้ไม่อนุญาตเต็มจอ หมุนเครื่องเป็นแนวนอนได้เลย เกมรองรับทั้งสองแนว', 'info', 'fs'); }
      } }, document.fullscreenElement ? 'ออกจากเต็มจอ' : 'เปิด')) : null;
    return [
      fsRow,
      h('label', { class: 'setting', for: 'set-name' }, glyph('talk'), 'ชื่อนักล่า', nameIn),
      h('label', { class: 'setting', for: 'set-sfx' }, glyph('sound'), 'เสียงเอฟเฟกต์', sfx),
      h('label', { class: 'setting', for: 'set-music' }, glyph('music'), 'ดนตรี', mus),
      h('label', { class: 'setting', for: 'set-shake' }, glyph('shake'), 'สั่นหน้าจอเมื่อโดนโจมตี', shake),
    ];
  }

  const keysHelp = () => h('div', { class: 'keys' },
    h('kbd', {}, 'WASD / ลูกศร'), h('span', {}, 'เดิน'),
    h('kbd', {}, 'J / Space / คลิก'), h('span', {}, 'โจมตี: กดเป็นจังหวะ = คอมโบตามอาวุธ · กดค้างแล้วปล่อย = ท่าชาร์จ'),
    h('kbd', {}, 'K / Shift'), h('span', {}, 'หลบ (2 ชาร์จ) ยกเลิกท่าได้ · หลบตอนศัตรูกำลังโดน = หลบสมบูรณ์ · หลบแล้วโจมตี = ท่าหลังหลบ'),
    h('kbd', {}, 'Q'), h('span', {}, 'ใช้ยาฟื้นพลัง'),
    h('kbd', {}, '1 / 2 / 3'), h('span', {}, 'ใช้สกิลในช่อง 1–3 (หรือ U / I / O)'),
    h('kbd', {}, 'R / 4'), h('span', {}, 'สกิลเผ่า'),
    h('kbd', {}, 'E / F'), h('span', {}, 'เปิดหีบ อ่านเอกสาร พักที่กองไฟ ใช้กุญแจ'),
    h('kbd', {}, 'Esc / P'), h('span', {}, 'หยุดเกม'));

  function openSettings() {
    app.audio.play('click');
    let close;
    const content = h('div', { class: 'modal panel' },
      h('h2', {}, 'ตั้งค่า'),
      settingsRows(),
      keysHelp(),
      h('button', { class: 'btn', type: 'button', 'data-action': 'open-notes', onclick: () => { close(); app.openPatchNotes(); } }, glyph('star'), `ประกาศอัปเดต (เวอร์ชัน ${GAME_VERSION})`),
      h('div', { class: 'actions' },
        confirmButton('ลบเซฟและเริ่มใหม่', 'กดอีกครั้งเพื่อลบถาวร', () => { close(); app.deleteSave(); }, 'btn danger'),
        h('button', { class: 'btn primary', type: 'button', onclick: () => close() }, 'เสร็จ')));
    close = modal(content);
  }

  function openPause() {
    let close;
    const content = h('div', { class: 'modal panel', 'data-modal': 'pause' },
      h('h2', {}, 'พักการล่า'),
      settingsRows(),
      keysHelp(),
      h('div', { class: 'actions' },
        confirmButton('ถอนตัวกลับค่าย', 'ยืนยัน: กลับค่าย (ของที่เก็บแล้วยังอยู่)', () => { close(); app.retreat(); }, 'btn danger'),
        h('button', { class: 'btn primary', type: 'button', 'data-action': 'resume', onclick: () => close() }, 'สู้ต่อ')));
    close = modal(content, { onClose: () => app.resumeBattle() });
    return close;
  }

  function openResult(res) {
    const { outcome, run, stage, completion } = res;
    const titleText = outcome === 'victory' ? 'ล่าสำเร็จ' : outcome === 'defeat' ? 'พ่ายแพ้' : 'ถอนตัว';
    const sub = outcome === 'victory' ? stage.name : outcome === 'defeat' ? 'ของที่เก็บได้ระหว่างทางยังอยู่ในกระเป๋า' : 'กลับค่ายพร้อมของที่เก็บได้';
    let close;
    const nextStage = completion?.unlocked?.length ? getStage(completion.unlocked[0]) : null;
    const content = h('div', { class: 'modal panel', 'data-modal': 'result', 'data-outcome': outcome },
      h('div', { class: 'eyebrow', style: { textAlign: 'center' } }, stage.name),
      h('h2', { class: outcome === 'victory' ? '' : 'lose' }, titleText),
      h('p', { class: 'muted', style: { margin: 0, textAlign: 'center' } }, sub),
      completion?.firstClear ? h('div', { class: 'notice ok' }, `ผ่านด่านครั้งแรก รับโบนัส ${completion.bonusGold} ทอง และประกายอำพัน ${completion.bonusSparks} ${nextStage ? ` · ปลดล็อก ${nextStage.name}` : ''}`) : null,
      h('div', { class: 'kv' },
        h('div', {}, h('span', { class: 'muted' }, 'กำจัด'), h('b', {}, `${run.kills} ตัว`)),
        h('div', {}, h('span', { class: 'muted' }, 'เวลา'), h('b', {}, `${Math.floor(run.seconds / 60)}:${String(run.seconds % 60).padStart(2, '0')}`)),
        h('div', {}, h('span', { class: 'muted' }, 'ประสบการณ์'), h('b', {}, `+${run.xp}`)),
        h('div', {}, h('span', { class: 'muted' }, 'ทอง'), h('b', {}, `+${fmt(run.gold)}`)),
        run.totalRooms ? h('div', {}, h('span', { class: 'muted' }, 'สำรวจ'), h('b', {}, `${run.rooms}/${run.totalRooms} ห้อง`)) : null,
        run.totalRooms ? h('div', {}, h('span', { class: 'muted' }, 'หีบ · เอกสาร'), h('b', {}, `${run.chests} · ${run.lore}`)) : null,
        h('div', {}, h('span', { class: 'muted' }, 'คอมโบสูงสุด'), h('b', {}, `${run.bestCombo || 0} ฮิต`)),
        h('div', {}, h('span', { class: 'muted' }, 'หลบสมบูรณ์'), h('b', {}, `${run.perfects || 0} ครั้ง`)),
        run.sparks ? h('div', {}, h('span', { class: 'muted' }, 'ประกายอำพัน'), h('b', {}, `+${run.sparks}`)) : null),
      run.levelUps ? h('div', { class: 'notice ok' }, `เลเวลอัป ${run.levelUps} ครั้ง`) : null,
      h('div', { class: 'eyebrow' }, `ของที่ได้ (${run.items.length} ชนิด)`),
      run.items.length
        ? h('div', { class: 'loot-grid' }, run.items.map((it, i) => {
          const def = getItem(it.id);
          return h('div', { class: `cell ${rarityClass(def.rarity)}`, title: def.name, style: { animationDelay: `${i * 60}ms` } }, itemImg(it.id), h('span', { class: 'qty' }, it.qty));
        }))
        : h('div', { class: 'empty-note' }, 'รอบนี้ไม่ได้ไอเทม'),
      res.saveOk ? null : h('div', { class: 'notice' }, 'บันทึกเกมไม่สำเร็จ (เบราว์เซอร์อาจปิดพื้นที่จัดเก็บ) ความคืบหน้าจะหายเมื่อปิดหน้า'),
      h('div', { class: 'actions' },
        h('button', { class: 'btn', type: 'button', 'data-action': 'again', onclick: () => { close(); app.startBattle(stage.id); } }, 'ล่าอีกครั้ง'),
        h('button', { class: 'btn primary', type: 'button', 'data-action': 'to-camp', onclick: () => { close(); app.goCamp(run.items.some((x) => getItem(x.id)?.category !== 'consumable') ? 'gear' : null); } }, 'กลับค่าย')));
    close = modal(content, { dismissable: false });
  }

  root.append(loading, title, camp, modalHost);

  return {
    loading: {
      progress(f, msg) { loadBar.style.width = `${Math.round(f * 100)}%`; if (msg) loadMsg.textContent = msg; },
      error(msg) { loadMsg.textContent = msg; loadMsg.style.color = 'var(--danger)'; },
    },
    showTitle, showCamp,
    hideAll() { for (const l of [loading, title, camp]) l.hidden = true; document.body.classList.remove('in-camp'); },
    openPanel, closePanel, rerender: renderPanel, renderTop, openPause, openResult, openSettings, modal,
    setBusy(b) { tabs.forEach((t) => { t.disabled = b; }); settingsBtn.disabled = b; },
    get currentPanel() { return current; },
    get campVisible() { return !camp.hidden; },
  };
}
