// The rift board: the ten online zones with their level, mechanic, monsters, boss and rewards.
// Go alone, or open an expedition room (up to 4 players) that everyone online can join.
import { h, glyph, itemImg, pct } from './dom.js';
import { tipTarget } from './itemTip.js';
import { dropOdds } from '../systems/loot.js';
import { ZONES, clearReward } from '../data/zones.js';
import { getEnemy } from '../data/enemies.js';
import { getItem } from '../data/items.js';

export function zoneLock(st, zone) {
  if (st.player.level < zone.level - 3) return `ต้องเลเวล ${zone.level - 3} ขึ้นไป`;
  if (zone.n === 1) return st.progress.cleared.s1 ? null : 'ผ่านป่าหนามสนธยาในเนื้อเรื่องก่อน';
  const prev = ZONES[zone.n - 2];
  return st.zones.cleared[prev.id] ? null : `พิชิต${prev.name}ก่อน`;
}

const fmtTime = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;

export function openZoneBoard(app) {
  const st = app.store.get();
  let close;
  const o = app.online;
  const cards = ZONES.map((z) => {
    const lock = zoneLock(st, z);
    const cleared = st.zones.cleared[z.id] || 0;
    const boss = getEnemy(z.boss);
    const legendary = boss?.drops.flatMap((t) => t.entries).map((e) => getItem(e.id)).find((d) => d?.rarity === 'legendary');
    const rw = clearReward(z, !cleared);
    return h('article', { class: `zone-card ${lock ? 'locked' : ''} t-${z.theme}`, 'data-zone': z.id },
      h('div', { class: 'zone-top' },
        h('span', { class: 'zone-n num' }, z.n),
        h('div', { class: 'zone-title' }, h('h3', {}, z.name), h('small', { class: 'muted' }, `เลเวล ${z.level} · ${z.rooms.length} ห้อง`)),
        cleared ? h('span', { class: 'chip ok' }, glyph('check'), `พิชิต ${cleared}${st.zones.best[z.id] ? ` · ${fmtTime(st.zones.best[z.id])}` : ''}`) : null),
      h('p', { class: 'muted zone-desc' }, z.desc),
      h('div', { class: 'zone-mech' }, glyph('wind'), h('span', {}, z.mechanicText)),
      h('div', { class: 'zone-foes' },
        z.monsters.map((id) => h('span', { class: 'foe-chip' }, h('img', { alt: '', src: app.spriteUri(id) }), getEnemy(id).name)),
        h('span', { class: 'foe-chip boss' }, h('img', { alt: '', src: app.spriteUri(z.boss) }), `บอส: ${boss.name}`)),
      h('div', { class: 'zone-reward' },
        h('span', {}, itemImg('gold'), `${rw.gold}`), h('span', {}, itemImg('spark'), `${rw.sparks}`), h('span', { class: 'muted' }, `+${rw.xp} ประสบการณ์${cleared ? '' : ' (โบนัสครั้งแรก)'}`),
        legendary ? tipTarget(h('span', { class: 'leg' }, itemImg(legendary.id), legendary.name), legendary.id, { chance: dropOdds(boss.drops).find((d) => d.id === legendary.id)?.chance }) : null),
      h('div', { class: 'odds zone-odds' }, h('span', { class: 'muted' }, 'บอสดรอป'),
        dropOdds(boss.drops).filter((d) => getItem(d.id)).sort((a, b) => b.chance - a.chance).map((d) =>
          tipTarget(h('span', {}, itemImg(d.id), h('span', { class: 'num' }, pct(d.chance, d.chance < 0.1 ? 1 : 0))), d.id, { chance: d.chance }))),
      lock
        ? h('button', { class: 'btn', type: 'button', disabled: true }, glyph('lock'), lock)
        : h('div', { class: 'zone-actions' },
          h('button', { class: 'btn', type: 'button', 'data-action': 'zone-solo', onclick: () => { close(); app.startZoneSolo(z.id); } }, glyph('sword'), 'ลุยคนเดียว'),
          h('button', { class: 'btn primary', type: 'button', 'data-action': 'zone-party', disabled: !o.canSend(), title: o.canSend() ? '' : (o.online ? 'บัญชีนี้ดูอย่างเดียว' : o.reason),
            onclick: async () => { close(); await app.openExpedition(z.id); } }, glyph('people'), 'เปิดคณะสำรวจ (สูงสุด 4)')));
  });
  const content = h('div', { class: 'modal panel zone-board', 'data-modal': 'zones' },
    h('h2', {}, 'ประตูมิติ · ดันเจี้ยนรวม'),
    h('p', { class: 'muted', style: { margin: 0, textAlign: 'center', fontSize: 'var(--step--1)' } }, 'สิบโซน สิบแบบ มอนสเตอร์และกลไกไม่ซ้ำกัน ไปคนเดียวหรือพาเพื่อนไปได้ถึง 4 คน (ศัตรูแข็งขึ้นตามจำนวนคน) ของดรอปเป็นของใครของมัน'),
    h('div', { class: 'zone-list' }, cards),
    h('div', { class: 'actions' }, h('button', { class: 'btn', type: 'button', onclick: () => close() }, 'ปิด')));
  close = app.modal(content);
  return close;
}
